/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.controller;

import hsb.dto.SuperDTO;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public interface SuperController <T extends SuperDTO,IdType>{
     public boolean add(T t) throws Exception;

    public boolean update(T t) throws Exception;

    public boolean delete(String id) throws Exception;
    
    public T getByID(String id) throws Exception;

    public ArrayList<T> search(String id) throws Exception;

    public ArrayList<T> getAll() throws Exception;
}
