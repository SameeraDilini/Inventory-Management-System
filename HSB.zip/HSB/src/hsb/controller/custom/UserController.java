/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.controller.custom;

import hsb.controller.SuperController;
import hsb.dto.UserDTO;

/**
 *
 * @author user
 */
public interface UserController extends SuperController<UserDTO, String>{
    Boolean lastUser(UserDTO dto) throws Exception;
    String getLogged_username() throws Exception;
}
