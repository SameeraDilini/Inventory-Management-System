/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.controller.custom.impl;

import hsb.controller.custom.UserController;
import hsb.dto.SuperDTO;
import hsb.dto.UserDTO;
import hsb.service.ServiceFactory;
import hsb.service.custom.impl.UserServiceImpl;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class UserControllerImpl implements UserController{
    
    private static Boolean user;

    @Override
    public Boolean lastUser(UserDTO dto) throws Exception {
        UserServiceImpl userServiceimpl=(UserServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.USER);
        user=userServiceimpl.lastUser(dto);
        
        return user;
    }

    @Override
    public boolean add(UserDTO t) throws Exception {
        UserServiceImpl userServiceimpl=(UserServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.USER);
        user=userServiceimpl.add(t);
        
        return user;
    }

    @Override
    public boolean update(UserDTO t) throws Exception {
        UserServiceImpl userServiceimpl=(UserServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.USER);
        user=userServiceimpl.update(t);
        
        return user;
    }

    @Override
    public boolean delete(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public UserDTO getByID(String id) throws Exception {
        UserServiceImpl userServiceimpl=(UserServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.USER);
        return userServiceimpl.getByID(id);
        
    }

    @Override
    public ArrayList<UserDTO> search(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<UserDTO> getAll() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getLogged_username() throws Exception {
        UserServiceImpl userServiceimpl=(UserServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.USER);
        return userServiceimpl.getLogged_username();
        
    }

    

    
    
}
