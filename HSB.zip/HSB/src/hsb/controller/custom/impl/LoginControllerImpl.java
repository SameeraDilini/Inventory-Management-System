/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.controller.custom.impl;

import hsb.controller.custom.LoginController;
import hsb.dto.LoginDTO;
import hsb.dto.SuperDTO;
import hsb.service.ServiceFactory;
import hsb.service.custom.impl.LoginServiceImpl;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class LoginControllerImpl implements LoginController{
    
    private static LoginDTO user;

    @Override
    public LoginDTO CheckUser(LoginDTO dto) throws Exception {
        LoginServiceImpl loginServiceimpl=(LoginServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.LOGIN);
        user=loginServiceimpl.CheckUser(dto);
        
        return user;
    }

    
    
    public static LoginDTO getUser(){
    
       return LoginControllerImpl.user;
    
    }

    @Override
    public boolean add(SuperDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean update(SuperDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public SuperDTO getByID(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList search(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList getAll() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
