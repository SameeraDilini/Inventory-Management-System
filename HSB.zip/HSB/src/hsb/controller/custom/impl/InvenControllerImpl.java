/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.controller.custom.impl;

import hsb.controller.custom.InvenController;
import hsb.dto.FaultyDTO;
import hsb.dto.InvenDTO;
import hsb.service.ServiceFactory;
import hsb.service.custom.impl.InvenServiceImpl;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class InvenControllerImpl implements InvenController{

    @Override
    public boolean add(InvenDTO t) throws Exception {
        InvenServiceImpl invenServiceimpl=(InvenServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.INVEN);
        return invenServiceimpl.add(t);
        
    }

    @Override
    public boolean update(InvenDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(String id) throws Exception {
       InvenServiceImpl invenServiceimpl=(InvenServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.INVEN);
        return invenServiceimpl.delete(id);
    }

    @Override
    public InvenDTO getByID(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<InvenDTO> search(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<InvenDTO> getAll() throws Exception {
        InvenServiceImpl invenServiceimpl=(InvenServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.INVEN);
        return invenServiceimpl.getAll();    }

    @Override
    public boolean add_faulty(FaultyDTO dto) throws Exception {
        InvenServiceImpl invenServiceimpl=(InvenServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.INVEN);
        return invenServiceimpl.add_faulty(dto);
    }

    @Override
    public boolean check_repetition(String id) throws Exception {
       InvenServiceImpl invenServiceimpl=(InvenServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.INVEN);
        return invenServiceimpl.check_repetition(id);
    }


    
}
