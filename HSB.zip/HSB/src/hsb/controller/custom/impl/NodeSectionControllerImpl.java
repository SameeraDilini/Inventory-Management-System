/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.controller.custom.impl;

import hsb.controller.custom.NodeSectionController;
import hsb.dto.Node_FaultyDTO;
import hsb.dto.SpareDTO;
import hsb.dto.bsc_DTO;
import hsb.service.ServiceFactory;
import hsb.service.custom.impl.NodeServiceImpl;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class NodeSectionControllerImpl implements NodeSectionController{

    @Override
    public boolean add(bsc_DTO t) throws Exception {
        NodeServiceImpl nodeServiceimpl=(NodeServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.NODE);
        return nodeServiceimpl.add(t);
        
        
    }

    @Override
    public boolean update(bsc_DTO t) throws Exception {
       NodeServiceImpl nodeServiceimpl=(NodeServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.NODE);
        return nodeServiceimpl.update(t);
    }

    @Override
    public boolean delete(String id) throws Exception {
        NodeServiceImpl nodeServiceimpl=(NodeServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.NODE);
        return nodeServiceimpl.delete(id);
    }

    @Override
    public bsc_DTO getByID(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<bsc_DTO> search(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<bsc_DTO> getAll() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
    @Override
    public SpareDTO getSparebyId(String id) throws Exception {
        NodeServiceImpl nodeServiceimpl=(NodeServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.NODE);
        return nodeServiceimpl.getSparebyId(id);
    }

    @Override
    public bsc_DTO getById(String id) throws Exception {
        NodeServiceImpl nodeServiceimpl=(NodeServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.NODE);
        return nodeServiceimpl.getById(id);    }

    @Override
    public ArrayList<bsc_DTO> getAllNodes() throws Exception {
        NodeServiceImpl nodeServiceimpl=(NodeServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.NODE);
        return nodeServiceimpl.getAllNodes();    }

    @Override
    public boolean check_repetition(String id) throws Exception {
        NodeServiceImpl nodeServiceimpl=(NodeServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.NODE);
        return nodeServiceimpl.check_repetition(id);
    }
    
}
