/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.controller.custom.impl;

import hsb.controller.custom.HistoryController;
import hsb.dto.HistoryDTO;
import hsb.dto.TransactionDTO;
import hsb.service.ServiceFactory;
import hsb.service.custom.impl.HistoryServiceImpl;
import hsb.service.custom.impl.InvenServiceImpl;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class HistoryControllerImpl implements HistoryController{

    @Override
    public boolean add(TransactionDTO t) throws Exception {
       HistoryServiceImpl historyServiceimpl=(HistoryServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.HISTORY);
        return historyServiceimpl.add(t);
    }

    @Override
    public boolean update(TransactionDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public TransactionDTO getByID(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<TransactionDTO> search(String id) throws Exception {
         HistoryServiceImpl historyServiceimpl=(HistoryServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.HISTORY);
        return historyServiceimpl.search(id);
    }

    @Override
    public ArrayList<TransactionDTO> getAll() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<TransactionDTO> search_by_location(String id) throws Exception {
         HistoryServiceImpl historyServiceimpl=(HistoryServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.HISTORY);
        return historyServiceimpl.search_by_location(id);
    }

    @Override
    public ArrayList<TransactionDTO> search_by_board(HistoryDTO dto) throws Exception {
        HistoryServiceImpl historyServiceimpl=(HistoryServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.HISTORY);
        return historyServiceimpl.search_by_board(dto);
    }
    
}
