/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.controller.custom.impl;

import hsb.business.BussinessFactory;
import hsb.controller.custom.FaultsController;
import hsb.dao.DAOFactory;
import hsb.dao.mysql.DAOmysqlfactory;
import hsb.dto.FaultyDTO;
import hsb.service.ServiceFactory;
import hsb.service.custom.impl.FaultsServiceImpl;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class FaultsControllerImpl implements FaultsController{

    @Override
    public boolean add(FaultyDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean update(FaultyDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(String id) throws Exception {
        FaultsServiceImpl faultsservice=(FaultsServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.FAULTS);
        return faultsservice.delete(id);
    }

    @Override
    public FaultyDTO getByID(String id) throws Exception {
        FaultsServiceImpl faultsservice=(FaultsServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.FAULTS);
        return faultsservice.getByID(id);
    }

    @Override
    public ArrayList<FaultyDTO> search(String id) throws Exception {
        FaultsServiceImpl faultsservice=(FaultsServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.FAULTS);
        return faultsservice.search(id);
    }

    @Override
    public ArrayList<FaultyDTO> getAll() throws Exception {
        FaultsServiceImpl faultsservice=(FaultsServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.FAULTS);
        return faultsservice.getAll();
    }

    @Override
    public boolean check_repetition(String id) throws Exception {
        FaultsServiceImpl faultsservice=(FaultsServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.FAULTS);
        return faultsservice.check_repetition(id);
    }

    @Override
    public boolean add_acknowledgement(FaultyDTO dto) throws Exception {
       FaultsServiceImpl faultsservice=(FaultsServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.FAULTS);
        return faultsservice.add_acknowledgement(dto);
    }

    @Override
    public boolean check_repetition_ack(String id) throws Exception {
        FaultsServiceImpl faultsservice=(FaultsServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.FAULTS);
        return faultsservice.check_repetition_ack(id);
    }

    @Override
    public ArrayList<FaultyDTO> getAll_ack() throws Exception {
        FaultsServiceImpl faultsservice=(FaultsServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.FAULTS);
        return faultsservice.getAll_ack();
    }

    @Override
    public boolean adv_replacment(String id) throws Exception {
        FaultsServiceImpl faultsservice=(FaultsServiceImpl) ServiceFactory.getInstance().getService(ServiceFactory.ServicetType.FAULTS);
        return faultsservice.adv_replacment(id);
    }
    

    
}
