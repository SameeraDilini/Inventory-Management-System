/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.controller.custom;

import hsb.controller.SuperController;
import hsb.dto.Node_FaultyDTO;
import hsb.dto.SpareDTO;
import hsb.dto.bsc_DTO;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public interface NodeSectionController extends SuperController<bsc_DTO, String>{
    bsc_DTO getById(String id) throws Exception;
    SpareDTO getSparebyId(String id) throws Exception;
    ArrayList<bsc_DTO> getAllNodes() throws Exception;
    boolean check_repetition(String id) throws Exception;
}
