/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.controller.custom;

import hsb.controller.SuperController;
import hsb.dto.FaultyDTO;
import hsb.dto.InvenDTO;

/**
 *
 * @author user
 */
public interface InvenController extends SuperController<InvenDTO, String>{
    boolean add_faulty(FaultyDTO dto) throws Exception;
    boolean check_repetition(String id) throws Exception;
}
