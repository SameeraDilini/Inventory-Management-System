/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.controller;

import hsb.controller.custom.UserController;
import hsb.controller.custom.impl.FaultsControllerImpl;
import hsb.controller.custom.impl.HistoryControllerImpl;
import hsb.controller.custom.impl.InvenControllerImpl;
import hsb.controller.custom.impl.LoginControllerImpl;
import hsb.controller.custom.impl.NodeSectionControllerImpl;
import hsb.controller.custom.impl.UserControllerImpl;
import hsb.view.controller.NodeViewController;


/**
 *
 * @author user
 */
public class ControllerFactory {
    
    private static ControllerFactory factory;
    private LoginControllerImpl loginCotrollerImpl;
    private UserControllerImpl usercontrollerimpl;
    private NodeSectionControllerImpl nodecontrollerimpl;
    private InvenControllerImpl invencontrollerimpl;
    private FaultsControllerImpl faultscontrollerimpl;
    private HistoryControllerImpl historycontrollerimpl;
    public enum ControllerType{
    
        LOGIN,USER,NODE,INVEN,FAULTS,HISTORY
    
    }
    
    public ControllerFactory(){
    
        loginCotrollerImpl=new LoginControllerImpl();
        usercontrollerimpl=new UserControllerImpl();
        nodecontrollerimpl=new NodeSectionControllerImpl();
        invencontrollerimpl=new InvenControllerImpl();
        faultscontrollerimpl=new FaultsControllerImpl();
        historycontrollerimpl=new HistoryControllerImpl();
    }
    
    
    public static ControllerFactory getInstance(){
    
        if(factory==null){
        
            factory=new ControllerFactory();
        
        }
    
        return factory;
    }
    
    public SuperController getController(ControllerType type){
    
        switch(type){
        
            case LOGIN:
                return loginCotrollerImpl;
            case USER:
                return usercontrollerimpl;
            case NODE:
                return nodecontrollerimpl;
            case INVEN:
                return invencontrollerimpl;
            case FAULTS:
                return faultscontrollerimpl;
            case HISTORY:
                return historycontrollerimpl;
            default:
                return null;
        
        }
    
    }
    
    
}
