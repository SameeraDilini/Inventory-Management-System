/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.model;

import java.util.Date;

/**
 *
 * @author user
 */
public class history_tablemodel {
    private String Serial_No;
    private String BSC_Location;
    private String Spare_Location;
    private String Sub_Inventory;
    private String Locator;
    private String Board_Name;
    private String Replacement;
    private String Replaced_Serial_No;
    private String Added_By;
    private Date Added_Date;
    private String Comment;
    
    
    
    public history_tablemodel(String Serial_No,
                                 String BSC_Location,
                                 String Spare_Location,
                                 String Sub_Inventory,
                                 String Locator,
                                 String Board_Name,
                                 String Replacement,
                                 String Replaced_Serial_No,
                                 Date Added_Date,
                                 String Added_By,
                                 String Comment){
    
    
        this.Serial_No=Serial_No;
        this.BSC_Location=BSC_Location;
        this.Spare_Location=Spare_Location;
        this.Sub_Inventory=Sub_Inventory;
        this.Locator=Locator;
        this.Board_Name=Board_Name;
        this.Replacement=Replacement;
        this.Replaced_Serial_No=Replaced_Serial_No;       
        this.Added_By=Added_By;
        this.Added_Date=Added_Date;
        this.Comment=Comment;
    
    }

    /**
     * @return the Serial_No
     */
    public String getSerial_No() {
        return Serial_No;
    }

    /**
     * @param Serial_No the Serial_No to set
     */
    public void setSerial_No(String Serial_No) {
        this.Serial_No = Serial_No;
    }

    /**
     * @return the Sub_Inventory
     */
    public String getSub_Inventory() {
        return Sub_Inventory;
    }

    /**
     * @param Sub_Inventory the Sub_Inventory to set
     */
    public void setSub_Inventory(String Sub_Inventory) {
        this.Sub_Inventory = Sub_Inventory;
    }

    /**
     * @return the Locator
     */
    public String getLocator() {
        return Locator;
    }

    /**
     * @param Locator the Locator to set
     */
    public void setLocator(String Locator) {
        this.Locator = Locator;
    }

    /**
     * @return the Board_Name
     */
    public String getBoard_Name() {
        return Board_Name;
    }

    /**
     * @param Board_Name the Board_Name to set
     */
    public void setBoard_Name(String Board_Name) {
        this.Board_Name = Board_Name;
    }

    /**
     * @return the Replacement
     */
    public String getReplacement() {
        return Replacement;
    }

    /**
     * @param Replacement the Replacement to set
     */
    public void setReplacement(String Replacement) {
        this.Replacement = Replacement;
    }

    /**
     * @return the Replaced_Serial_No
     */
    public String getReplaced_Serial_No() {
        return Replaced_Serial_No;
    }

    /**
     * @param Replaced_Serial_No the Replaced_Serial_No to set
     */
    public void setReplaced_Serial_No(String Replaced_Serial_No) {
        this.Replaced_Serial_No = Replaced_Serial_No;
    }

    /**
     * @return the Added_By
     */
    public String getAdded_By() {
        return Added_By;
    }

    /**
     * @param Added_By the Added_By to set
     */
    public void setAdded_By(String Added_By) {
        this.Added_By = Added_By;
    }

    /**
     * @return the Added_Date
     */
    public Date getAdded_Date() {
        return Added_Date;
    }

    /**
     * @param Added_Date the Added_Date to set
     */
    public void setAdded_Date(Date Added_Date) {
        this.Added_Date = Added_Date;
    }

    /**
     * @return the Comment
     */
    public String getComment() {
        return Comment;
    }

    /**
     * @param Comment the Comment to set
     */
    public void setComment(String Comment) {
        this.Comment = Comment;
    }

    /**
     * @return the BSC_Location
     */
    public String getBSC_Location() {
        return BSC_Location;
    }

    /**
     * @param BSC_Location the BSC_Location to set
     */
    public void setBSC_Location(String BSC_Location) {
        this.BSC_Location = BSC_Location;
    }

    /**
     * @return the Spare_Location
     */
    public String getSpare_Location() {
        return Spare_Location;
    }

    /**
     * @param Spare_Location the Spare_Location to set
     */
    public void setSpare_Location(String Spare_Location) {
        this.Spare_Location = Spare_Location;
    }

   
    
    
    
    
}
