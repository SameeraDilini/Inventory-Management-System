/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.model;

import java.util.Date;
import javafx.scene.control.CheckBox;

/**
 *
 * @author user
 */
public class faulty_tablemodel {
    private String Serial_Number;
    private String Vendor;
    private String ERP_Item_Code;
    private String Board_Name;
    private Date Added_Date;
    private String Added_By;
    private String Acknowledgement;
    private Date Acknowledged_Date;
    
    
    public faulty_tablemodel(
            String Serial_Number,
            String Vendor,
            String ERP_Item_Code,
            String Board_Name,
            Date Added_Date,
            String Added_By
            )
    {
    
        this.Serial_Number=Serial_Number;
        this.Vendor=Vendor;
        this.ERP_Item_Code=ERP_Item_Code;
        this.Board_Name=Board_Name;
        this.Added_Date=Added_Date;
        this.Added_By=Added_By;
        
        
    
    }

    public faulty_tablemodel(String Serial_Number, String Vendor, String ERP_Item_Code, String Board_Name, Date Added_Date, String Added_By, String Acknowledgement) {
        this.Serial_Number = Serial_Number;
        this.Vendor = Vendor;
        this.ERP_Item_Code = ERP_Item_Code;
        this.Board_Name = Board_Name;
        this.Added_Date = Added_Date;
        this.Added_By = Added_By;
        this.Acknowledgement = Acknowledgement;
    }

    public faulty_tablemodel(String Serial_Number, String Vendor, String ERP_Item_Code, String Board_Name, Date Added_Date, String Added_By, Date Acknowledged_Date) {
        this.Serial_Number = Serial_Number;
        this.Vendor = Vendor;
        this.ERP_Item_Code = ERP_Item_Code;
        this.Board_Name = Board_Name;
        this.Added_Date = Added_Date;
        this.Added_By = Added_By;
        this.Acknowledged_Date = Acknowledged_Date;
    }

    

    

    

    /**
     * @return the Serial_Number
     */
    public String getSerial_Number() {
        return Serial_Number;
    }

    /**
     * @param Serial_Number the Serial_Number to set
     */
    public void setSerial_Number(String Serial_Number) {
        this.Serial_Number = Serial_Number;
    }

    /**
     * @return the Vendor
     */
    public String getVendor() {
        return Vendor;
    }

    /**
     * @param Vendor the Vendor to set
     */
    public void setVendor(String Vendor) {
        this.Vendor = Vendor;
    }

    /**
     * @return the ERP_Item_Code
     */
    public String getERP_Item_Code() {
        return ERP_Item_Code;
    }

    /**
     * @param ERP_Item_Code the ERP_Item_Code to set
     */
    public void setERP_Item_Code(String ERP_Item_Code) {
        this.ERP_Item_Code = ERP_Item_Code;
    }

    /**
     * @return the Board_Name
     */
    public String getBoard_Name() {
        return Board_Name;
    }

    /**
     * @param Board_Name the Board_Name to set
     */
    public void setBoard_Name(String Board_Name) {
        this.Board_Name = Board_Name;
    }

    /**
     * @return the Added_Date
     */
    public Date getAdded_Date() {
        return Added_Date;
    }

    /**
     * @param Added_Date the Added_Date to set
     */
    public void setAdded_Date(Date Added_Date) {
        this.Added_Date = Added_Date;
    }

    /**
     * @return the Added_By
     */
    public String getAdded_By() {
        return Added_By;
    }

    /**
     * @param Added_By the Added_By to set
     */
    public void setAdded_By(String Added_By) {
        this.Added_By = Added_By;
    }

    /**
     * @return the Acknowledgement
     */
    public String getAcknowledgement() {
        return Acknowledgement;
    }

    /**
     * @param Acknowledgement the Acknowledgement to set
     */
    public void setAcknowledgement(String Acknowledgement) {
        this.Acknowledgement = Acknowledgement;
    }

    /**
     * @return the Acknowledged_Date
     */
    public Date getAcknowledged_Date() {
        return Acknowledged_Date;
    }

    /**
     * @param Acknowledged_Date the Acknowledged_Date to set
     */
    public void setAcknowledged_Date(Date Acknowledged_Date) {
        this.Acknowledged_Date = Acknowledged_Date;
    }

    

    

    

    

    
}
