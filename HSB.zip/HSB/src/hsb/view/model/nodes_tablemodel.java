/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.model;

import java.util.Date;

/**
 *
 * @author user
 */
public class nodes_tablemodel {
    private String Serial_No;
    private String BSC_Name;
    private String board_name;
    private String Rack;
    private String Shelf;
    private String Slot;
    private String manufac_date;
    private String ERP_Item_Code;
    private String erp_no;
    private String Vendor;
    private String Physical_Name;
    private String Logical_Name;
    private Date Date;
    private String Added_by;
    private String Comment;
    private String Added_By;
    private Date Added_Date;
    private String ERP_Name;
    
    
    public nodes_tablemodel(
            String Serial_No,
            String Vendor,
            String BSC_Name,
            String Physical_Name,
            String Logical_Name,
            String ERP_Item_Code,
            String ERP_Name,
            String Rack,
            String Shelf,
            String Slot,String Added_By,
            Date Added_Date,
            String Comment
            ){
    
        this.Serial_No=Serial_No;
        this.Vendor=Vendor;
        this.BSC_Name=BSC_Name;
        this.Physical_Name=Physical_Name;
        this.Logical_Name=Logical_Name;
        this.ERP_Item_Code=ERP_Item_Code;
        this.ERP_Name=ERP_Name;
        this.Rack=Rack;
        this.Shelf=Shelf;
        this.Slot=Slot;
        this.Added_By=Added_By;
        this.Added_Date=Added_Date;
        this.Comment=Comment;

    }

    /**
     * @return the Serial_No
     */
    public String getSerial_No() {
        return Serial_No;
    }

    /**
     * @param Serial_No the Serial_No to set
     */
    public void setSerial_No(String Serial_No) {
        this.Serial_No = Serial_No;
    }

    /**
     * @return the BSC_Name
     */
    public String getBSC_Name() {
        return BSC_Name;
    }

    /**
     * @param BSC_Name the BSC_Name to set
     */
    public void setBSC_Name(String BSC_Name) {
        this.BSC_Name = BSC_Name;
    }

    /**
     * @return the board_name
     */
    public String getBoard_name() {
        return board_name;
    }

    /**
     * @param board_name the board_name to set
     */
    public void setBoard_name(String board_name) {
        this.board_name = board_name;
    }

    /**
     * @return the Rack
     */
    public String getRack() {
        return Rack;
    }

    /**
     * @param Rack the Rack to set
     */
    public void setRack(String Rack) {
        this.Rack = Rack;
    }

    /**
     * @return the Shelf
     */
    public String getShelf() {
        return Shelf;
    }

    /**
     * @param Shelf the Shelf to set
     */
    public void setShelf(String Shelf) {
        this.Shelf = Shelf;
    }

    /**
     * @return the Slot
     */
    public String getSlot() {
        return Slot;
    }

    /**
     * @param Slot the Slot to set
     */
    public void setSlot(String Slot) {
        this.Slot = Slot;
    }

    /**
     * @return the manufac_date
     */
    public String getManufac_date() {
        return manufac_date;
    }

    /**
     * @param manufac_date the manufac_date to set
     */
    public void setManufac_date(String manufac_date) {
        this.manufac_date = manufac_date;
    }

    /**
     * @return the ERP_Item_Code
     */
    public String getERP_Item_Code() {
        return ERP_Item_Code;
    }

    /**
     * @param ERP_Item_Code the ERP_Item_Code to set
     */
    public void setERP_Item_Code(String ERP_Item_Code) {
        this.ERP_Item_Code = ERP_Item_Code;
    }

    /**
     * @return the erp_no
     */
    public String getErp_no() {
        return erp_no;
    }

    /**
     * @param erp_no the erp_no to set
     */
    public void setErp_no(String erp_no) {
        this.erp_no = erp_no;
    }

    /**
     * @return the Vendor
     */
    public String getVendor() {
        return Vendor;
    }

    /**
     * @param Vendor the Vendor to set
     */
    public void setVendor(String Vendor) {
        this.Vendor = Vendor;
    }

    /**
     * @return the Physical_Name
     */
    public String getPhysical_Name() {
        return Physical_Name;
    }

    /**
     * @param Physical_Name the Physical_Name to set
     */
    public void setPhysical_Name(String Physical_Name) {
        this.Physical_Name = Physical_Name;
    }

    /**
     * @return the Logical_Name
     */
    public String getLogical_Name() {
        return Logical_Name;
    }

    /**
     * @param Logical_Name the Logical_Name to set
     */
    public void setLogical_Name(String Logical_Name) {
        this.Logical_Name = Logical_Name;
    }

    /**
     * @return the Date
     */
    public Date getDate() {
        return Date;
    }

    /**
     * @param Date the Date to set
     */
    public void setDate(Date Date) {
        this.Date = Date;
    }

    /**
     * @return the Added_by
     */
    public String getAdded_by() {
        return Added_by;
    }

    /**
     * @param Added_by the Added_by to set
     */
    public void setAdded_by(String Added_by) {
        this.Added_by = Added_by;
    }

    /**
     * @return the Comment
     */
    public String getComment() {
        return Comment;
    }

    /**
     * @param Comment the Comment to set
     */
    public void setComment(String Comment) {
        this.Comment = Comment;
    }

    /**
     * @return the Added_By
     */
    public String getAdded_By() {
        return Added_By;
    }

    /**
     * @param Added_By the Added_By to set
     */
    public void setAdded_By(String Added_By) {
        this.Added_By = Added_By;
    }

    /**
     * @return the Added_Date
     */
    public Date getAdded_Date() {
        return Added_Date;
    }

    /**
     * @param Added_Date the Added_Date to set
     */
    public void setAdded_Date(Date Added_Date) {
        this.Added_Date = Added_Date;
    }

    /**
     * @return the ERP_Name
     */
    public String getERP_Name() {
        return ERP_Name;
    }

    /**
     * @param ERP_Name the ERP_Name to set
     */
    public void setERP_Name(String ERP_Name) {
        this.ERP_Name = ERP_Name;
    }

    

    
}
