/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.model;

import java.util.Date;

/**
 *
 * @author user
 */
public class spare_tablemodel {
    private String Serial_Number;
    private String Vendor;
    private String Sub_Inventory;
    private String Locator;
    private String Location;
    private Date Added_Date;
    private String Added_By;
    private String ERP_Item_Code;
    private String ERP_Number;
    private String Board_Name;
    private Date Manufactured_Date;



 public spare_tablemodel(
             String Serial_Number,
             String Vendor,
             String Board_Name,
             String Sub_Inventory,
             String Locator,
             String Location,
             Date Manufactured_Date,
             String ERP_Item_Code,
             String ERP_Number,
             String Added_By,
             Date Added_Date
            
            ){
    
        this.Serial_Number=Serial_Number;
        this.Vendor=Vendor;
        this.Sub_Inventory=Sub_Inventory;
        this.Locator=Locator;
        this.Location=Location;
        this.Added_Date=Added_Date;
        this.Added_By=Added_By;
        this.ERP_Item_Code=ERP_Item_Code;
        this.ERP_Number=ERP_Number;
        this.Board_Name=Board_Name;
        this.Manufactured_Date=Manufactured_Date;

    }

    /**
     * @return the Serial_Number
     */
    public String getSerial_Number() {
        return Serial_Number;
    }

    /**
     * @param Serial_Number the Serial_Number to set
     */
    public void setSerial_Number(String Serial_Number) {
        this.Serial_Number = Serial_Number;
    }

    /**
     * @return the Vendor
     */
    public String getVendor() {
        return Vendor;
    }

    /**
     * @param Vendor the Vendor to set
     */
    public void setVendor(String Vendor) {
        this.Vendor = Vendor;
    }

    /**
     * @return the Sub_Inventory
     */
    public String getSub_Inventory() {
        return Sub_Inventory;
    }

    /**
     * @param Sub_Inventory the Sub_Inventory to set
     */
    public void setSub_Inventory(String Sub_Inventory) {
        this.Sub_Inventory = Sub_Inventory;
    }

    /**
     * @return the Locator
     */
    public String getLocator() {
        return Locator;
    }

    /**
     * @param Locator the Locator to set
     */
    public void setLocator(String Locator) {
        this.Locator = Locator;
    }

    /**
     * @return the Location
     */
    public String getLocation() {
        return Location;
    }

    /**
     * @param Location the Location to set
     */
    public void setLocation(String Location) {
        this.Location = Location;
    }

    

    /**
     * @return the Added_By
     */
    public String getAdded_By() {
        return Added_By;
    }

    /**
     * @param Added_By the Added_By to set
     */
    public void setAdded_By(String Added_By) {
        this.Added_By = Added_By;
    }

    /**
     * @return the ERP_Item_Code
     */
    public String getERP_Item_Code() {
        return ERP_Item_Code;
    }

    /**
     * @param ERP_Item_Code the ERP_Item_Code to set
     */
    public void setERP_Item_Code(String ERP_Item_Code) {
        this.ERP_Item_Code = ERP_Item_Code;
    }

    /**
     * @return the ERP_Number
     */
    public String getERP_Number() {
        return ERP_Number;
    }

    /**
     * @param ERP_Number the ERP_Number to set
     */
    public void setERP_Number(String ERP_Number) {
        this.ERP_Number = ERP_Number;
    }

    /**
     * @return the Board_Name
     */
    public String getBoard_Name() {
        return Board_Name;
    }

    /**
     * @param Board_Name the Board_Name to set
     */
    public void setBoard_Name(String Board_Name) {
        this.Board_Name = Board_Name;
    }

    /**
     * @return the Manufactured_Date
     */
    public Date getManufactured_Date() {
        return Manufactured_Date;
    }

    /**
     * @param Manufactured_Date the Manufactured_Date to set
     */
    public void setManufactured_Date(Date Manufactured_Date) {
        this.Manufactured_Date = Manufactured_Date;
    }

    /**
     * @return the Added_Date
     */
    public Date getAdded_Date() {
        return Added_Date;
    }

    /**
     * @param Added_Date the Added_Date to set
     */
    public void setAdded_Date(Date Added_Date) {
        this.Added_Date = Added_Date;
    }
}
