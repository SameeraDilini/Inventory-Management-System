/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.model;

import java.util.Date;

/**
 *
 * @author user
 */
public class home_tablemodel {
    private String Serial_No;
    private String Board;
    private Date Faulty_List_Added_Date;
    private String User;
    private String Acknowledged_Date;
    private String Ack_added_by;
    
    
    
    
    public home_tablemodel(String Serial_No,String Board,Date Faulty_List_Added_Date,String User){
    
        this.Serial_No=Serial_No;
        this.Board=Board;
        this.Faulty_List_Added_Date=Faulty_List_Added_Date;
        this.User=User;
        
    
    }

    public home_tablemodel(String Serial_No, String Board, Date Faulty_List_Added_Date, String User, String Acknowledged_Date, String Ack_added_by) {
        this.Serial_No = Serial_No;
        this.Board = Board;
        this.Faulty_List_Added_Date = Faulty_List_Added_Date;
        this.User = User;
        this.Acknowledged_Date = Acknowledged_Date;
        this.Ack_added_by = Ack_added_by;
    }
    
    

    public home_tablemodel(String Serial_No, String Board, Date Faulty_List_Added_Date, String User, String Acknowledged_Date) {
        this.Serial_No = Serial_No;
        this.Board = Board;
        this.Faulty_List_Added_Date = Faulty_List_Added_Date;
        this.User = User;
        this.Acknowledged_Date = Acknowledged_Date;
    }
    
    

    /**
     * @return the Board
     */
    public String getBoard() {
        return Board;
    }

    /**
     * @param Board the Board to set
     */
    public void setBoard(String Board) {
        this.Board = Board;
    }

    

    /**
     * @return the User
     */
    public String getUser() {
        return User;
    }

    /**
     * @param User the User to set
     */
    public void setUser(String User) {
        this.User = User;
    }

    /**
     * @return the Serial_No
     */
    public String getSerial_No() {
        return Serial_No;
    }

    /**
     * @param Serial_No the Serial_No to set
     */
    public void setSerial_No(String Serial_No) {
        this.Serial_No = Serial_No;
    }

    

    /**
     * @return the Faulty_List_Added_Date
     */
    public Date getFaulty_List_Added_Date() {
        return Faulty_List_Added_Date;
    }

    /**
     * @param Faulty_List_Added_Date the Faulty_List_Added_Date to set
     */
    public void setFaulty_List_Added_Date(Date Faulty_List_Added_Date) {
        this.Faulty_List_Added_Date = Faulty_List_Added_Date;
    }

    /**
     * @return the Acknowledged_Date
     */
    public String getAcknowledged_Date() {
        return Acknowledged_Date;
    }

    /**
     * @param Acknowledged_Date the Acknowledged_Date to set
     */
    public void setAcknowledged_Date(String Acknowledged_Date) {
        this.Acknowledged_Date = Acknowledged_Date;
    }

    /**
     * @return the Ack_added_by
     */
    public String getAck_added_by() {
        return Ack_added_by;
    }

    /**
     * @param Ack_added_by the Ack_added_by to set
     */
    public void setAck_added_by(String Ack_added_by) {
        this.Ack_added_by = Ack_added_by;
    }

    

    
}
