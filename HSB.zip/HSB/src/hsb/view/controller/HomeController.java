/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.util.Duration;



/**
 * FXML Controller class
 *
 * @author user
 */
public class HomeController implements Initializable {

    
    @FXML
    public BorderPane border_pane;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        try {
            Parent side_bar = FXMLLoader.load(getClass().getResource("/hsb/view/ui/side_nav_home.fxml"));
            Parent header = FXMLLoader.load(getClass().getResource("/hsb/view/ui/home_header_bar.fxml"));
            Parent content = FXMLLoader.load(getClass().getResource("/hsb/view/ui/Home_Menu.fxml"));
//            Parent right_bar = FXMLLoader.load(getClass().getResource("/hsb/view/ui/home_right_nav.fxml"));
            Parent footer = FXMLLoader.load(getClass().getResource("/hsb/view/ui/home_footer.fxml"));
            border_pane.setLeft(side_bar);
            border_pane.setCenter(content);
//            border_pane.setRight(right_bar);
//            border_pane.setTop(header);
            border_pane.setBottom(footer);
            
//            Notifications notifys=Notifications.create()
//                    .title("Hello")
//                    .text("World")
//                    .graphic(null)
//                    .hideAfter(Duration.seconds(10))
//                    .position(Pos.BOTTOM_RIGHT)
//                    .onAction(new EventHandler<ActionEvent>() {
//                @Override
//                public void handle(ActionEvent event) {
//                    System.out.println("Notifications ");
//                }
//            });
            
//            notifys.showConfirm();
           
        } catch (IOException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }    
    
}
