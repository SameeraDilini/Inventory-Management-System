/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import hsb.controller.ControllerFactory;
import hsb.controller.custom.FaultsController;
import hsb.controller.custom.HistoryController;
import hsb.controller.custom.InvenController;
import hsb.controller.custom.NodeSectionController;
import hsb.controller.custom.UserController;
import hsb.dto.FaultyDTO;
import hsb.dto.InvenDTO;
import hsb.dto.SpareDTO;
import hsb.dto.TransactionDTO;
import hsb.dto.bsc_DTO;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author user
 */
public class Spare_faultyController implements Initializable {

    private TextField txt_serial_no;
   
    
    private FaultyDTO faulty;
    
    @FXML
    private Label lbl_check_serialno;
    @FXML
    private Label lbl_vendor;
    @FXML
    private Label lbl_erp_item_code;
    @FXML
    private Label lbl_board_name;
    @FXML
    private Button btn_add;
    @FXML
    private ComboBox<String> cmb_serial_no;
    ArrayList<String> arraylist;
    
//    private FaultyDTO faulty;

    /**
     * Initializes the controller class.
     */
    
    
    public Spare_faultyController(){
    
        
    
    
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            btn_add.setVisible(false);
            arraylist=new ArrayList<>();
            InvenController spcontroller=(InvenController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.INVEN);
            ArrayList<InvenDTO> spares = spcontroller.getAll();
            
            spares.forEach((dto_sp) -> {
                arraylist.add(dto_sp.getSerial_no());
            });
            
            cmb_serial_no.setEditable(true);
            ObservableList<String> items_sp = FXCollections.observableArrayList(arraylist);
            
            FilteredList<String> filteredItems_sp = new FilteredList<String>(items_sp, p_sp -> true);
            cmb_serial_no.getEditor().textProperty().addListener((obs_sp, oldValue_sp, newValue_sp) -> {
                final TextField editor_sp = cmb_serial_no.getEditor();
                final String selected_sp = cmb_serial_no.getSelectionModel().getSelectedItem();
                
                // This needs run on the GUI thread to avoid the error described
                // here: https://bugs.openjdk.java.net/browse/JDK-8081700.
                Platform.runLater(() -> {
                    // If the no item in the list is selected or the selected item
                    // isn't equal to the current input, we refilter the list.
                    if (selected_sp == null || !selected_sp.equals(editor_sp.getText())) {
                        filteredItems_sp.setPredicate(itemsp -> {
                            // We return true for any items that starts with the
                            // same letters as the input. We use toUpperCase to
                            // avoid case sensitivity.
                            if (itemsp.toUpperCase().startsWith(newValue_sp.toUpperCase())) {
                                return true;
                            } else {
                                return false;
                            }
                        });
                    }
                });
            });
            
            cmb_serial_no.setItems(filteredItems_sp);
            cmb_serial_no.valueProperty().addListener(new ChangeListener<String>() {
                @Override
                public void changed(ObservableValue<? extends String> observablesp, String oldValuesp, String newValuesp) {
                    if(cmb_serial_no.getSelectionModel().getSelectedItem()!=null){
                        
                        try {
                            NodeSectionController controller=(NodeSectionController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
                            SpareDTO spare=controller.getSparebyId(cmb_serial_no.getSelectionModel().getSelectedItem());
                            
                            if(spare!=null){
                                
                                lbl_vendor.setText(spare.getVendor());
                                lbl_board_name.setText(spare.getBoard_name());
                                lbl_erp_item_code.setText(spare.getErp_item_code());
                                
                                btn_add.setVisible(true);
                                
                            }
                        } catch (Exception ex) {
                            Logger.getLogger(Node_f_sController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            });
        } catch (Exception ex) {
            Logger.getLogger(Spare_faultyController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void add_faulty_list(MouseEvent event) throws Exception {
        
        if(cmb_serial_no.getSelectionModel().getSelectedItem()==null){
        
        lbl_check_serialno.setText("* Please Fill the Serial No");
//        txt_serial_no.setFocusTraversable(true);
        
        }else{
            FaultsController invencontroller=(FaultsController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.FAULTS);
            boolean rep=invencontroller.check_repetition(cmb_serial_no.getSelectionModel().getSelectedItem());    

        if(rep==true){
        lbl_check_serialno.setText("* Already added");
        }else{
        lbl_check_serialno.setText("");
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate localDate = LocalDate.now();
        Date date = java.sql.Date.valueOf(localDate);
        
        
        UserController controller_user=(UserController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.USER);
        String user=controller_user.getLogged_username();
        
                
        
        
            faulty=new FaultyDTO(cmb_serial_no.getSelectionModel().getSelectedItem(),lbl_vendor.getText(),lbl_erp_item_code.getText(),lbl_board_name.getText(),date,user);
            InvenController controller=(InvenController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.INVEN);
            Boolean check=controller.add_faulty(faulty);
            
            boolean spare_delete=controller.delete(cmb_serial_no.getSelectionModel().getSelectedItem());
            
            TransactionDTO transaction=new TransactionDTO(cmb_serial_no.getSelectionModel().getSelectedItem(),
                                                        "",
                                                        "",
                                                        "",
                                                        "",
                                                        lbl_board_name.getText().toUpperCase(),
                                                        "",
                                                        "",
                                                        date,user,"Added to Faulty List from Spare List");
        
        
        HistoryController history_controller=(HistoryController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.HISTORY);
        boolean history=history_controller.add(transaction);
        
        System.out.println(spare_delete);

        System.out.println(date);
        
        if(check==true && spare_delete==true && history==true){
            
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Information Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Successfully added!");

            alert.showAndWait();
            
           ArrayList<String> arraylist2=new ArrayList<>();
            InvenController spcontroller2=(InvenController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.INVEN);
            ArrayList<InvenDTO> spares2 = spcontroller2.getAll();
            
            spares2.forEach((dto_sp) -> {
                arraylist2.add(dto_sp.getSerial_no());
            });
            
            cmb_serial_no.setEditable(true);
            ObservableList<String> items_sp2 = FXCollections.observableArrayList(arraylist2);
            cmb_serial_no.setItems(items_sp2);
            cmb_serial_no.valueProperty().addListener(new ChangeListener<String>() {
                @Override
                public void changed(ObservableValue<? extends String> observablesp, String oldValuesp, String newValuesp) {
                    if(cmb_serial_no.getSelectionModel().getSelectedItem()!=null){
                        
                        try {
                            NodeSectionController controller=(NodeSectionController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
                            SpareDTO spare=controller.getSparebyId(cmb_serial_no.getSelectionModel().getSelectedItem());
                            
                            if(spare!=null){
                                
                                lbl_vendor.setText(spare.getVendor());
                                lbl_board_name.setText(spare.getBoard_name());
                                lbl_erp_item_code.setText(spare.getErp_item_code());
                                
                                btn_add.setVisible(true);
                                
                            }
                        } catch (Exception ex) {
                            Logger.getLogger(Node_f_sController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            });
            
            
           cmb_serial_no.getSelectionModel().clearSelection();
            lbl_board_name.setText("");
            lbl_vendor.setText("");
            lbl_erp_item_code.setText("");
            lbl_check_serialno.setText("");
            
            
        
        }
        else{
        
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, there was an error!");

            alert.showAndWait();
        
            cmb_serial_no.getSelectionModel().clearSelection();
            lbl_board_name.setText("");
            lbl_vendor.setText("");
            lbl_erp_item_code.setText("");
            lbl_check_serialno.setText("");
 
        }
    
    }
        
        }
    }

    
}
