/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import static hsb.main.main.stage;
import static hsb.view.controller.LoginViewController.primarystage;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author user
 */
public class Home_header_barController implements Initializable {
    
        /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    } 

    @FXML
    private void minimize(MouseEvent event) {
         primarystage.setIconified(true);
    }

    @FXML
    private void maximize(MouseEvent event) {
        primarystage.setMaximized(true);
    }

    @FXML
    private void close(MouseEvent event) {
        System.exit(0);
    }


   
//
//    private void minimize_app(MouseEvent event) {
//        primarystage.setIconified(true);
//    }
//
//    private void maximize_app(MouseEvent event) {
//        primarystage.setMaximized(true);
//    }
//
//    private void close_app(MouseEvent event) {
//        System.exit(0);
//    }
    
}
