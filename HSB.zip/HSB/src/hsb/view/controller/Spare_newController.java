/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import static com.sun.javafx.util.Utils.split;
import hsb.controller.ControllerFactory;
import hsb.controller.custom.FaultsController;
import hsb.controller.custom.HistoryController;
import hsb.controller.custom.InvenController;
import hsb.controller.custom.NodeSectionController;
import hsb.controller.custom.UserController;
import hsb.dto.InvenDTO;
import hsb.dto.TransactionDTO;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author user
 */
public class Spare_newController implements Initializable {

    @FXML
    private TextField txtserial_no;
    
    
    @FXML
    private TextField txt_sub_inven;
    
    @FXML
    private TextField txt_location;
    @FXML
    private TextField txt_item_code;
    @FXML
    private TextField txt_erp_num;
    @FXML
    private DatePicker txt_man_date;
    
    private InvenDTO inventory;
    @FXML
    private TextField txt_board_name;
    

    @FXML
    private Label lbl_check_location;
    @FXML
    private Label lbl_check_man_date;
    @FXML
    private TextField txt_Locator;
    @FXML
    private Label lbl_check_serialno;
    @FXML
    private TextField txt_comment;
    @FXML
    private Label lbl_check_man_date1;
    @FXML
    private ComboBox<String> cmb_vendor;

    private ArrayList<String> A_list;
    /**
     * Initializes the controller class.
     */
     
     
     public Spare_newController(){
     
//          pattern_spare = Pattern.compile(LOACTION_PATTERN);
     
     }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
                A_list=new ArrayList<>();
                A_list.add("ZTE");
                A_list.add("HUAWEI");

               ObservableList<String> list=FXCollections.observableArrayList(A_list);
                cmb_vendor.getItems().add(list.get(0));
                cmb_vendor.getItems().add(list.get(1));
                cmb_vendor.getSelectionModel().selectFirst();
    }    

    @FXML
    private void addSpare(MouseEvent event) throws Exception {
        
        if(txtserial_no.getText().equals("")){
        
        lbl_check_serialno.setText("* Please Fill the Serial No");
        txtserial_no.setFocusTraversable(true);
        
        }else{
            InvenController invencontroller=(InvenController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.INVEN);
            boolean rep=invencontroller.check_repetition(txtserial_no.getText());    

        if(rep==true){
        lbl_check_serialno.setText("* Aleardy added");
        }else{
        lbl_check_serialno.setText("");
           
        if(txt_man_date.getValue()!=null){
            
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate localDate = LocalDate.now();
        Date date = java.sql.Date.valueOf(localDate);
        String strDateFormat = "YYYY-MM-DD";
        DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
//        Date manufac_date=dateFormat.parse(txt_man_date.getText());
        Date manufac_date=java.sql.Date.valueOf(txt_man_date.getValue());
        if(manufac_date.after(date)){
         
             Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops !  You cannot add future dates!");

            alert.showAndWait();
         
         }else{
        
        
        
        
        UserController controller_user=(UserController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.USER);
        String user=controller_user.getLogged_username();
        
        if(txt_Locator.getText().equals("") || 
           txt_board_name.getText().equals("") || 
           txt_erp_num.getText().equals("") || 
           txt_item_code.getText().equals("") ||
           txt_location.getText().equals("") ||
           txt_sub_inven.getText().equals("")){
       
       
           Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops !  Fill all the fields!");

            alert.showAndWait();
       
       
       }else{
        
        inventory=new InvenDTO(txtserial_no.getText(),
                                cmb_vendor.getSelectionModel().getSelectedItem(),
                                txt_sub_inven.getText().toUpperCase(),
                                txt_Locator.getText().toUpperCase(),
                                txt_location.getText().toUpperCase(),
                                date,
                                user,
                                txt_item_code.getText().toUpperCase(),
                                txt_erp_num.getText().toUpperCase(),
                                txt_board_name.getText().toUpperCase(),
                                manufac_date,
                                txt_comment.getText()
                                );
        InvenController controller=(InvenController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.INVEN);
        Boolean check=controller.add(inventory);
        
//        FaultsController f_controller=(FaultsController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.FAULTS);
//        boolean fault=f_controller.delete(txtserial_no.getText());
        
        System.out.println(check);
        
        TransactionDTO transaction=new TransactionDTO(txtserial_no.getText(),
                                                        "",
                                                        txt_location.getText().toUpperCase(),
                                                        txt_sub_inven.getText().toUpperCase(),
                                                        txt_Locator.getText().toUpperCase(),
                                                        txt_board_name.getText().toUpperCase(),
                                                        "",
                                                        "",
                                                        date,user,"Added to Spare List");
        
        
        HistoryController history_controller=(HistoryController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.HISTORY);
        boolean history=history_controller.add(transaction);
        
        if(check==true && history==true){
            
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Successfully added!");

            alert.showAndWait();
            
            txtserial_no.clear();
            cmb_vendor.getSelectionModel().clearSelection();
            txt_board_name.clear();
            txt_sub_inven.clear();
            txt_Locator.clear();
            txt_location.clear();
            txt_item_code.clear();
            txt_erp_num.clear();
            txt_man_date.getEditor().clear();
            lbl_check_location.setText("");
            lbl_check_man_date.setText("");
            lbl_check_serialno.setText("");
            txt_comment.clear();
            
            
        
        }
        else{
        
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, there was an error!");

            alert.showAndWait();
        
            txtserial_no.clear();
            cmb_vendor.getSelectionModel().clearSelection();
            txt_board_name.clear();
            txt_sub_inven.clear();
            txt_Locator.clear();
            txt_location.clear();
            txt_item_code.clear();
            txt_erp_num.clear();
            txt_man_date.getEditor().clear();
            lbl_check_location.setText("");
            lbl_check_man_date.setText("");
            lbl_check_serialno.setText("");
            txt_comment.clear();
        
        
        }
        
        }
        
        }
        
        }else{
            
                lbl_check_man_date.setText("* Please Fill the Date");
                
                
            }
            
       
        
       
        
        }
        
        }
        
    }
    
    

    
}
