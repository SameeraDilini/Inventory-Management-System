/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

/**
 * FXML Controller class
 *
 * @author user
 */
public class Home_MenuController implements Initializable {

    @FXML
    private Pane pane;
    @FXML
    private HBox home_tab;
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            Parent start = FXMLLoader.load(getClass().getResource("/hsb/view/ui/home_content.fxml"));
            pane.getChildren().removeAll();
            pane.getChildren().setAll(start);
            
            home_tab.setStyle("-fx-background-color: rgb(16, 59, 99);-fx-background-radius:30 30 30 30;");
           
        } catch (IOException ex) {
            Logger.getLogger(Home_MenuController.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }    

    @FXML
    private void home_tab(MouseEvent event) {
        try {
            Parent start = FXMLLoader.load(getClass().getResource("/hsb/view/ui/home_content.fxml"));
            pane.getChildren().removeAll();
            pane.getChildren().setAll(start);
            
            home_tab.setStyle("-fx-background-color: rgb(16, 59, 99);-fx-background-radius:30 30 30 30;");
            
        } catch (IOException ex) {
            Logger.getLogger(Home_MenuController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

   
    
}
