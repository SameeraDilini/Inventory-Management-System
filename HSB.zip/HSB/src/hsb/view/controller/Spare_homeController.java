/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import hsb.controller.ControllerFactory;
import hsb.controller.custom.InvenController;
import hsb.controller.custom.NodeSectionController;
import hsb.dto.InvenDTO;
import hsb.dto.bsc_DTO;
import hsb.view.model.nodes_tablemodel;
import hsb.view.model.spare_tablemodel;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import tray.animations.AnimationType;
import tray.notification.NotificationType;
import tray.notification.TrayNotification;

/**
 * FXML Controller class
 *
 * @author user
 */
public class Spare_homeController implements Initializable {

    @FXML
    private TableView<spare_tablemodel> table_spare;
    ArrayList<spare_tablemodel> all_spares;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            table_spare.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("Serial_Number"));
            table_spare.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("Vendor"));
            table_spare.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("Board_Name"));
            table_spare.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("Sub_Inventory"));
            table_spare.getColumns().get(4).setCellValueFactory(new PropertyValueFactory<>("Locator"));
            table_spare.getColumns().get(5).setCellValueFactory(new PropertyValueFactory<>("Location"));
            table_spare.getColumns().get(6).setCellValueFactory(new PropertyValueFactory<>("Manufactured_Date"));
            table_spare.getColumns().get(7).setCellValueFactory(new PropertyValueFactory<>("ERP_Item_Code"));
            table_spare.getColumns().get(8).setCellValueFactory(new PropertyValueFactory<>("ERP_Number"));
            table_spare.getColumns().get(9).setCellValueFactory(new PropertyValueFactory<>("Added_By"));
            table_spare.getColumns().get(10).setCellValueFactory(new PropertyValueFactory<>("Added_Date"));
  
            //node_home view
            InvenController controller=(InvenController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.INVEN);
            ArrayList<InvenDTO> nodes = controller.getAll();
            all_spares = new ArrayList<spare_tablemodel>();
            for (InvenDTO dto : nodes) {
                all_spares.add(new spare_tablemodel(
                        dto.getSerial_no(),
                        dto.getVendor(),
                        dto.getBoard_name(),
                        dto.getSub_inventory(),
                        dto.getLocator(),
                        dto.getLocation(),
                        dto.getManufac_date(),
                        dto.getItem_code(),
                        dto.getErp_number(),
                        dto.getAdded_by(),
                        dto.getDate()
                        
                ));
            }
            ObservableList<spare_tablemodel> allnodes = FXCollections.observableArrayList(all_spares);

//            table_spare.getSelectionModel().setCellSelectionEnabled(true);
//                table_spare.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

                MenuItem item = new MenuItem("Copy");
                item.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        ObservableList<TablePosition> posList = table_spare.getSelectionModel().getSelectedCells();
                        int old_r = -1;
                        StringBuilder clipboardString = new StringBuilder();
                        for (TablePosition p : posList) {
                            int r = p.getRow();
                            int c = p.getColumn();
                            Object cell = table_spare.getColumns().get(c).getCellData(r);
                            if (cell == null)
                                cell = "";
                            if (old_r == r)
                                clipboardString.append('\t');
                            else if (old_r != -1)
                                clipboardString.append('\n');
                            clipboardString.append(cell);
                            old_r = r;
                        }
                        final ClipboardContent content = new ClipboardContent();
                        content.putString(clipboardString.toString());
                        Clipboard.getSystemClipboard().setContent(content);
                    }
                });
                ContextMenu menu = new ContextMenu();
                menu.getItems().add(item);
                table_spare.setContextMenu(menu);
            table_spare.setItems(allnodes);
//            System.out.println(nodes.get(1));
        } catch (Exception ex) {
            Logger.getLogger(Spare_homeController.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }    

    @FXML
    private void export(MouseEvent event) {
     writeListToExcel(all_spares);
    }
    
    public static void writeListToExcel(ArrayList<spare_tablemodel> spare_list){
 
        
        // Using XSSF for xlsx format, for xls use HSSF
        Workbook workbook = new HSSFWorkbook();
 
        Sheet sheet = workbook.createSheet("Spares");
 
        
        Row rw=sheet.createRow(0);
        rw.createCell(0).setCellValue("Serial_No");
        rw.createCell(1).setCellValue("Vendor");
        rw.createCell(2).setCellValue("Board Name");
        rw.createCell(3).setCellValue("Sub Inventory");
        rw.createCell(4).setCellValue("Locator");
        rw.createCell(5).setCellValue("Location");
        rw.createCell(6).setCellValue("Manufactured Date");
        rw.createCell(7).setCellValue("ERP Item Code");
        rw.createCell(8).setCellValue("ERP Number");
        rw.createCell(9).setCellValue("Added By");
        rw.createCell(10).setCellValue("Added Date");
        
        
        
        
        int rowIndex = 1;
//        for(Student student : studentList){
            for (spare_tablemodel tm: spare_list){
                
            Row row = sheet.createRow(rowIndex++);
            
            int cellIndex = 0;
            
            row.createCell(cellIndex++).setCellValue(tm.getSerial_Number());
            
            
            row.createCell(cellIndex++).setCellValue(tm.getVendor());
            row.createCell(cellIndex++).setCellValue(tm.getBoard_Name());
            row.createCell(cellIndex++).setCellValue(tm.getSub_Inventory());
            row.createCell(cellIndex++).setCellValue(tm.getLocator());
            row.createCell(cellIndex++).setCellValue(tm.getLocation());
            
            SimpleDateFormat formatter2 = new SimpleDateFormat("dd/MM/yyyy");
            String strDate2 = formatter2.format(tm.getManufactured_Date());
            row.createCell(cellIndex++).setCellValue(strDate2);
            
            row.createCell(cellIndex++).setCellValue(tm.getERP_Item_Code());
            row.createCell(cellIndex++).setCellValue(tm.getERP_Number());
            row.createCell(cellIndex++).setCellValue(tm.getAdded_By());
            
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
            String strDate = formatter.format(tm.getAdded_Date());
            row.createCell(cellIndex++).setCellValue(strDate);
 
            
            
            
 
        }
 
        //write this workbook in excel file.
        try {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Save to Excel");
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Microsoft Office Excel 2013", "*.xls"));
            File selectedFile = fileChooser.showSaveDialog(null);
            if (selectedFile != null) {
            TrayNotification tray = new TrayNotification();
            FileOutputStream fileout = new FileOutputStream(selectedFile.getAbsoluteFile());
            workbook.write(fileout);
            fileout.close();
 
            System.out.println(selectedFile.getAbsoluteFile() + " is successfully written");
            tray.setNotificationType(NotificationType.SUCCESS);
            tray.setTitle("Save Success");
            tray.setMessage("File has been successfully saved");
            tray.setAnimationType(AnimationType.POPUP);
            tray.showAndDismiss(javafx.util.Duration.millis(1000));
            tray.setRectangleFill(javafx.scene.paint.Color.valueOf("#4183D7"));
//            tray.setImage(new Image("/img/icons8_Ok_96px.png"));
            
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
 
 
    }
    
}
