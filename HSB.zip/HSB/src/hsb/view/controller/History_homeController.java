/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

/**
 * FXML Controller class
 *
 * @author user
 */
public class History_homeController implements Initializable {

    @FXML
    private Pane pane;
    @FXML
    private HBox serial_no_tab;
    @FXML
    private HBox bsc_tab;
    @FXML
    private HBox board_name_tab;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            Parent start = FXMLLoader.load(getClass().getResource("/hsb/view/ui/history.fxml"));
            pane.getChildren().removeAll();
            pane.getChildren().setAll(start);
            
            serial_no_tab.setStyle("-fx-background-color: rgb(47, 71, 42);-fx-background-radius:30 30 30 30;");
            bsc_tab.setStyle("-fx-background-color: rgb(36, 158, 42);");
            board_name_tab.setStyle("-fx-background-color: rgb(36, 158, 42);");
            
            
                    } catch (IOException ex) {
            Logger.getLogger(NodeViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void by_serial_no(MouseEvent event) {
         try {
            Parent start = FXMLLoader.load(getClass().getResource("/hsb/view/ui/history.fxml"));
            pane.getChildren().removeAll();
            pane.getChildren().setAll(start);
            
             serial_no_tab.setStyle("-fx-background-color: rgb(47, 71, 42);-fx-background-radius:30 30 30 30;");
            bsc_tab.setStyle("-fx-background-color: rgb(36, 158, 42);");
            board_name_tab.setStyle("-fx-background-color: rgb(36, 158, 42);");
                    } catch (IOException ex) {
            Logger.getLogger(NodeViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void by_bsc_name(MouseEvent event) {
         try {
            Parent start = FXMLLoader.load(getClass().getResource("/hsb/view/ui/history_2.fxml"));
            pane.getChildren().removeAll();
            pane.getChildren().setAll(start);
            
             serial_no_tab.setStyle("-fx-background-color: rgb(36, 158, 42);");
            bsc_tab.setStyle("-fx-background-color: rgb(47, 71, 42);-fx-background-radius:30 30 30 30;");
            board_name_tab.setStyle("-fx-background-color: rgb(36, 158, 42);");
                    } catch (IOException ex) {
            Logger.getLogger(NodeViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void by_board_type(MouseEvent event) {
         try {
            Parent start = FXMLLoader.load(getClass().getResource("/hsb/view/ui/history_3.fxml"));
            pane.getChildren().removeAll();
            pane.getChildren().setAll(start);
            
             serial_no_tab.setStyle("-fx-background-color: rgb(36, 158, 42);");
            bsc_tab.setStyle("-fx-background-color: rgb(36, 158, 42);");
            board_name_tab.setStyle("-fx-background-color: rgb(47, 71, 42);-fx-background-radius:30 30 30 30;");
                    } catch (IOException ex) {
            Logger.getLogger(NodeViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
