/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import static com.sun.javafx.util.Utils.split;
import hsb.controller.ControllerFactory;
import hsb.controller.custom.HistoryController;
import hsb.controller.custom.NodeSectionController;
import hsb.controller.custom.UserController;
import hsb.dto.TransactionDTO;
import hsb.dto.UserDTO;
import hsb.dto.bsc_DTO;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author user
 */
public class Node_newController implements Initializable {

    private TextField txtvendor;
    @FXML
    private TextField txtlocation;
    @FXML
    private TextField txt_phy_name;
    @FXML
    private TextField txt_log_name;
    
    private bsc_DTO node;
    
    private UserDTO user;
    @FXML
    private TextField txt_serial_no;
    @FXML
    private Button ADD_btn;
    
    @FXML
    private TextField txt_erp_code;
    @FXML
    private TextField txt_erp_name;
    @FXML
    private DatePicker txt_man_date;
    
    private Pattern pattern_node;
    private Matcher matcher_node;
    private String validate_location="";
     private static final String LOACTION_PATTERN = 
		"^BSC+[0-9]{1,}_+[0-9]_+[0-9]_+[0-9]{1,2}$";
    @FXML
    private Label lbl_check_location;
    @FXML
    private Label lbl_check_date;
    @FXML
    private Label lbl_check_serialno;
    @FXML
    private TextField txtcomment;
    @FXML
    private Label lbl_check_date1;
    @FXML
    private ComboBox<String> cmb_vendor;
    private ArrayList<String> A_list;
    private ArrayList<String> B_list;
    @FXML
    private ComboBox<String> cmb_bsc_location;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
                A_list=new ArrayList<>();
                A_list.add("ZTE");
                A_list.add("HUAWEI");

               ObservableList<String> list=FXCollections.observableArrayList(A_list);
                cmb_vendor.getItems().add(list.get(0));
                cmb_vendor.getItems().add(list.get(1));
                cmb_vendor.getSelectionModel().selectFirst();
        
                B_list=new ArrayList<>();
                B_list.add("WELIKADA");
                B_list.add("ANURADHAPURA");

               ObservableList<String> list_b=FXCollections.observableArrayList(B_list);
                cmb_bsc_location.getItems().add(list_b.get(0));
                cmb_bsc_location.getItems().add(list_b.get(1));
                cmb_bsc_location.getSelectionModel().selectFirst();
                
                
    }    
    
    public Node_newController(){
    
        pattern_node = Pattern.compile(LOACTION_PATTERN);
    
    }

    @FXML
    private void add_New_Node(MouseEvent event) throws Exception {
        
        if(txt_serial_no.getText().equals("")){
        
        lbl_check_serialno.setText("* Please Fill the Serial No");
        txt_serial_no.setFocusTraversable(true);
        
        }else{
            
        NodeSectionController nodecontroller=(NodeSectionController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
        boolean rep=nodecontroller.check_repetition(txt_serial_no.getText());    

        if(rep==true){
        lbl_check_serialno.setText("* Aleardy added");
        }else{
            lbl_check_serialno.setText("");
        validate_location=txtlocation.getText();
        boolean check_location=validate_location(validate_location);
        
        if(check_location==true ){
        
            lbl_check_location.setText("* matched");
            
            if(txt_man_date.getValue()!=null){
            
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate localDate = LocalDate.now();
        Date date = java.sql.Date.valueOf(localDate);
        
         Date manufac_date=java.sql.Date.valueOf(txt_man_date.getValue());
         if(manufac_date.after(date)){
         
             Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops !  You cannot add future dates!");

            alert.showAndWait();
         
         }else{
         
        
        UserController controller_user=(UserController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.USER);
        String user=controller_user.getLogged_username();
        
        String commaswords = txtlocation.getText();
        String[] list = split(commaswords, "_");
       
        String bsc_name=list[0];
        String rack=list[1];
        String shelf=list[2];
        String slot=list[3];
        
       if(txt_erp_code.getText().equals("") || txt_erp_name.getText().equals("") || 
               txt_log_name.getText().equals("") || txt_phy_name.getText().equals("")){
       
       
           Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops !  Fill all the fields!");

            alert.showAndWait();
       
       
       }else{
        

        node=new bsc_DTO(Integer.parseInt("0"),
                         txt_serial_no.getText(),
                         cmb_vendor.getSelectionModel().getSelectedItem(),
                         bsc_name,
                         cmb_bsc_location.getSelectionModel().getSelectedItem(),
                         txt_phy_name.getText().toUpperCase(),
                         txt_log_name.getText().toUpperCase(),
                         txt_erp_code.getText().toUpperCase(),
                         txt_erp_name.getText().toUpperCase(),
                         rack,
                         shelf,
                         slot,
                         date,
                         user,
                         manufac_date,
                         txtcomment.getText()
                        
                        );
        NodeSectionController controller=(NodeSectionController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
        Boolean check=controller.add(node);
        
        System.out.println(check);
        
        TransactionDTO transaction=new TransactionDTO(txt_serial_no.getText(),
                                                        txtlocation.getText(),
                                                        "",
                                                        "",
                                                        "",
                                                        txt_phy_name.getText().toUpperCase(),
                                                        "",
                                                        "",
                                                        date,user,"Added to BSC List");
        
        
        HistoryController history_controller=(HistoryController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.HISTORY);
        boolean history=history_controller.add(transaction);
        
        
        
        if(check==true && history==true){
            
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Information Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Successfully added!");

            alert.showAndWait();
            
            txt_serial_no.clear();
            
            txtlocation.clear();
            txt_phy_name.clear();
            txt_log_name.clear();
            
            txt_erp_code.clear();
            txt_erp_name.clear();
            txt_man_date.getEditor().clear();
            txtcomment.clear();
            lbl_check_date.setText("");
            lbl_check_location.setText("");
            lbl_check_serialno.setText("");
            
            
        
        }
        else{
        
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, there was an error!");

            alert.showAndWait();
        
            txt_serial_no.clear();
            
            txtlocation.clear();
            txt_phy_name.clear();
            txt_log_name.clear();
            
            txt_erp_code.clear();
            txt_erp_name.clear();
            txt_man_date.getEditor().clear();
            txtcomment.clear();
            lbl_check_date.setText("");
            lbl_check_location.setText("");
            lbl_check_serialno.setText("");
        
        
        }
       
       }
       
       }
       }else{
            
//                lbl_check_date.setText("* Please Fill the Date");


        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate localDate = LocalDate.now();
        Date date = java.sql.Date.valueOf(localDate);
        
         
         
        
        UserController controller_user=(UserController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.USER);
        String user=controller_user.getLogged_username();
        
        String commaswords = txtlocation.getText();
        String[] list = split(commaswords, "_");
       
        String bsc_name=list[0];
        String rack=list[1];
        String shelf=list[2];
        String slot=list[3];
        
       if(txt_erp_code.getText().equals("") || txt_erp_name.getText().equals("") || 
               txt_log_name.getText().equals("") || txt_phy_name.getText().equals("")){
       
       
           Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops !  Fill all the fields!");

            alert.showAndWait();
       
       
       }else{
        

        node=new bsc_DTO(Integer.parseInt("0"),
                         txt_serial_no.getText(),
                         cmb_vendor.getSelectionModel().getSelectedItem(),
                         bsc_name,
                         cmb_bsc_location.getSelectionModel().getSelectedItem(),
                         txt_phy_name.getText().toUpperCase(),
                         txt_log_name.getText().toUpperCase(),
                         txt_erp_code.getText().toUpperCase(),
                         txt_erp_name.getText().toUpperCase(),
                         rack,
                         shelf,
                         slot,
                         date,
                         user,
                         null,
                         txtcomment.getText()
                        
                        );
        NodeSectionController controller=(NodeSectionController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
        Boolean check=controller.add(node);
        
        System.out.println(check);
        
        TransactionDTO transaction=new TransactionDTO(txt_serial_no.getText(),
                                                        txtlocation.getText(),
                                                        "",
                                                        "",
                                                        "",
                                                        txt_phy_name.getText().toUpperCase(),
                                                        "",
                                                        "",
                                                        date,user,"Added to BSC List");
        
        
        HistoryController history_controller=(HistoryController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.HISTORY);
        boolean history=history_controller.add(transaction);
        
        
        
        if(check==true && history==true){
            
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Information Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Successfully added!");

            alert.showAndWait();
            
            txt_serial_no.clear();
            
            txtlocation.clear();
            txt_phy_name.clear();
            txt_log_name.clear();
            
            txt_erp_code.clear();
            txt_erp_name.clear();
            txt_man_date.getEditor().clear();
            txtcomment.clear();
            lbl_check_date.setText("");
            lbl_check_location.setText("");
            lbl_check_serialno.setText("");
            
            
        
        }
        else{
        
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, there was an error!");

            alert.showAndWait();
        
            txt_serial_no.clear();
            
            txtlocation.clear();
            txt_phy_name.clear();
            txt_log_name.clear();
            
            txt_erp_code.clear();
            txt_erp_name.clear();
            txt_man_date.getEditor().clear();
            txtcomment.clear();
            lbl_check_date.setText("");
            lbl_check_location.setText("");
            lbl_check_serialno.setText("");
        
        
        }
       
       }
       
       
                
                
            }
            
       
        
        }else{
        
            lbl_check_location.setText("* should be eg: BSC23_1_2_3");
        
        }
        



//        String commaswords = txtlocation.getText();
//        String[] list = split(commaswords, "_");
//        
//        
//        for(String sep:list){
//        
//            System.out.println(sep); 
//        
//        }
        
        }
        
        }
           
    }
    
    
    public boolean validate_location(final String hex) {

		matcher_node = pattern_node.matcher(hex);
		return matcher_node.matches();

	    }
    
}
