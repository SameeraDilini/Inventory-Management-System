/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import hsb.controller.ControllerFactory;
import hsb.controller.custom.UserController;
import hsb.dto.UserDTO;
import static hsb.main.main.stage;
import static hsb.view.controller.LoginViewController.primarystage3;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class Forgot_passwordController implements Initializable {

    @FXML
    private Pane header_pane;
    @FXML
    private TextField txt_email;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void minimize_app(MouseEvent event) {
        primarystage3.setIconified(true);
    }

    @FXML
    private void close_app(MouseEvent event) {
        System.exit(0);
        
    }

    @FXML
    private void go_to_login_page(MouseEvent event) throws IOException {
        
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", 465);            //127.0.0.1:49685
        props.put("mail.smtp.user", "dilinipreshani@gmail.com");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.debug", "true");
        props.put("mail.smtp.socketFactory.port", 465);
        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.socketFactory.fallback", "false"); 
        try {
            UserController controller=(UserController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.USER);
                UserDTO user=controller.getByID(txt_email.getText());              
            if (user!=null)
            {   
                String fetchedPassword = user.getPassword();               
                Session session = Session.getDefaultInstance(props, null);
                session.setDebug(true);
                MimeMessage message = new MimeMessage(session);
                message.setText("Your password is " + fetchedPassword);
                message.setSubject("Password for your account");
                message.setFrom(new InternetAddress("dilinipreshani@gmail.com"));
                message.addRecipient(Message.RecipientType.TO, new InternetAddress("dilinipreshani@gmail.com".trim()));
                message.saveChanges();
                Transport transport = session.getTransport("smtp");
                transport.connect("smtp.gmail.com", "dilinipreshani@gmail.com", "sameera1994");
                transport.sendMessage(message, message.getAllRecipients());
                transport.close();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Your password has been sent to your email. Check your Email!");

            alert.showAndWait();
            
            
            Parent root = FXMLLoader.load(getClass().getResource("/hsb/view/ui/login.fxml"));
            Scene scene = new Scene(root);
            stage=new Stage();
            stage.initStyle(StageStyle.TRANSPARENT);
            stage.setScene(scene);
            
            stage.show();
            primarystage3.close();
            }
        } catch (Exception e) {
            e.printStackTrace();  
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, Email is not found!");

            alert.showAndWait();
        }  
        
        
        
        
        
        
        
        
//            Parent root = FXMLLoader.load(getClass().getResource("/hsb/view/ui/login.fxml"));
//            Scene scene = new Scene(root);
//            stage=new Stage();
//            stage.initStyle(StageStyle.TRANSPARENT);
//            stage.setScene(scene);
//            
//            stage.show();
//            primarystage3.close();
    }
    
}
