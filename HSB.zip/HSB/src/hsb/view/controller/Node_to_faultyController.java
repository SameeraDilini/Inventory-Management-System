/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import hsb.controller.ControllerFactory;
import hsb.controller.custom.FaultsController;
import hsb.controller.custom.HistoryController;
import hsb.controller.custom.InvenController;
import hsb.controller.custom.NodeSectionController;
import hsb.controller.custom.UserController;
import hsb.dto.FaultyDTO;
import hsb.dto.InvenDTO;
import hsb.dto.SpareDTO;
import hsb.dto.TransactionDTO;
import hsb.dto.bsc_DTO;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author user
 */
public class Node_to_faultyController implements Initializable {

    @FXML
    private Label lbl_check_serial_no;
    
    @FXML
    private Button btn_add;
    ArrayList<String> arraylist;
    @FXML
    private ComboBox<String> cmb_serial_no;
    @FXML
    private Label lbl_check_serial_no1111;
    @FXML
    private Label lbl_check_serial_no11111;
    @FXML
    private Label lbl_vendor;
    @FXML
    private Label lbl_erp_item_code;
    @FXML
    private Label lbl_board_name;
    
    private FaultyDTO faulty;
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         try {
            btn_add.setVisible(false);
            arraylist=new ArrayList<>();
            NodeSectionController nodecontroller=(NodeSectionController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
            ArrayList<bsc_DTO> nodes = nodecontroller.getAllNodes();
            
            nodes.forEach((dto_sp) -> {
                arraylist.add(dto_sp.getSerial_no());
            });
            
            cmb_serial_no.setEditable(true);
            ObservableList<String> items_sp = FXCollections.observableArrayList(arraylist);
            
            FilteredList<String> filteredItems_sp = new FilteredList<String>(items_sp, p_sp -> true);
            cmb_serial_no.getEditor().textProperty().addListener((obs_sp, oldValue_sp, newValue_sp) -> {
                final TextField editor_sp = cmb_serial_no.getEditor();
                final String selected_sp = cmb_serial_no.getSelectionModel().getSelectedItem();
                
                // This needs run on the GUI thread to avoid the error described
                // here: https://bugs.openjdk.java.net/browse/JDK-8081700.
                Platform.runLater(() -> {
                    // If the no item in the list is selected or the selected item
                    // isn't equal to the current input, we refilter the list.
                    if (selected_sp == null || !selected_sp.equals(editor_sp.getText())) {
                        filteredItems_sp.setPredicate(itemsp -> {
                            // We return true for any items that starts with the
                            // same letters as the input. We use toUpperCase to
                            // avoid case sensitivity.
                            if (itemsp.toUpperCase().startsWith(newValue_sp.toUpperCase())) {
                                return true;
                            } else {
                                return false;
                            }
                        });
                    }
                });
            });
            
            cmb_serial_no.setItems(filteredItems_sp);
            cmb_serial_no.valueProperty().addListener(new ChangeListener<String>() {
                @Override
                public void changed(ObservableValue<? extends String> observablesp, String oldValuesp, String newValuesp) {
                    if(cmb_serial_no.getSelectionModel().getSelectedItem()!=null){
                        
                        try {
                            NodeSectionController controller=(NodeSectionController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
                            bsc_DTO bsc=controller.getById(cmb_serial_no.getSelectionModel().getSelectedItem());
                            
                            if(bsc!=null){
                                
                                lbl_vendor.setText(bsc.getVendor());
                                lbl_board_name.setText(bsc.getPhysical_name());
                                lbl_erp_item_code.setText(bsc.getErp_item_code());
                                
                                btn_add.setVisible(true);
                                
                            }
                        } catch (Exception ex) {
                            Logger.getLogger(Node_f_sController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            });
        } catch (Exception ex) {
            Logger.getLogger(Spare_faultyController.class.getName()).log(Level.SEVERE, null, ex);
        }
        // TODO
    }    

    @FXML
    private void add_faulty(MouseEvent event) {
      if(cmb_serial_no.getSelectionModel().getSelectedItem()==null){
        
        lbl_check_serial_no.setText("* Please Fill the Serial No");
//        txt_serial_no.setFocusTraversable(true);
        
        }else{
          try {
              FaultsController invencontroller=(FaultsController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.FAULTS);
              boolean rep=invencontroller.check_repetition(cmb_serial_no.getSelectionModel().getSelectedItem());
              
              if(rep==true){
                  lbl_check_serial_no.setText("* Already added");
              }else{
                  lbl_check_serial_no.setText("");
                  DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                  LocalDate localDate = LocalDate.now();
                  Date date = java.sql.Date.valueOf(localDate);
                  
                  
                  UserController controller_user=(UserController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.USER);
                  String user=controller_user.getLogged_username();
                  
                  
                  SingleSelectionModel<String> serial_no=cmb_serial_no.getSelectionModel();
                  
                  faulty=new FaultyDTO(cmb_serial_no.getSelectionModel().getSelectedItem(),lbl_vendor.getText(),lbl_erp_item_code.getText(),lbl_board_name.getText(),date,user);
                  InvenController controller=(InvenController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.INVEN);
                  Boolean check=controller.add_faulty(faulty);
                  
                  NodeSectionController node_controller=(NodeSectionController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
                  boolean node_delete=node_controller.delete(cmb_serial_no.getSelectionModel().getSelectedItem());
                  
                  TransactionDTO transaction=new TransactionDTO(cmb_serial_no.getSelectionModel().getSelectedItem(),
                          "",
                          "",
                          "",
                          "",
                          lbl_board_name.getText().toUpperCase(),
                          "",
                          "",
                          date,user,"Added to Faulty List from BSC List");
                  
                  
                  HistoryController history_controller=(HistoryController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.HISTORY);
                  boolean history=history_controller.add(transaction);
                  
                  System.out.println(node_delete);
                  
                  System.out.println(date);
                  
                  if(check==true && node_delete==true && history==true){
                      
                      Alert alert = new Alert(Alert.AlertType.INFORMATION);
                      alert.setTitle("Information Dialog");
                      alert.setHeaderText(null);
                      alert.setContentText("Successfully added!");
                      
                      alert.showAndWait();
                      
                     ArrayList<String> arraylist2=new ArrayList<>();
                    NodeSectionController nodecontroller2=(NodeSectionController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
                    ArrayList<bsc_DTO> nodes2 = nodecontroller2.getAllNodes();

                    nodes2.forEach((dto_sp) -> {
                        arraylist2.add(dto_sp.getSerial_no());
                    });
                    ObservableList<String> items_sp2 = FXCollections.observableArrayList(arraylist2);
                    cmb_serial_no.setItems(items_sp2);
                    cmb_serial_no.valueProperty().addListener(new ChangeListener<String>() {
                        @Override
                        public void changed(ObservableValue<? extends String> observablesp, String oldValuesp, String newValuesp) {
                            if(cmb_serial_no.getSelectionModel().getSelectedItem()!=null){

                                try {
                                    NodeSectionController controller=(NodeSectionController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
                                    bsc_DTO bsc=controller.getById(cmb_serial_no.getSelectionModel().getSelectedItem());

                                    if(bsc!=null){

                                        lbl_vendor.setText(bsc.getVendor());
                                        lbl_board_name.setText(bsc.getPhysical_name());
                                        lbl_erp_item_code.setText(bsc.getErp_item_code());

                                        btn_add.setVisible(true);

                                    }
                                } catch (Exception ex) {
                                    Logger.getLogger(Node_f_sController.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                        }
                    });
                    
                    
                    
                      cmb_serial_no.getSelectionModel().clearSelection();
                      lbl_board_name.setText("");
                      lbl_vendor.setText("");
                      lbl_erp_item_code.setText("");
                      lbl_check_serial_no.setText("");
                      
                      
                      
                  }
                  else{
                      
                      Alert alert = new Alert(Alert.AlertType.ERROR);
                      alert.setTitle("Error Dialog");
                      alert.setHeaderText("Look, an Error Dialog");
                      alert.setContentText("Ooops, there was an error!");
                      
                      alert.showAndWait();
                      
                      cmb_serial_no.getSelectionModel().clearSelection();
                      lbl_board_name.setText("");
                      lbl_vendor.setText("");
                      lbl_erp_item_code.setText("");
                      lbl_check_serial_no.setText("");
                      
                  }
                  
              }     } catch (Exception ex) {
              Logger.getLogger(Node_to_faultyController.class.getName()).log(Level.SEVERE, null, ex);
          }
        
        }
    }
    
}
