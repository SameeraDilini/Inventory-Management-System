/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

/**
 * FXML Controller class
 *
 * @author user
 */
public class SpareViewController implements Initializable {

    @FXML
    private Pane pane;
    @FXML
    private HBox home_tab;
    @FXML
    private HBox new_tab;
    @FXML
    private HBox faulty_tab;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            Parent start = FXMLLoader.load(getClass().getResource("/hsb/view/ui/spare_home.fxml"));
            pane.getChildren().removeAll();
            pane.getChildren().setAll(start);
            
            home_tab.setStyle("-fx-background-color: rgb(99, 23, 46);-fx-background-radius:30 30 30 30;");
            new_tab.setStyle("-fx-background-color: rgb(244, 70, 70);");
            faulty_tab.setStyle("-fx-background-color: rgb(244, 70, 70);");
                    } catch (IOException ex) {
            Logger.getLogger(NodeViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void home_content(MouseEvent event) {
         try {
            Parent start = FXMLLoader.load(getClass().getResource("/hsb/view/ui/spare_home.fxml"));
            pane.getChildren().removeAll();
            pane.getChildren().setAll(start);
            
            home_tab.setStyle("-fx-background-color: rgb(99, 23, 46);-fx-background-radius:30 30 30 30;");
            new_tab.setStyle("-fx-background-color: rgb(244, 70, 70);");
            faulty_tab.setStyle("-fx-background-color: rgb(244, 70, 70);");
            
                    } catch (IOException ex) {
            Logger.getLogger(NodeViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void add_new(MouseEvent event) {
         try {
            Parent start = FXMLLoader.load(getClass().getResource("/hsb/view/ui/spare_new.fxml"));
            pane.getChildren().removeAll();
            pane.getChildren().setAll(start);
            home_tab.setStyle("-fx-background-color: rgb(244, 70, 70);");
            new_tab.setStyle("-fx-background-color: rgb(99, 23, 46);-fx-background-radius:30 30 30 30;");
            faulty_tab.setStyle("-fx-background-color: rgb(244, 70, 70);");
                    } catch (IOException ex) {
            Logger.getLogger(NodeViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void go_to_faulty(MouseEvent event) {
         try {
            Parent start = FXMLLoader.load(getClass().getResource("/hsb/view/ui/spare_faulty.fxml"));
            pane.getChildren().removeAll();
            pane.getChildren().setAll(start);
            home_tab.setStyle("-fx-background-color: rgb(244, 70, 70);");
            new_tab.setStyle("-fx-background-color: rgb(244, 70, 70);");
            faulty_tab.setStyle("-fx-background-color: rgb(99, 23, 46);-fx-background-radius:30 30 30 30;");
                    } catch (IOException ex) {
            Logger.getLogger(NodeViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
