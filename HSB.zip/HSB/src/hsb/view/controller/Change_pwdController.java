/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import hsb.controller.ControllerFactory;
import hsb.controller.custom.UserController;
import hsb.dto.UserDTO;
import static hsb.main.main.stage;
import static hsb.view.controller.LoginViewController.primarystage2;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author user
 */
public class Change_pwdController implements Initializable {

    @FXML
    private Pane change_pwd_pane;
    @FXML
    private ImageView close_btn;
    @FXML
    private ImageView min_btn;
    
    private UserDTO user;
    @FXML
    private TextField txtusername;
    @FXML
    private PasswordField txt_old_pwd;
    @FXML
    private PasswordField txt_new_pwd;
    @FXML
    private PasswordField txt_confirm_pwd;
    
    private Pattern pattern_pwd;
    private Matcher matcher_pwd;
    
    private static final String PASSWORD_PATTERN = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,40})";
    @FXML
    private Label lbl_new_pwd;
    @FXML
    private Label lbl_confirm_pwd;
    @FXML
    private Label lbl_un;
    @FXML
    private Label lbl_old_pwd;
    @FXML
    private Pane header_pane;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    public Change_pwdController(){
    
        pattern_pwd = Pattern.compile(PASSWORD_PATTERN);
    
    }

    @FXML
    private void close_app(MouseEvent event) {
        System.exit(0);
    }

    @FXML
    private void minimize_app(MouseEvent event) {
         primarystage2.setIconified(true);
    }

    @FXML
    private void go_to_login_page(MouseEvent event) throws IOException, Exception {
        
        
        UserController controller=(UserController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.USER);
        UserDTO check_un=controller.getByID(txtusername.getText());
        
        
        
        if(check_un!=null){
            
            lbl_un.setText("");
            System.out.println("okay");

           if(check_un.getPassword().equals(txt_old_pwd.getText())){
                
                lbl_old_pwd.setText("");
                
               
                }else{
                    lbl_old_pwd.setText("Wrong Old Password");
                    System.out.println(check_un.getPassword());
                }

                }else{
                    lbl_un.setText("*Wrong Username");

                }
        
       boolean new_pwd=validate_pwd(txt_new_pwd.getText());
       
       if(new_pwd==true){
       
           lbl_new_pwd.setText("");
       
       }else{
       
           lbl_new_pwd.setText("*@ least 8 character with "+"\n"+"1 digit,1 lower and uppercase "+"\n"+"character and (@ # $ % ! .)");
       
       
       }
       
       if(txt_confirm_pwd.getText().equals("")){
       
           lbl_confirm_pwd.setText("*confirm Password");
       
       }
       
       if(check_un!=null && new_pwd==true && txt_new_pwd.getText().equals(txt_confirm_pwd.getText())){
           
           user=new UserDTO(check_un.getId(),txtusername.getText(),txt_new_pwd.getText());
           boolean confirm=controller.update(user);
           
           if(confirm==true){Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Successfully added!");

            alert.showAndWait();
            
            Parent root = FXMLLoader.load(getClass().getResource("/hsb/view/ui/login.fxml"));
            Scene scene = new Scene(root);
            stage=new Stage();
            stage.initStyle(StageStyle.TRANSPARENT);
            stage.setScene(scene);
            stage.show();
            primarystage2.close();
           }else{
               
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, there was an error!");
            
           }

            

       }else{Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, there was an error!");}
    }
    
    
     //validate password
            public boolean validate_pwd(final String password) {
 
                matcher_pwd = pattern_pwd.matcher(password);
                return matcher_pwd.matches();

            }
    
}
