/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

/**
 * FXML Controller class
 *
 * @author user
 */
public class NodeViewController implements Initializable {

    @FXML
    private Pane pane;
    @FXML
    private HBox home_tab;
    @FXML
    private HBox new_tab;
    @FXML
    private HBox faulty_tab;
    @FXML
    private HBox bsc_to_faulty_tab;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            Parent start = FXMLLoader.load(getClass().getResource("/hsb/view/ui/node_startup.fxml"));
            pane.getChildren().removeAll();
            pane.getChildren().setAll(start);
            
            home_tab.setStyle("-fx-background-color: rgb(188, 9, 87);-fx-background-radius:30 30 30 30;");
            new_tab.setStyle("-fx-background-color: rgb(221, 33, 187);");
            faulty_tab.setStyle("-fx-background-color: rgb(221, 33, 187);");
            bsc_to_faulty_tab.setStyle("-fx-background-color: rgb(221, 33, 187);");
                    } catch (IOException ex) {
            Logger.getLogger(NodeViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void home_content(MouseEvent event) {
         try {
            Parent start = FXMLLoader.load(getClass().getResource("/hsb/view/ui/node_startup.fxml"));
            pane.getChildren().removeAll();
            pane.getChildren().setAll(start);
            
            home_tab.setStyle("-fx-background-color: rgb(188, 9, 87);-fx-background-radius:30 30 30 30;");
            new_tab.setStyle("-fx-background-color: rgb(221, 33, 187);");
            faulty_tab.setStyle("-fx-background-color: rgb(221, 33, 187);");
            bsc_to_faulty_tab.setStyle("-fx-background-color: rgb(221, 33, 187);");
            
                    } catch (IOException ex) {
            Logger.getLogger(NodeViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void add_new(MouseEvent event) {
         try {
            Parent start = FXMLLoader.load(getClass().getResource("/hsb/view/ui/node_new.fxml"));
            pane.getChildren().removeAll();
            pane.getChildren().setAll(start);
            
            home_tab.setStyle("-fx-background-color: rgb(221, 33, 187);");
            new_tab.setStyle("-fx-background-color: rgb(188, 9, 87);-fx-background-radius:30 30 30 30;");
            faulty_tab.setStyle("-fx-background-color: rgb(221, 33, 187);");
            bsc_to_faulty_tab.setStyle("-fx-background-color: rgb(221, 33, 187);");
                    } catch (IOException ex) {
            Logger.getLogger(NodeViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void faults(MouseEvent event) {
         try {
            Parent start = FXMLLoader.load(getClass().getResource("/hsb/view/ui/node_f_s.fxml"));
            pane.getChildren().removeAll();
            pane.getChildren().setAll(start);
            
            home_tab.setStyle("-fx-background-color: rgb(221, 33, 187);");
            new_tab.setStyle("-fx-background-color: rgb(221, 33, 187);");
            faulty_tab.setStyle("-fx-background-color: rgb(188, 9, 87);-fx-background-radius:30 30 30 30;");
            bsc_to_faulty_tab.setStyle("-fx-background-color: rgb(221, 33, 187);");
                    } catch (IOException ex) {
            Logger.getLogger(NodeViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void add_to_faulty(MouseEvent event) throws IOException {
            Parent start = FXMLLoader.load(getClass().getResource("/hsb/view/ui/node_to_faulty.fxml"));
            pane.getChildren().removeAll();
            pane.getChildren().setAll(start);
            
            home_tab.setStyle("-fx-background-color: rgb(221, 33, 187);");
            new_tab.setStyle("-fx-background-color: rgb(221, 33, 187);");
            faulty_tab.setStyle("-fx-background-color: rgb(221, 33, 187);");
            bsc_to_faulty_tab.setStyle("-fx-background-color: rgb(188, 9, 87);-fx-background-radius:30 30 30 30;");
    }
    
}
