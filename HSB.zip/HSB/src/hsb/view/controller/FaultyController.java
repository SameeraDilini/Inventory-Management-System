/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import static com.sun.javafx.util.Utils.split;
import hsb.controller.ControllerFactory;
import hsb.controller.custom.FaultsController;
import hsb.controller.custom.HistoryController;
import hsb.controller.custom.InvenController;
import hsb.controller.custom.UserController;
import hsb.dto.FaultyDTO;
import hsb.dto.InvenDTO;
import hsb.dto.TransactionDTO;
import hsb.view.model.faulty_tablemodel;
import hsb.view.model.home_tablemodel;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import tray.animations.AnimationType;
import tray.notification.NotificationType;
import tray.notification.TrayNotification;

/**
 * FXML Controller class
 *
 * @author user
 */
public class FaultyController implements Initializable {

    @FXML
    private Label lbluser;
    @FXML
    private Label lbldate;
    @FXML
    private Label lbltime;
    @FXML
    private TableView<faulty_tablemodel> tbl_faulty;
    @FXML
    private ComboBox<String> cmb_y_n;
    
    @FXML
    private Button btn_replace;
    @FXML
    private TextField txt_sub_invetory;
    @FXML
    private TextField txt_locator;
    @FXML
    private TextField txt_location;
    @FXML
    private TextField txt_adv_serial_no;
    
    ArrayList<String> arraylist;
    @FXML
    private Label lbl_adv_serial_no;
    @FXML
    private TextField txt_erp_item_code;
    @FXML
    private TextField txt_erp_no;
    
    @FXML
    private DatePicker txt_man_date;
    @FXML
    private TextField txt_board_name;
    
    
     private InvenDTO inventory;

     private ArrayList<String> A_list;
    @FXML
    private ComboBox<String> cmb_vendor;
    @FXML
    private ComboBox<String> cmb_serial_no;
    
    ArrayList<String> arraylist_f;
    ArrayList<String> arraylist_f2;
    
    
    /**
     * Initializes the controller class.
     */
    
    
    public FaultyController(){
        
        
        
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
        
        try {
            
            
            
            try {
                try {
                    UserController controller=(UserController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.USER);
                    String user=controller.getLogged_username();
                    lbluser.setText(user);
                    
                    
                    
                    //date and time
                    
                    Date date = new Date();
                    String strDateFormat = "hh:mm:ss a";
                    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
                    String formattedDate= dateFormat.format(date);
                    System.out.println("Current time of the day using Date - 12 hour format: " + formattedDate);
                    lbltime.setText(formattedDate);
                    
                    
                    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
                    LocalDate localDate = LocalDate.now();
                    System.out.println(dtf.format(localDate)); //2016/11/16
                    
                    SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
                    String strDate = formatter.format(date);
                    lbldate.setText(strDate);
                    
                    arraylist_f=new ArrayList<>();
            FaultsController fcontroller=(FaultsController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.FAULTS);
            ArrayList<FaultyDTO> spares = fcontroller.getAll_ack();

            spares.forEach((dto_sp) -> {
                arraylist_f.add(dto_sp.getSerial_no());
            });

            cmb_serial_no.setEditable(true);
            ObservableList<String> items_sp = FXCollections.observableArrayList(arraylist_f);

            FilteredList<String> filteredItems_sp = new FilteredList<String>(items_sp, p_sp -> true);
            cmb_serial_no.getEditor().textProperty().addListener((obs_sp, oldValue_sp, newValue_sp) -> {
                final TextField editor_sp = cmb_serial_no.getEditor();
                final String selected_sp = cmb_serial_no.getSelectionModel().getSelectedItem();

                // This needs run on the GUI thread to avoid the error described
                // here: https://bugs.openjdk.java.net/browse/JDK-8081700.
                Platform.runLater(() -> {
                    // If the no item in the list is selected or the selected item
                    // isn't equal to the current input, we refilter the list.
                    if (selected_sp == null || !selected_sp.equals(editor_sp.getText())) {
                        filteredItems_sp.setPredicate(itemsp -> {
                            // We return true for any items that starts with the
                            // same letters as the input. We use toUpperCase to
                            // avoid case sensitivity.
                            if (itemsp.toUpperCase().startsWith(newValue_sp.toUpperCase())) {
                                return true;
                            } else {
                                return false;
                            }
                        });
                    }
                });
            });

                    cmb_serial_no.setItems(filteredItems_sp);
                } catch (Exception ex) {
                    Logger.getLogger(Side_nav_homeController.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                
                tbl_faulty.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("Serial_Number"));
                tbl_faulty.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("Vendor"));
                tbl_faulty.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("ERP_Item_Code"));
                tbl_faulty.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("Board_Name"));
                tbl_faulty.getColumns().get(4).setCellValueFactory(new PropertyValueFactory<>("Added_Date"));
                tbl_faulty.getColumns().get(5).setCellValueFactory(new PropertyValueFactory<>("Added_By"));
                tbl_faulty.getColumns().get(6).setCellValueFactory(new PropertyValueFactory<>("Acknowledged_Date"));
                
                LocalDate localDate = LocalDate.now();
                Date date = java.sql.Date.valueOf(localDate);
                //node_home view
                FaultsController controller=(FaultsController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.FAULTS);
                ArrayList<FaultyDTO> faults = controller.getAll();
                ArrayList<faulty_tablemodel> all_faults = new ArrayList<faulty_tablemodel>();
                for (FaultyDTO dto : faults) {
                    all_faults.add(new faulty_tablemodel(
                            dto.getSerial_no(),
                            dto.getVendor(),
                            dto.getErp_item_code(),
                            dto.getBoard_name(),
                            dto.getAdded_date(),
                            dto.getAdded_by()
                            
                            
                            
                    ));
                }
                
                ArrayList<FaultyDTO> faulty_ack = controller.getAll_ack();
                            for (FaultyDTO dto_ack : faulty_ack) {
                            
                                all_faults.add(new faulty_tablemodel(
                                                dto_ack.getSerial_no(),
                                                dto_ack.getVendor(),
                                                dto_ack.getErp_item_code(),
                                                dto_ack.getBoard_name(),
                                                dto_ack.getAdded_date(),
                                                dto_ack.getAdded_by(),
                                                dto_ack.getAdded_date_ack()


                                        ));
                            
                            }
                ObservableList<faulty_tablemodel> allnodes = FXCollections.observableArrayList(all_faults);
                
//                tbl_faulty.getSelectionModel().setCellSelectionEnabled(true);
//                tbl_faulty.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

                UserController controller2=(UserController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.USER);
                String user=controller2.getLogged_username();
                MenuItem item = new MenuItem("Send to repair");
                item.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        
                        try {
                            
                            LocalDate localDate = LocalDate.now();
                            Date date = java.sql.Date.valueOf(localDate);
                            
                            System.out.println(tbl_faulty.getSelectionModel().getSelectedItem().getSerial_Number());
                            String ack_serial_no=tbl_faulty.getSelectionModel().getSelectedItem().getSerial_Number();
                            FaultyDTO f_dto=controller.getByID(ack_serial_no);
                            System.out.println(f_dto);
                            boolean check_ack_rep=controller.check_repetition_ack(ack_serial_no);
                            if(check_ack_rep==true){
                            
                                Alert alert = new Alert(Alert.AlertType.ERROR);
                                alert.setTitle("Error Dialog");
                                alert.setHeaderText("Look, an Error Dialog");
                                alert.setContentText("Ooops, Already Added!");

                                alert.showAndWait();
                            
                            
                            
                            }else{
                            FaultyDTO ack_dto=new FaultyDTO(f_dto.getSerial_no(),
                                                            f_dto.getVendor(),
                                                            f_dto.getErp_item_code(),
                                                            f_dto.getBoard_name(),
                                                            f_dto.getAdded_date(),
                                                            f_dto.getAdded_by(),
                                                            date,
                                                            user);
                            boolean ack=controller.add_acknowledgement(ack_dto);
                            System.out.println(ack);
                            
                            
                            boolean fault=controller.delete(ack_serial_no);
                            
                            TransactionDTO transaction=new TransactionDTO(ack_serial_no,
                                                                            "",
                                                                            "",
                                                                            "",
                                                                            "",
                                                                            "",
                                                                            "",
                                                                            "",
                                                                            date,user,"Sent To Repair");
                            
                            HistoryController history_controller=(HistoryController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.HISTORY);
                            boolean history=history_controller.add(transaction);
                            
                            if(ack==true && fault==true && history){
                            
                                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                alert.setTitle("Information Dialog");
                                alert.setHeaderText(null);
                                alert.setContentText("Successfully Acknowleged!");

                                alert.showAndWait();
                            
                                
                                
                                
                                //node_home view
                            
                            ArrayList<FaultyDTO> faults = controller.getAll();
                            ArrayList<faulty_tablemodel> all_faults = new ArrayList<faulty_tablemodel>();
                            for (FaultyDTO dto : faults) {
                                all_faults.add(new faulty_tablemodel(
                                        dto.getSerial_no(),
                                        dto.getVendor(),
                                        dto.getErp_item_code(),
                                        dto.getBoard_name(),
                                        dto.getAdded_date(),
                                        dto.getAdded_by()



                                ));
                            }
                            
                            ArrayList<FaultyDTO> faulty_ack = controller.getAll_ack();
                            for (FaultyDTO dto_ack : faulty_ack) {
                            
                                all_faults.add(new faulty_tablemodel(
                                                dto_ack.getSerial_no(),
                                                dto_ack.getVendor(),
                                                dto_ack.getErp_item_code(),
                                                dto_ack.getBoard_name(),
                                                dto_ack.getAdded_date(),
                                                dto_ack.getAdded_by(),
                                                dto_ack.getAdded_date_ack()


                                        ));
                            
                            }
                            ObservableList<faulty_tablemodel> allnodes = FXCollections.observableArrayList(all_faults);

                            tbl_faulty.setItems(allnodes);
                            

                            arraylist_f2=new ArrayList<>();
                            ArrayList<FaultyDTO> faults_ack = controller.getAll_ack();
                            faults_ack.forEach((dto_sp) -> {
                                arraylist_f2.add(dto_sp.getSerial_no());
                            });
                            ObservableList<String> list=FXCollections.observableArrayList(arraylist_f2);
                            cmb_serial_no.setItems(list);
                            
                            
                            
                            }else{
                            
                                Alert alert = new Alert(Alert.AlertType.ERROR);
                                alert.setTitle("Error Dialog");
                                alert.setHeaderText("Look, an Error Dialog");
                                alert.setContentText("Ooops, there was an error!");

                                alert.showAndWait();
                            
                            
                            }
                            
                            }
                        } catch (Exception ex) {
                            Logger.getLogger(FaultyController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                            
                           
                    }
                });
                ContextMenu menu = new ContextMenu();
                menu.getItems().add(item);
                tbl_faulty.setContextMenu(menu);
                tbl_faulty.setItems(allnodes);
                
              
                
                

            } catch (Exception ex) {
                Logger.getLogger(FaultyController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            lbl_adv_serial_no.setVisible(false);
            txt_adv_serial_no.setVisible(false);
            
            arraylist=new ArrayList<>();
            arraylist.add("YES");
            arraylist.add("NO");
            
            ObservableList<String> list=FXCollections.observableArrayList(arraylist);
            cmb_y_n.getItems().add(list.get(0));
            cmb_y_n.getItems().add(list.get(1));
            
            cmb_y_n.valueProperty().addListener(new ChangeListener<String>() {
                @Override
                public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
            //                 System.out.println(cmb_y_n.getValue());
            if(cmb_y_n.getSelectionModel().getSelectedItem()=="YES"){

                lbl_adv_serial_no.setVisible(true);
                txt_adv_serial_no.setVisible(true);

            }else{

                lbl_adv_serial_no.setVisible(false);
                txt_adv_serial_no.setVisible(false);
            }
                            }
                        });
            //                System.out.println(cmb_y_n.getValue());

            cmb_y_n.getSelectionModel().selectLast();

            A_list=new ArrayList<>();
            A_list.add("ZTE");
            A_list.add("HUAWEI");

            ObservableList<String> list2=FXCollections.observableArrayList(A_list);
            cmb_vendor.getItems().add(list2.get(0));
            cmb_vendor.getItems().add(list2.get(1));
            cmb_vendor.getSelectionModel().selectFirst();

            

        } catch (Exception ex) {
            Logger.getLogger(FaultyController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }    

    @FXML
    private void replace(MouseEvent event) throws Exception {
       if(cmb_serial_no.getSelectionModel().getSelectedItem()==null){
        
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, Fill the Serial Number!");

            alert.showAndWait();
        
            cmb_serial_no.getSelectionModel().clearSelection();
            
            txt_board_name.clear();
            txt_sub_invetory.clear();
            txt_locator.clear();
            txt_location.clear();
            txt_erp_item_code.clear();
            txt_erp_no.clear();
            txt_man_date.getEditor().clear();
        
        }else{
            InvenController invencontroller=(InvenController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.INVEN);
            boolean rep=invencontroller.check_repetition(cmb_serial_no.getSelectionModel().getSelectedItem());    

        if(rep==true){
        Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, Already Added!");

            alert.showAndWait();
        
            cmb_serial_no.getSelectionModel().clearSelection();
            
            txt_board_name.clear();
            txt_sub_invetory.clear();
            txt_locator.clear();
            txt_location.clear();
            txt_erp_item_code.clear();
            txt_erp_no.clear();
            txt_man_date.getEditor().clear();
        }else{
        
        
    
            if(txt_man_date.getValue()!=null){
                try {
                    String strDateFormat = "YYYY-MM-DD";
                    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
//        Date manufac_date=dateFormat.parse(txt_man_date.getText());
        


        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate localDate = LocalDate.now();
        Date date = java.sql.Date.valueOf(localDate);

        Date manufac_date=java.sql.Date.valueOf(txt_man_date.getValue());
         if(manufac_date.after(date)){
         
             Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops !  You cannot add future dates!");

            alert.showAndWait();
         
         }else{

        UserController controller_user=(UserController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.USER);
        String user=controller_user.getLogged_username();

        
        

        if(cmb_y_n.getValue().equals("YES")){
            
            if(txt_adv_serial_no.getText().equals("") || 
                    txt_board_name.getText().equals("") || 
                    txt_erp_item_code.getText().equals("") || 
                    txt_erp_no.getText().equals("") || 
                    txt_location.getText().equals("") || 
                    txt_locator.getText().equals("") || 
                    txt_sub_invetory.getText().equals("")
                    ){
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, Fill all the fields!");

            alert.showAndWait();
                
            
            
            
            }else{
        
            inventory=new InvenDTO(txt_adv_serial_no.getText(),
                        cmb_vendor.getSelectionModel().getSelectedItem(),
                        txt_sub_invetory.getText().toUpperCase(),
                        txt_locator.getText().toUpperCase(),
                        txt_location.getText().toUpperCase(),
                        date,
                        user,
                        txt_erp_item_code.getText().toUpperCase(),
                        txt_erp_no.getText().toUpperCase(),
                        txt_board_name.getText().toUpperCase(),
                        manufac_date,
                        ""
        );
        InvenController controller=(InvenController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.INVEN);
        Boolean check=controller.add(inventory);
        
        FaultsController f_controller=(FaultsController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.FAULTS);
        boolean fault=f_controller.adv_replacment(cmb_serial_no.getSelectionModel().getSelectedItem());

        System.out.println(check);

        TransactionDTO transaction=new TransactionDTO(cmb_serial_no.getSelectionModel().getSelectedItem(),
                txt_location.getText(),
                "",
                txt_sub_invetory.getText(),
                txt_locator.getText(),
                txt_board_name.getText(),
                "ADVANCED",
                txt_adv_serial_no.getText(),
                date,user,"Replaced");
        
        TransactionDTO transaction2=new TransactionDTO(txt_adv_serial_no.getText(),
                "",
                txt_location.getText(),
                txt_sub_invetory.getText(),
                txt_locator.getText(),
                txt_board_name.getText(),
                "ADVANCED",
                "before : "+cmb_serial_no.getSelectionModel().getSelectedItem(),
                date,user,"Added to Spare List");


        HistoryController history_controller=(HistoryController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.HISTORY);
        boolean history=history_controller.add(transaction);
        boolean history2=history_controller.add(transaction2);
        
        if(check==true && fault==true && history==true && history2==true){

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Successfully Replaced!");

            alert.showAndWait();

            cmb_serial_no.getSelectionModel().clearSelection();
            
            txt_board_name.clear();
            txt_sub_invetory.clear();
            txt_locator.clear();
            txt_location.clear();
            txt_erp_item_code.clear();
            txt_erp_no.clear();
            txt_man_date.getEditor().clear();
            txt_adv_serial_no.setText("");
            
            //node_home view
            FaultsController controller2=(FaultsController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.FAULTS);
            ArrayList<FaultyDTO> faults = controller2.getAll();
            ArrayList<faulty_tablemodel> all_faults = new ArrayList<faulty_tablemodel>();
            for (FaultyDTO dto : faults) {
                all_faults.add(new faulty_tablemodel(
                        dto.getSerial_no(),
                        dto.getVendor(),
                        dto.getErp_item_code(),
                        dto.getBoard_name(),
                        dto.getAdded_date(),
                        dto.getAdded_by()
                        
                        
                        
                ));
            }
            ArrayList<FaultyDTO> faulty_ack = controller2.getAll_ack();
                            for (FaultyDTO dto_ack : faulty_ack) {
                            
                                all_faults.add(new faulty_tablemodel(
                                                dto_ack.getSerial_no(),
                                                dto_ack.getVendor(),
                                                dto_ack.getErp_item_code(),
                                                dto_ack.getBoard_name(),
                                                dto_ack.getAdded_date(),
                                                dto_ack.getAdded_by(),
                                                dto_ack.getAdded_date_ack()


                                        ));
                            
                            }
            ObservableList<faulty_tablemodel> allnodes = FXCollections.observableArrayList(all_faults);

            tbl_faulty.setItems(allnodes);
            
           ArrayList<String> arraylist_f3=new ArrayList<>();
           ArrayList<FaultyDTO> faults_ack2 = controller2.getAll_ack();
           faults_ack2.forEach((dto_sp) -> {
           arraylist_f3.add(dto_sp.getSerial_no());
           });
           ObservableList<String> list2=FXCollections.observableArrayList(arraylist_f3);
           cmb_serial_no.setItems(list2);


        }
        else{

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, there was an error!");

            alert.showAndWait();

            cmb_serial_no.getSelectionModel().clearSelection();
            
            txt_board_name.clear();
            txt_sub_invetory.clear();
            txt_locator.clear();
            txt_location.clear();
            txt_erp_item_code.clear();
            txt_erp_no.clear();
            txt_man_date.getEditor().clear();
            


        }  
            }
        
        }
        
        if(cmb_y_n.getValue().equals("NO")){
            
                    if(txt_board_name.getText().equals("") || 
                    txt_erp_item_code.getText().equals("") || 
                    txt_erp_no.getText().equals("") || 
                    txt_location.getText().equals("") || 
                    txt_locator.getText().equals("") || 
                    txt_sub_invetory.getText().equals("")
                    ){
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, Fill all the fields!");

            alert.showAndWait();
                
            
            
            
            }else{
        
            InvenDTO inventory2=new InvenDTO(cmb_serial_no.getSelectionModel().getSelectedItem(),
                cmb_vendor.getSelectionModel().getSelectedItem(),
                txt_sub_invetory.getText().toUpperCase(),
                txt_locator.getText().toUpperCase(),
                txt_location.getText().toUpperCase(),
                date,
                user,
                txt_erp_item_code.getText().toUpperCase(),
                txt_erp_no.getText().toUpperCase(),
                txt_board_name.getText().toUpperCase(),
                manufac_date,
                ""
        );
        InvenController controller2=(InvenController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.INVEN);
        Boolean check2=controller2.add(inventory2);
        
        FaultsController f_controller2=(FaultsController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.FAULTS);
        boolean fault2=f_controller2.adv_replacment(cmb_serial_no.getSelectionModel().getSelectedItem());

        

        TransactionDTO transaction2=new TransactionDTO(cmb_serial_no.getSelectionModel().getSelectedItem(),
                "",
                txt_location.getText(),
                txt_sub_invetory.getText(),
                txt_locator.getText(),
                txt_board_name.getText(),
                "",
                "",
                date,user,"Added to Spare List");


        HistoryController history_controller2=(HistoryController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.HISTORY);
        boolean history2=history_controller2.add(transaction2);

        
        if(check2==true && fault2==true && history2==true){

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Successfully Added!");

            alert.showAndWait();

            cmb_serial_no.getSelectionModel().clearSelection();
            
            txt_board_name.clear();
            txt_sub_invetory.clear();
            txt_locator.clear();
            txt_location.clear();
            txt_erp_item_code.clear();
            txt_erp_no.clear();
            txt_man_date.getEditor().clear();
            txt_adv_serial_no.setText("");
            
            //node_home view
            FaultsController controller3=(FaultsController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.FAULTS);
            ArrayList<FaultyDTO> faults = controller3.getAll();
            ArrayList<faulty_tablemodel> all_faults = new ArrayList<faulty_tablemodel>();
            for (FaultyDTO dto : faults) {
                all_faults.add(new faulty_tablemodel(
                        dto.getSerial_no(),
                        dto.getVendor(),
                        dto.getErp_item_code(),
                        dto.getBoard_name(),
                        dto.getAdded_date(),
                        dto.getAdded_by()
                        
                        
                ));
            }
            ArrayList<FaultyDTO> faulty_ack = controller3.getAll_ack();
                            for (FaultyDTO dto_ack : faulty_ack) {
                            
                                all_faults.add(new faulty_tablemodel(
                                                dto_ack.getSerial_no(),
                                                dto_ack.getVendor(),
                                                dto_ack.getErp_item_code(),
                                                dto_ack.getBoard_name(),
                                                dto_ack.getAdded_date(),
                                                dto_ack.getAdded_by(),
                                                dto_ack.getAdded_date_ack()


                                        ));
                            
                            }
            ObservableList<faulty_tablemodel> allnodes = FXCollections.observableArrayList(all_faults);

            tbl_faulty.setItems(allnodes);
            ArrayList<String> arraylist_f4=new ArrayList<>();
           ArrayList<FaultyDTO> faults_ack3 = controller3.getAll_ack();
           faults_ack3.forEach((dto_sp) -> {
           arraylist_f4.add(dto_sp.getSerial_no());
           });
           ObservableList<String> list3=FXCollections.observableArrayList(arraylist_f4);
           cmb_serial_no.setItems(list3);


        }
        else{

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, there was an error!");

            alert.showAndWait();

            cmb_serial_no.getSelectionModel().clearSelection();
            
            txt_board_name.clear();
            txt_sub_invetory.clear();
            txt_locator.clear();
            txt_location.clear();
            txt_erp_item_code.clear();
            txt_erp_no.clear();
            txt_man_date.getEditor().clear();


        }  
        
        }
        
        }
        
                }
        
        
             } catch (Exception ex) {
                            Logger.getLogger(FaultyController.class.getName()).log(Level.SEVERE, null, ex);
                        }
        }else{

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, Please Fill the Date!");

            alert.showAndWait();


                    }
            
       
        
       
        
        }
        
        }
    }

    @FXML
    private void export(MouseEvent event) {
        
        try {
            SimpleDateFormat formatter2 = new SimpleDateFormat("dd/MM/yyyy");
            
            FaultsController controller3=(FaultsController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.FAULTS);
            ArrayList<FaultyDTO> faults = controller3.getAll();
            ArrayList<faulty_tablemodel> all_faults = new ArrayList<faulty_tablemodel>();
            for (FaultyDTO dto : faults) {
                all_faults.add(new faulty_tablemodel(
                        dto.getSerial_no(),
                        dto.getVendor(),
                        dto.getErp_item_code(),
                        dto.getBoard_name(),
                        dto.getAdded_date(),
                        dto.getAdded_by()
                        
                        
                        
                ));
            }
            ArrayList<FaultyDTO> faulty_ack = controller3.getAll_ack();
            for (FaultyDTO dto_ack : faulty_ack) {
                
                all_faults.add(new faulty_tablemodel(
                        dto_ack.getSerial_no(),
                        dto_ack.getVendor(),
                        dto_ack.getErp_item_code(),
                        dto_ack.getBoard_name(),
                        dto_ack.getAdded_date(),
                        dto_ack.getAdded_by(),
                        formatter2.format(dto_ack.getAdded_date_ack())
                        
                        
                ));
                
            }
            writeListToExcel(all_faults);
        } catch (Exception ex) {
            Logger.getLogger(FaultyController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void writeListToExcel(ArrayList<faulty_tablemodel> faulty_list){
 
        
        // Using XSSF for xlsx format, for xls use HSSF
        Workbook workbook = new HSSFWorkbook();
 
        Sheet sheet = workbook.createSheet("All Faults");
 
        
        Row rw=sheet.createRow(0);
        rw.createCell(0).setCellValue("Serial_No");
        rw.createCell(1).setCellValue("Vendor");
        rw.createCell(2).setCellValue("ERP Item Code");
        rw.createCell(3).setCellValue("Board Name");
        rw.createCell(4).setCellValue("Added Date");
        rw.createCell(5).setCellValue("Added By");
        rw.createCell(6).setCellValue("Acknowledged_Date");
        
        
        
        
        int rowIndex = 1;
//        for(Student student : studentList){
            for (faulty_tablemodel tm: faulty_list){
                
            Row row = sheet.createRow(rowIndex++);
            
            int cellIndex = 0;
            
            row.createCell(cellIndex++).setCellValue(tm.getSerial_Number());
            row.createCell(cellIndex++).setCellValue(tm.getVendor());
            row.createCell(cellIndex++).setCellValue(tm.getERP_Item_Code());
            row.createCell(cellIndex++).setCellValue(tm.getBoard_Name());
            
 
            
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
            String strDate = formatter.format(tm.getAdded_Date());
            row.createCell(cellIndex++).setCellValue(strDate);
 
            
            row.createCell(cellIndex++).setCellValue(tm.getAdded_By());
            
            row.createCell(cellIndex++).setCellValue(tm.getAcknowledgement());
            
               

 
        }
 
        //write this workbook in excel file.
        try {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Save to Excel");
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Microsoft Office Excel 2013", "*.xls"));
            File selectedFile = fileChooser.showSaveDialog(null);
            if (selectedFile != null) {
            TrayNotification tray = new TrayNotification();
            FileOutputStream fileout = new FileOutputStream(selectedFile.getAbsoluteFile());
            workbook.write(fileout);
            fileout.close();
 
            System.out.println(selectedFile.getAbsoluteFile() + " is successfully written");
            tray.setNotificationType(NotificationType.SUCCESS);
            tray.setTitle("Save Success");
            tray.setMessage("File has been successfully saved");
            tray.setAnimationType(AnimationType.POPUP);
            tray.showAndDismiss(javafx.util.Duration.millis(1000));
            tray.setRectangleFill(javafx.scene.paint.Color.valueOf("#4183D7"));
//            tray.setImage(new Image("/img/icons8_Ok_96px.png"));
            
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
 
 
    }
    
    
    
}
