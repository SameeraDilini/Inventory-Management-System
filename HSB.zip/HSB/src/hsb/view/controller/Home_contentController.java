/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import hsb.controller.ControllerFactory;
import hsb.controller.custom.FaultsController;
import hsb.controller.custom.NodeSectionController;
import hsb.dto.FaultyDTO;
import hsb.dto.bsc_DTO;
import hsb.view.model.home_tablemodel;
import hsb.view.model.nodes_tablemodel;
import impl.org.controlsfx.spreadsheet.CellView;
import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DataFormat;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import tray.animations.AnimationType;
import tray.notification.NotificationType;
import tray.notification.TrayNotification;

/**
 * FXML Controller class
 *
 * @author user
 */
public class Home_contentController implements Initializable {

    @FXML
    private TableView<home_tablemodel> table_fault_home;
    @FXML
    private HBox activeColumn;
    @FXML
    private TableColumn<home_tablemodel, Date> ack_col;

    boolean flag=false;
    @FXML
    private HBox activeColumn1;
    private ArrayList<home_tablemodel> all_faulty;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        try {
            table_fault_home.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("Serial_No"));
            table_fault_home.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("Board"));
            table_fault_home.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("Faulty_List_Added_Date"));
            table_fault_home.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("User"));
            table_fault_home.getColumns().get(4).setCellValueFactory(new PropertyValueFactory<>("Acknowledged_Date"));
            
            LocalDate localDate = LocalDate.now();
            Date date = java.sql.Date.valueOf(localDate);
            
            SimpleDateFormat formatter2 = new SimpleDateFormat("dd/MM/yyyy");
//            String strDate2 = formatter2.format(tm.getAcknowledged_Date());
            
            //node_home view
            FaultsController controller=(FaultsController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.FAULTS);
            ArrayList<FaultyDTO> faulty = controller.getAll();
            all_faulty = new ArrayList<home_tablemodel>();
            for (FaultyDTO dto : faulty) {
                
                
                
                Date date_2=dto.getAdded_date();
                
                long diffInMillies = Math.abs(date.getTime() - date_2.getTime());
                long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
                

                if(diff>=45){
                
                    all_faulty.add(new home_tablemodel(
                        dto.getSerial_no(),
                        dto.getBoard_name(),
                        dto.getAdded_date(),
                        dto.getAdded_by()
                        
                        
                        ));

                        }
                
            }
                ArrayList<FaultyDTO> faulty_ack = controller.getAll_ack();
                
                for (FaultyDTO dto_ack : faulty_ack) {
                  
                Date date_3=dto_ack.getAdded_date_ack();
                
                long diffInMillies_2 = Math.abs(date.getTime() - date_3.getTime());
                long diff_2 = TimeUnit.DAYS.convert(diffInMillies_2, TimeUnit.MILLISECONDS);
                

                if(diff_2>=45){
                
                    
                    
                    all_faulty.add(new home_tablemodel(
                        dto_ack.getSerial_no(),
                        dto_ack.getBoard_name(),
                        dto_ack.getAdded_date(),
                        dto_ack.getAdded_by(),
                        formatter2.format(dto_ack.getAdded_date_ack())
                        
                        
                        
                ));
                    
                    
                    
                }
                
                }
                
                   

                ObservableList<home_tablemodel> allfaulties = FXCollections.observableArrayList(all_faulty);
                
                
                

//                table_fault_home.getSelectionModel().setCellSelectionEnabled(true);
//                table_fault_home.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

                MenuItem item = new MenuItem("Copy");
                item.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        ObservableList<TablePosition> posList = table_fault_home.getSelectionModel().getSelectedCells();
                        int old_r = -1;
                        StringBuilder clipboardString = new StringBuilder();
                        for (TablePosition p : posList) {
                            int r = p.getRow();
                            int c = p.getColumn();
                            Object cell = table_fault_home.getColumns().get(c).getCellData(r);
                            if (cell == null)
                                cell = "";
                            if (old_r == r)
                                clipboardString.append('\t');
                            else if (old_r != -1)
                                clipboardString.append('\n');
                            clipboardString.append(cell);
                            old_r = r;
                            
                            
                            
                        }
                        final ClipboardContent content = new ClipboardContent();
                        content.putString(clipboardString.toString());
                        Clipboard.getSystemClipboard().setContent(content);
//                        System.out.println(Clipboard.getSystemClipboard().getString());
                        
                       
                    }
                });
                ContextMenu menu = new ContextMenu();
                menu.getItems().add(item);
                table_fault_home.setContextMenu(menu);
                        
                        

                table_fault_home.setItems(allfaulties);
               
                table_fault_home.setRowFactory(tv -> new TableRow<home_tablemodel>() {
                        @Override
                        public void updateItem(home_tablemodel item, boolean empty) {
                            super.updateItem(item, empty) ;
                            if (item == null) {
                                setStyle("");
                            } else if (item.getAcknowledged_Date()!=null) {
                                setStyle("-fx-background-color: rgb(134, 234, 91);");
                            } else {
                                setStyle("");
                            }
                        }
                    });
                
            
            
//             home_tab.setStyle("-fx-background-color: rgb(91, 23, 76);");
            
   
        } catch (Exception ex) {
            Logger.getLogger(Home_contentController.class.getName()).log(Level.SEVERE, null, ex);
        }
            
       
        
    }

    @FXML
    private void export(MouseEvent event) {
        
        writeListToExcel(all_faulty);
    }
    
    public static void writeListToExcel(ArrayList<home_tablemodel> faulty_list){
 
        
        // Using XSSF for xlsx format, for xls use HSSF
        Workbook workbook = new HSSFWorkbook();
 
        Sheet sheet = workbook.createSheet("Faults");
 
        
        Row rw=sheet.createRow(0);
        rw.createCell(0).setCellValue("Serial_No");
        rw.createCell(1).setCellValue("Board");
        rw.createCell(2).setCellValue("Faulty_List_Added Date");
        rw.createCell(3).setCellValue("User");
        rw.createCell(4).setCellValue("Acknowledged_date");
        
        
        
        int rowIndex = 1;
//        for(Student student : studentList){
            for (home_tablemodel tm: faulty_list){
                
            Row row = sheet.createRow(rowIndex++);
            
            int cellIndex = 0;
            
            row.createCell(cellIndex++).setCellValue(tm.getSerial_No());
            
            
            row.createCell(cellIndex++).setCellValue(tm.getBoard());
 
            
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
            String strDate = formatter.format(tm.getFaulty_List_Added_Date());
            row.createCell(cellIndex++).setCellValue(strDate);
 
            
            row.createCell(cellIndex++).setCellValue(tm.getUser());
            row.createCell(cellIndex++).setCellValue(tm.getAcknowledged_Date());

//                System.out.println(strDate2);
 
        }
 
        //write this workbook in excel file.
        try {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Save to Excel");
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Microsoft Office Excel 2013", "*.xls"));
            File selectedFile = fileChooser.showSaveDialog(null);
            if (selectedFile != null) {
            TrayNotification tray = new TrayNotification();
            FileOutputStream fileout = new FileOutputStream(selectedFile.getAbsoluteFile());
            workbook.write(fileout);
            fileout.close();
 
            System.out.println(selectedFile.getAbsoluteFile() + " is successfully written");
            tray.setNotificationType(NotificationType.SUCCESS);
            tray.setTitle("Save Success");
            tray.setMessage("File has been successfully saved");
            tray.setAnimationType(AnimationType.POPUP);
            tray.showAndDismiss(javafx.util.Duration.millis(1000));
            tray.setRectangleFill(javafx.scene.paint.Color.valueOf("#4183D7"));
//            tray.setImage(new Image("/img/icons8_Ok_96px.png"));
            
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
 
 
    }


           
    
}
