/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import hsb.controller.ControllerFactory;
import hsb.controller.custom.NodeSectionController;
import hsb.dto.Node_FaultyDTO;
import hsb.dto.bsc_DTO;
import hsb.view.model.home_tablemodel;
import hsb.view.model.nodes_tablemodel;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import tray.animations.AnimationType;
import tray.notification.NotificationType;
import tray.notification.TrayNotification;

/**
 * FXML Controller class
 *
 * @author user
 */
public class Node_startupController implements Initializable {

    @FXML
    private TableView<nodes_tablemodel> table_nodes;
    ArrayList<nodes_tablemodel> all_nodes;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            table_nodes.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("Serial_No"));
            table_nodes.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("Vendor"));
            table_nodes.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("BSC_Name"));
            table_nodes.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("Physical_Name"));
            table_nodes.getColumns().get(4).setCellValueFactory(new PropertyValueFactory<>("Logical_Name"));
            table_nodes.getColumns().get(5).setCellValueFactory(new PropertyValueFactory<>("ERP_Item_Code"));
            table_nodes.getColumns().get(6).setCellValueFactory(new PropertyValueFactory<>("ERP_Name"));
            table_nodes.getColumns().get(7).setCellValueFactory(new PropertyValueFactory<>("Rack"));
            table_nodes.getColumns().get(8).setCellValueFactory(new PropertyValueFactory<>("Shelf"));
            table_nodes.getColumns().get(9).setCellValueFactory(new PropertyValueFactory<>("Slot"));
            table_nodes.getColumns().get(10).setCellValueFactory(new PropertyValueFactory<>("Added_By"));
            table_nodes.getColumns().get(11).setCellValueFactory(new PropertyValueFactory<>("Added_Date"));
            table_nodes.getColumns().get(12).setCellValueFactory(new PropertyValueFactory<>("Comment"));
        
  
            //node_home view
            NodeSectionController controller=(NodeSectionController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
            ArrayList<bsc_DTO> nodes = controller.getAllNodes();
            all_nodes = new ArrayList<nodes_tablemodel>();
            for (bsc_DTO dto : nodes) {
                all_nodes.add(new nodes_tablemodel(
                        dto.getSerial_no(),
                        dto.getVendor(),
                        dto.getBsc_rnc_name(),
                        dto.getPhysical_name(),
                        dto.getLogical_name(),
                        dto.getErp_item_code(),
                        dto.getErp_name(),
                        dto.getRack(),
                        dto.getSub_rack(),
                        dto.getSlot(),
                        dto.getAdded_by(),
                        dto.getDate(),
                        dto.getComment()
                        
                ));
            }
            ObservableList<nodes_tablemodel> allnodes = FXCollections.observableArrayList(all_nodes);
            
            

//                table_nodes.getSelectionModel().setCellSelectionEnabled(true);
//                table_nodes.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

                MenuItem item = new MenuItem("Copy");
                item.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        ObservableList<TablePosition> posList = table_nodes.getSelectionModel().getSelectedCells();
                        int old_r = -1;
                        StringBuilder clipboardString = new StringBuilder();
                        for (TablePosition p : posList) {
                            int r = p.getRow();
                            int c = p.getColumn();
                            Object cell = table_nodes.getColumns().get(c).getCellData(r);
                            if (cell == null)
                                cell = "";
                            if (old_r == r)
                                clipboardString.append('\t');
                            else if (old_r != -1)
                                clipboardString.append('\n');
                            clipboardString.append(cell);
                            old_r = r;
                        }
                        final ClipboardContent content = new ClipboardContent();
                        content.putString(clipboardString.toString());
                        Clipboard.getSystemClipboard().setContent(content);
                    }
                });
                ContextMenu menu = new ContextMenu();
                menu.getItems().add(item);
                table_nodes.setContextMenu(menu);

            table_nodes.setItems(allnodes);
            
            
        } catch (Exception ex) {
            Logger.getLogger(Node_startupController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }   

    @FXML
    private void export(MouseEvent event) {
       writeListToExcel(all_nodes);
    }
    
    public static void writeListToExcel(ArrayList<nodes_tablemodel> node_list){
 
        
        // Using XSSF for xlsx format, for xls use HSSF
        Workbook workbook = new HSSFWorkbook();
 
        Sheet sheet = workbook.createSheet("Nodes");
 
        
        Row rw=sheet.createRow(0);
        rw.createCell(0).setCellValue("Serial_No");
        rw.createCell(1).setCellValue("Vendor");
        rw.createCell(2).setCellValue("BSC Name");
        rw.createCell(3).setCellValue("Physical Name");
        rw.createCell(4).setCellValue("Logical Name");
        rw.createCell(5).setCellValue("ERP Item Code");
        rw.createCell(6).setCellValue("ERP Name");
        rw.createCell(7).setCellValue("Rack");
        rw.createCell(8).setCellValue("Shelf");
        rw.createCell(9).setCellValue("Slot");
        rw.createCell(10).setCellValue("Added By");
        rw.createCell(11).setCellValue("Added Date");
        rw.createCell(12).setCellValue("Comment");
        
        
        
        int rowIndex = 1;
//        for(Student student : studentList){
            for (nodes_tablemodel tm: node_list){
                
            Row row = sheet.createRow(rowIndex++);
            
            int cellIndex = 0;
            
            row.createCell(cellIndex++).setCellValue(tm.getSerial_No());
            
            
            row.createCell(cellIndex++).setCellValue(tm.getVendor());
            row.createCell(cellIndex++).setCellValue(tm.getBSC_Name());
            row.createCell(cellIndex++).setCellValue(tm.getPhysical_Name());
            row.createCell(cellIndex++).setCellValue(tm.getLogical_Name());
            row.createCell(cellIndex++).setCellValue(tm.getERP_Item_Code());
            row.createCell(cellIndex++).setCellValue(tm.getERP_Name());
            row.createCell(cellIndex++).setCellValue(tm.getRack());
            row.createCell(cellIndex++).setCellValue(tm.getShelf());
            row.createCell(cellIndex++).setCellValue(tm.getSlot());
            row.createCell(cellIndex++).setCellValue(tm.getAdded_By());
            
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
            String strDate = formatter.format(tm.getAdded_Date());
            row.createCell(cellIndex++).setCellValue(strDate);
 
            
            row.createCell(cellIndex++).setCellValue(tm.getComment());
            
 
        }
 
        //write this workbook in excel file.
        try {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Save to Excel");
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Microsoft Office Excel 2013", "*.xls"));
            File selectedFile = fileChooser.showSaveDialog(null);
            if (selectedFile != null) {
            TrayNotification tray = new TrayNotification();
            FileOutputStream fileout = new FileOutputStream(selectedFile.getAbsoluteFile());
            workbook.write(fileout);
            fileout.close();
 
            System.out.println(selectedFile.getAbsoluteFile() + " is successfully written");
            tray.setNotificationType(NotificationType.SUCCESS);
            tray.setTitle("Save Success");
            tray.setMessage("File has been successfully saved");
            tray.setAnimationType(AnimationType.POPUP);
            tray.showAndDismiss(javafx.util.Duration.millis(1000));
            tray.setRectangleFill(javafx.scene.paint.Color.valueOf("#4183D7"));
//            tray.setImage(new Image("/img/icons8_Ok_96px.png"));
            
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
 
 
    }
    
}
