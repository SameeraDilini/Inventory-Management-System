/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import hsb.controller.ControllerFactory;
import hsb.controller.custom.HistoryController;
import hsb.controller.custom.InvenController;
import hsb.controller.custom.NodeSectionController;
import hsb.controller.custom.UserController;
import hsb.dto.FaultyDTO;
import hsb.dto.InvenDTO;
import hsb.dto.Node_FaultyDTO;
import hsb.dto.SpareDTO;
import hsb.dto.TransactionDTO;
import hsb.dto.bsc_DTO;
import hsb.view.model.nodes_tablemodel;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author user
 */
public class Node_f_sController implements Initializable {

    @FXML
    private Label lbluser;
    @FXML
    private Label lbldate;
    @FXML
    private Label lbltime;
    
    @FXML
    private Label lbl_b_r_name;
    @FXML
    private Label lbl_br_boardd_name;
    @FXML
    private Label lbl_sub_inven;
    @FXML
    private Label lbl_rack_position;
    @FXML
    private Label lbl_locator;
    @FXML
    private Label lbl_sub_rack_position;
    @FXML
    private Label lbl_location;
    @FXML
    private Label lbl_slot_position;
    @FXML
    private Label lbl_sp_manufac_date;
    @FXML
    private Label lbl_br_manufac_date;
    @FXML
    private Label lbl_sp_erp_numer;
    @FXML
    private Label lbl_erp_code;
    @FXML
    private Label lbl_br_erp_numer;
    @FXML
    private Button btn_replace;
    @FXML
    private Label lbl_sp_board_name;
    @FXML
    private TextField txtcomment;
    @FXML
    private ComboBox<String> cmb_bsc_ser;
    @FXML
    private ComboBox<String> cmb_spare_ser;
    private ArrayList<String> arraylist;
    private ArrayList<String> arraylist_sp;
    
    @FXML
    private Label lblcomment;
    @FXML
    private ComboBox<String> cmb_pass;
    private ArrayList<String> arraylist_pass;
    
    
    /**
     * Initializes the controller class.
     */
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
            try {
                
                try {
                    UserController controller=(UserController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.USER);
                    String user=controller.getLogged_username();
                    lbluser.setText(user);
                    
                    //date & time
                    
                    Date date = new Date();
                    String strDateFormat = "hh:mm:ss a";
                    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
                    String formattedDate= dateFormat.format(date);
                    System.out.println("Current time of the day using Date - 12 hour format: " + formattedDate);
                    lbltime.setText(formattedDate);
                    
                    
                    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
                    LocalDate localDate = LocalDate.now();
                    
                    System.out.println(dtf.format(localDate)); //2016/11/16
                    
                    SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
                    String strDate = formatter.format(date);
                    
//                  String strDate = dateFormat.format(localDate);
                    lbldate.setText(strDate);

                } catch (Exception ex) {
                    Logger.getLogger(Side_nav_homeController.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                // cmb pass
                
                arraylist_pass=new ArrayList<>();
                arraylist_pass.add("Faulty List");
                arraylist_pass.add("Spare List");

               ObservableList<String> list=FXCollections.observableArrayList(arraylist_pass);
                cmb_pass.getItems().add(list.get(0));
                cmb_pass.getItems().add(list.get(1));
                cmb_pass.getSelectionModel().selectFirst();
                
//                btn_replace.setVisible(false);
                arraylist=new ArrayList<>();
                NodeSectionController controller=(NodeSectionController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
                ArrayList<bsc_DTO> nodes = controller.getAllNodes();
                
                nodes.forEach((dto) -> {
                    arraylist.add(dto.getSerial_no());
                });
                
                cmb_bsc_ser.setEditable(true);
                ObservableList<String> items = FXCollections.observableArrayList(arraylist);
                
                FilteredList<String> filteredItems = new FilteredList<String>(items, p -> true);
                            cmb_bsc_ser.getEditor().textProperty().addListener((obsn, oldValuen, newValuen) -> {
                        final TextField editor = cmb_bsc_ser.getEditor();
                        final String selected = cmb_bsc_ser.getSelectionModel().getSelectedItem();

                        // This needs run on the GUI thread to avoid the error described
                        // here: https://bugs.openjdk.java.net/browse/JDK-8081700.
                        Platform.runLater(() -> {
                            // If the no item in the list is selected or the selected item
                            // isn't equal to the current input, we refilter the list.
                            if (selected == null || !selected.equals(editor.getText())) {
                                filteredItems.setPredicate(itemn -> {
                                    // We return true for any items that starts with the
                                    // same letters as the input. We use toUpperCase to
                                    // avoid case sensitivity.
                                    if (itemn.toUpperCase().startsWith(newValuen.toUpperCase())) {
                                        return true;
                                    } else {
                                        return false;
                                    }
                                });
                            }
                        });
                    });

                    cmb_bsc_ser.setItems(filteredItems);
                    
                    cmb_bsc_ser.valueProperty().addListener(new ChangeListener<String>() {
                    @Override
                    public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                        if(cmb_bsc_ser.getSelectionModel().getSelectedItem()!=null){
                        
                            try {
                                NodeSectionController controller=(NodeSectionController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
                                bsc_DTO node=controller.getById(cmb_bsc_ser.getSelectionModel().getSelectedItem());
                                
                                if(node!=null){
                                    lbl_b_r_name.setText(node.getBsc_rnc_name());
                                    lbl_br_boardd_name.setText(node.getPhysical_name());
                                    lbl_rack_position.setText(node.getRack());
                                    lbl_sub_rack_position.setText(node.getSub_rack());
                                    lbl_slot_position.setText(node.getSlot());
                                    
                                    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                                    String strDate = formatter.format(node.getManufac_date());
                                    
                                    
                                    lbl_br_manufac_date.setText(strDate);
                                    lbl_erp_code.setText(node.getErp_item_code());
                                    lbl_br_erp_numer.setText(node.getErp_name());
                                    lblcomment.setText(node.getComment());
                                    
                                   final int serial_no=node.getId();
                                    
                                }  } catch (Exception ex) {
                                Logger.getLogger(Node_f_sController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                        
                        }
                    }
                });
                    
                    
                    
                    
                    
                    
                
                arraylist_sp=new ArrayList<>();
                InvenController spcontroller=(InvenController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.INVEN);
                ArrayList<InvenDTO> spares = spcontroller.getAll();
                
                spares.forEach((dto_sp) -> {
                    arraylist_sp.add(dto_sp.getSerial_no());
                });
                
                cmb_spare_ser.setEditable(true);
                ObservableList<String> items_sp = FXCollections.observableArrayList(arraylist_sp);
                
                FilteredList<String> filteredItems_sp = new FilteredList<String>(items_sp, p_sp -> true);
                            cmb_spare_ser.getEditor().textProperty().addListener((obs_sp, oldValue_sp, newValue_sp) -> {
                        final TextField editor_sp = cmb_spare_ser.getEditor();
                        final String selected_sp = cmb_spare_ser.getSelectionModel().getSelectedItem();

                        // This needs run on the GUI thread to avoid the error described
                        // here: https://bugs.openjdk.java.net/browse/JDK-8081700.
                        Platform.runLater(() -> {
                            // If the no item in the list is selected or the selected item
                            // isn't equal to the current input, we refilter the list.
                            if (selected_sp == null || !selected_sp.equals(editor_sp.getText())) {
                                filteredItems_sp.setPredicate(itemsp -> {
                                    // We return true for any items that starts with the
                                    // same letters as the input. We use toUpperCase to
                                    // avoid case sensitivity.
                                    if (itemsp.toUpperCase().startsWith(newValue_sp.toUpperCase())) {
                                        return true;
                                    } else {
                                        return false;
                                    }
                                });
                            }
                        });
                    });

                    cmb_spare_ser.setItems(filteredItems_sp);
                    cmb_spare_ser.valueProperty().addListener(new ChangeListener<String>() {
                    @Override
                    public void changed(ObservableValue<? extends String> observablesp, String oldValuesp, String newValuesp) {
                        if(cmb_spare_ser.getSelectionModel().getSelectedItem()!=null){
                        
                            try {
                                SpareDTO spare=controller.getSparebyId(cmb_spare_ser.getSelectionModel().getSelectedItem());
                                
                                if(spare!=null){

                                    lbl_sp_board_name.setText(spare.getBoard_name());
                                    lbl_sub_inven.setText(spare.getSub_inventory());
                                    lbl_locator.setText(spare.getLocator());
                                    lbl_location.setText(spare.getLocation());
                                    
                                    
                                    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                                    String strManDate = formatter.format(spare.getManufac_date());

                                    lbl_sp_manufac_date.setText(strManDate);
                                    lbl_sp_erp_numer.setText(spare.getErp_number());
                                    
                                    
                                    
                                    
                                }
                            } catch (Exception ex) {
                                Logger.getLogger(Node_f_sController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                    }
                    }
                });
                    

                    
                
                    
                        
                
            } catch (Exception ex) {
                Logger.getLogger(Node_f_sController.class.getName()).log(Level.SEVERE, null, ex);
            }
        
    }    

    @FXML
    private void Replace(MouseEvent event) throws Exception {
        

        if(cmb_bsc_ser.getSelectionModel().getSelectedItem()!=null && cmb_spare_ser.getSelectionModel().getSelectedItem()!=null){
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate localDate = LocalDate.now();
            Date date = java.sql.Date.valueOf(localDate);
            
            UserController controller=(UserController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.USER);
            String user=controller.getLogged_username();
            
            String serialno=cmb_bsc_ser.getSelectionModel().getSelectedItem();
            NodeSectionController controller2=(NodeSectionController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
            bsc_DTO node=controller2.getById(cmb_bsc_ser.getSelectionModel().getSelectedItem());
            SpareDTO spare=controller2.getSparebyId(cmb_spare_ser.getSelectionModel().getSelectedItem());
             
            if(node!=null){
                
            
            System.out.println(cmb_bsc_ser.getSelectionModel().getSelectedItem());
            bsc_DTO dto=new bsc_DTO(
                    node.getId(),
                    cmb_spare_ser.getSelectionModel().getSelectedItem(),
                    cmb_bsc_ser.getSelectionModel().getSelectedItem(),
                    node.getVendor(),
                    node.getBsc_rnc_name().toUpperCase(),
                    node.getBsc_location().toUpperCase(),
                    node.getPhysical_name().toUpperCase(),
                    node.getLogical_name().toUpperCase(),
                    node.getErp_item_code().toUpperCase(),
                    lbl_sp_erp_numer.getText().toUpperCase(),
                    node.getRack(),
                    node.getSub_rack(),
                    node.getSlot(),
                    date,
                    user,
                    spare.getManufac_date(),
                    txtcomment.getText()
                    
            );
            
            
//            NodeSectionController nodecontroller=(NodeSectionController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
            Boolean check=controller2.update(dto);
            
            InvenController inventcontroller=(InvenController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.INVEN);
            Boolean check_spare=inventcontroller.delete(cmb_spare_ser.getSelectionModel().getSelectedItem());
            
            FaultyDTO faulty=new FaultyDTO(cmb_bsc_ser.getSelectionModel().getSelectedItem(),node.getVendor(),node.getErp_item_code(),node.getPhysical_name(),date,user);
//            InvenController controller_n=(InvenController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.INVEN);
            
            
            if(cmb_pass.getSelectionModel().getSelectedItem().equals("Faulty List")){
            
            
            Boolean check_delete=inventcontroller.add_faulty(faulty);
            
            TransactionDTO transaction=new TransactionDTO(cmb_bsc_ser.getSelectionModel().getSelectedItem(),
                                                        lbl_location.getText().toUpperCase(),
                                                        "",
                                                        "",
                                                        "",
                                                        lbl_br_boardd_name.getText().toUpperCase(),
                                                        "",
                                                        cmb_spare_ser.getSelectionModel().getSelectedItem(),
                                                        date,user,"Replaced and Forward to the Faulty List");
            
            
        
        
        HistoryController history_controller=(HistoryController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.HISTORY);
        boolean history=history_controller.add(transaction);
            
        
            TransactionDTO transaction2=new TransactionDTO(cmb_spare_ser.getSelectionModel().getSelectedItem(),
                                                        "",
                                                        "",
                                                        spare.getSub_inventory(),
                                                        spare.getLocator(),
                                                        spare.getBoard_name(),
                                                        "",
                                                        node.getSerial_no(),
                                                        date,user,"Removed from Spare List");
            
            HistoryController history_controller2=(HistoryController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.HISTORY);
            boolean history2=history_controller2.add(transaction2);
            
            System.out.println(history);
            
            if(check==true && check_spare==true && history==true && history2==true && check_delete==true){
            
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Successfully Replaced!");

            alert.showAndWait();
            
           ArrayList<String> arraylist_n=new ArrayList<>();
           ArrayList<bsc_DTO> allnodes = controller2.getAllNodes();
           allnodes.forEach((dto_sp) -> {
           arraylist_n.add(dto_sp.getSerial_no());
           });
           ObservableList<String> list=FXCollections.observableArrayList(arraylist_n);
           cmb_bsc_ser.setItems(list);
           cmb_bsc_ser.valueProperty().addListener(new ChangeListener<String>() {
                    @Override
                    public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                        if(cmb_bsc_ser.getSelectionModel().getSelectedItem()!=null){
                        
                            try {
                                NodeSectionController controller=(NodeSectionController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
                                bsc_DTO node=controller.getById(cmb_bsc_ser.getSelectionModel().getSelectedItem());
                                
                                if(node!=null){
                                    lbl_b_r_name.setText(node.getBsc_rnc_name());
                                    lbl_br_boardd_name.setText(node.getPhysical_name());
                                    lbl_rack_position.setText(node.getRack());
                                    lbl_sub_rack_position.setText(node.getSub_rack());
                                    lbl_slot_position.setText(node.getSlot());
                                    
                                    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                                    String strDate = formatter.format(node.getManufac_date());
                                    
                                    
                                    lbl_br_manufac_date.setText(strDate);
                                    lbl_erp_code.setText(node.getErp_item_code());
                                    lbl_br_erp_numer.setText(node.getErp_name());
                                    lblcomment.setText(node.getComment());
                                    
                                   final int serial_no=node.getId();
                                    
                                }  } catch (Exception ex) {
                                Logger.getLogger(Node_f_sController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                        
                        }
                    }
                });
           
            cmb_bsc_ser.getSelectionModel().clearSelection();
            
            
           ArrayList<String> arraylist_n2=new ArrayList<>();
           ArrayList<InvenDTO> allspares = inventcontroller.getAll();
           allspares.forEach((dto_sp) -> {
           arraylist_n2.add(dto_sp.getSerial_no());
           });
           ObservableList<String> list2=FXCollections.observableArrayList(arraylist_n2);
           cmb_spare_ser.setItems(list2);
           cmb_spare_ser.valueProperty().addListener(new ChangeListener<String>() {
                    @Override
                    public void changed(ObservableValue<? extends String> observablesp, String oldValuesp, String newValuesp) {
                        if(cmb_spare_ser.getSelectionModel().getSelectedItem()!=null){
                        
                            try {
                                NodeSectionController controller2=(NodeSectionController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
                                SpareDTO spare=controller2.getSparebyId(cmb_spare_ser.getSelectionModel().getSelectedItem());
                                
                                if(spare!=null){

                                    lbl_sp_board_name.setText(spare.getBoard_name());
                                    lbl_sub_inven.setText(spare.getSub_inventory());
                                    lbl_locator.setText(spare.getLocator());
                                    lbl_location.setText(spare.getLocation());
                                    
                                    
                                    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                                    String strManDate = formatter.format(spare.getManufac_date());

                                    lbl_sp_manufac_date.setText(strManDate);
                                    lbl_sp_erp_numer.setText(spare.getErp_number());
                                    
                                    
                                    
                                    
                                }
                            } catch (Exception ex) {
                                Logger.getLogger(Node_f_sController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                    }
                    }
                });
            cmb_spare_ser.getSelectionModel().clearSelection();
             
            lbl_b_r_name.setText("");
            lbl_br_boardd_name.setText("");
            lbl_br_erp_numer.setText("");
            lbl_br_manufac_date.setText("");
            lbl_erp_code.setText("");
            lbl_rack_position.setText("");
            lbl_slot_position.setText("");
            lbl_sub_rack_position.setText("");
            lbl_location.setText("");
            lbl_locator.setText("");
            lbl_sp_board_name.setText("");
            lbl_sp_erp_numer.setText("");
            lbl_sp_manufac_date.setText("");
            lbl_sub_inven.setText("");
            lblcomment.setText("");
            txtcomment.clear();
            
            
            
            
            }else{
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, there was an error!");

            alert.showAndWait();
            
            
            }
            
            }
            
            if(cmb_pass.getSelectionModel().getSelectedItem().equals("Spare List")){
            
               InvenDTO inventory=new InvenDTO(cmb_bsc_ser.getSelectionModel().getSelectedItem(),
                                node.getVendor(),
                                "",
                                "",
                                "",
                                date,
                                user,
                                node.getErp_item_code(),
                                node.getErp_name(),
                                node.getPhysical_name(),
                                node.getManufac_date(),
                                node.getComment()
                                );
            
            Boolean check_delete=inventcontroller.add(inventory);
            
            TransactionDTO transaction=new TransactionDTO(cmb_bsc_ser.getSelectionModel().getSelectedItem(),
                                                        lbl_location.getText().toUpperCase(),
                                                        "",
                                                        "",
                                                        "",
                                                        lbl_br_boardd_name.getText().toUpperCase(),
                                                        "",
                                                        cmb_spare_ser.getSelectionModel().getSelectedItem(),
                                                        date,user,"Replaced and Forward to the Spare List");
            
            
        
        
        HistoryController history_controller=(HistoryController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.HISTORY);
        boolean history=history_controller.add(transaction);
            
        
            TransactionDTO transaction2=new TransactionDTO(cmb_spare_ser.getSelectionModel().getSelectedItem(),
                                                        "",
                                                        "",
                                                        spare.getSub_inventory(),
                                                        spare.getLocator(),
                                                        spare.getBoard_name(),
                                                        "",
                                                        node.getSerial_no(),
                                                        date,user,"Removed from Spare List");
            
            HistoryController history_controller2=(HistoryController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.HISTORY);
            boolean history2=history_controller2.add(transaction2);
            
            System.out.println(history);
            
            if(check==true && check_spare==true && history==true && history2==true && check_delete==true){
            
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Successfully Replaced!");

            alert.showAndWait();
            
            ArrayList<String> arraylist_n=new ArrayList<>();
           ArrayList<bsc_DTO> allnodes = controller2.getAllNodes();
           allnodes.forEach((dto_sp) -> {
           arraylist_n.add(dto_sp.getSerial_no());
           });
           ObservableList<String> list=FXCollections.observableArrayList(arraylist_n);
           cmb_bsc_ser.setItems(list);
           cmb_bsc_ser.valueProperty().addListener(new ChangeListener<String>() {
                    @Override
                    public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                        if(cmb_bsc_ser.getSelectionModel().getSelectedItem()!=null){
                        
                            try {
                                NodeSectionController controller=(NodeSectionController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
                                bsc_DTO node=controller.getById(cmb_bsc_ser.getSelectionModel().getSelectedItem());
                                
                                if(node!=null){
                                    lbl_b_r_name.setText(node.getBsc_rnc_name());
                                    lbl_br_boardd_name.setText(node.getPhysical_name());
                                    lbl_rack_position.setText(node.getRack());
                                    lbl_sub_rack_position.setText(node.getSub_rack());
                                    lbl_slot_position.setText(node.getSlot());
                                    
                                    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                                    String strDate = formatter.format(node.getManufac_date());
                                    
                                    
                                    lbl_br_manufac_date.setText(strDate);
                                    lbl_erp_code.setText(node.getErp_item_code());
                                    lbl_br_erp_numer.setText(node.getErp_name());
                                    lblcomment.setText(node.getComment());
                                    
                                   final int serial_no=node.getId();
                                    
                                }  } catch (Exception ex) {
                                Logger.getLogger(Node_f_sController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                        
                        }
                    }
                });
           
            cmb_bsc_ser.getSelectionModel().clearSelection();
            
            
           ArrayList<String> arraylist_n2=new ArrayList<>();
           ArrayList<InvenDTO> allspares = inventcontroller.getAll();
           allspares.forEach((dto_sp) -> {
           arraylist_n2.add(dto_sp.getSerial_no());
           });
           ObservableList<String> list2=FXCollections.observableArrayList(arraylist_n2);
           cmb_spare_ser.setItems(list2);
           cmb_spare_ser.valueProperty().addListener(new ChangeListener<String>() {
                    @Override
                    public void changed(ObservableValue<? extends String> observablesp, String oldValuesp, String newValuesp) {
                        if(cmb_spare_ser.getSelectionModel().getSelectedItem()!=null){
                        
                            try {
                                NodeSectionController controller2=(NodeSectionController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.NODE);
                                SpareDTO spare=controller2.getSparebyId(cmb_spare_ser.getSelectionModel().getSelectedItem());
                                
                                if(spare!=null){

                                    lbl_sp_board_name.setText(spare.getBoard_name());
                                    lbl_sub_inven.setText(spare.getSub_inventory());
                                    lbl_locator.setText(spare.getLocator());
                                    lbl_location.setText(spare.getLocation());
                                    
                                    
                                    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                                    String strManDate = formatter.format(spare.getManufac_date());

                                    lbl_sp_manufac_date.setText(strManDate);
                                    lbl_sp_erp_numer.setText(spare.getErp_number());
                                    
                                    
                                    
                                    
                                }
                            } catch (Exception ex) {
                                Logger.getLogger(Node_f_sController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                    }
                    }
                });
            cmb_spare_ser.getSelectionModel().clearSelection();
             
            lbl_b_r_name.setText("");
            lbl_br_boardd_name.setText("");
            lbl_br_erp_numer.setText("");
            lbl_br_manufac_date.setText("");
            lbl_erp_code.setText("");
            lbl_rack_position.setText("");
            lbl_slot_position.setText("");
            lbl_sub_rack_position.setText("");
            lbl_location.setText("");
            lbl_locator.setText("");
            lbl_sp_board_name.setText("");
            lbl_sp_erp_numer.setText("");
            lbl_sp_manufac_date.setText("");
            lbl_sub_inven.setText("");
            lblcomment.setText("");
            txtcomment.clear();
            
            
            
            
            }else{
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, there was an error!");

            alert.showAndWait();
            
            
            }
            
            }
            
            
            
            
            }else{                                                   //if(node!=null)
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, Empty Entry!");

            alert.showAndWait();
            
                
            
            }
        } else{
        
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Look, an Error Dialog");
            alert.setContentText("Ooops, Please Fill the Serial Numbers!");

            alert.showAndWait();
        
        
        }

            
    }

    
    
}
