/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;


import hsb.controller.ControllerFactory;
import hsb.controller.custom.FaultsController;
import hsb.controller.custom.UserController;
import hsb.dto.FaultyDTO;
import static hsb.main.main.stage;
import static hsb.view.controller.LoginViewController.primarystage;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;



/**
 * FXML Controller class
 *
 * @author user
 */
public class Side_nav_homeController implements Initializable {

    @FXML
    private Label lbluser;
    @FXML
    private HBox home_tab;
    @FXML
    private HBox node_tab;
    @FXML
    private HBox inventory_tab;
    @FXML
    private HBox fault_tab;
    @FXML
    private HBox history_tab;
    @FXML
    private HBox about_tab;
    
    
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            UserController controller=(UserController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.USER);
            String user=controller.getLogged_username();
            lbluser.setText(user);
            
            home_tab.setStyle("-fx-background-color: rgb(9, 21, 40);-fx-background-radius:30 30 30 30;");
            node_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            inventory_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            fault_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            history_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            about_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");

            
            
        } catch (Exception ex) {
            Logger.getLogger(Side_nav_homeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void home_content(MouseEvent event) {
        try {
            BorderPane border_pane = (BorderPane) ((Node) event.getSource()).getScene().getRoot();
            Parent content_home = FXMLLoader.load(getClass().getResource("/hsb/view/ui/Home_Menu.fxml"));
            border_pane.setCenter(content_home);
            
            home_tab.setStyle("-fx-background-color: rgb(9, 21, 40);-fx-background-radius:30 30 30 30;");
            node_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            inventory_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            fault_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            history_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            about_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");

        } catch (IOException ex) {
            Logger.getLogger(Side_nav_homeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void node_content(MouseEvent event) {
        try {
            BorderPane border_pane = (BorderPane) ((Node) event.getSource()).getScene().getRoot();
            Parent content_home = FXMLLoader.load(getClass().getResource("/hsb/view/ui/node.fxml"));
            border_pane.setCenter(content_home);
            
            home_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            node_tab.setStyle("-fx-background-color: rgb(9, 21, 40);-fx-background-radius:30 30 30 30;");
            inventory_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            fault_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            history_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            about_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
        } catch (IOException ex) {
            Logger.getLogger(Side_nav_homeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

   

    @FXML
    private void faults_contents(MouseEvent event) {
        try {
            BorderPane border_pane = (BorderPane) ((Node) event.getSource()).getScene().getRoot();
            Parent content_home = FXMLLoader.load(getClass().getResource("/hsb/view/ui/faulty.fxml"));
            border_pane.setCenter(content_home);
            
            home_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            node_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            inventory_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            fault_tab.setStyle("-fx-background-color: rgb(9, 21, 40);-fx-background-radius:30 30 30 30;");
            history_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            about_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
        } catch (IOException ex) {
            Logger.getLogger(Side_nav_homeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void history_content(MouseEvent event) {
           try {
            BorderPane border_pane = (BorderPane) ((Node) event.getSource()).getScene().getRoot();
            Parent content_home = FXMLLoader.load(getClass().getResource("/hsb/view/ui/history_home.fxml"));
            border_pane.setCenter(content_home);
            
            home_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            node_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            inventory_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            fault_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            history_tab.setStyle("-fx-background-color: rgb(9, 21, 40);-fx-background-radius:30 30 30 30;");
            about_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
        } catch (IOException ex) {
            Logger.getLogger(Side_nav_homeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    

    @FXML
    private void inventory_content(MouseEvent event) {
          try {
            BorderPane border_pane = (BorderPane) ((Node) event.getSource()).getScene().getRoot();
            Parent content_home = FXMLLoader.load(getClass().getResource("/hsb/view/ui/spare.fxml"));
            border_pane.setCenter(content_home);
            
            home_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            node_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            inventory_tab.setStyle("-fx-background-color: rgb(9, 21, 40);-fx-background-radius:30 30 30 30;");
            fault_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            history_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            about_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
        } catch (IOException ex) {
            Logger.getLogger(Side_nav_homeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

//    private void notifications(MouseEvent event) {
//         Notifications notifys=Notifications.create()
//                    .title("Hello")
//                    .text("World")
//                    .graphic(null)
//                    .hideAfter(Duration.seconds(10))
//                    .position(Pos.BOTTOM_RIGHT)
//                    .onAction(new EventHandler<ActionEvent>() {
//                @Override
//                public void handle(ActionEvent event) {
//                    System.out.println("Notifications ");
//                }
//            });
//            
//            notifys.showConfirm();
//    }

   

   

    @FXML
    private void logout(MouseEvent event) throws IOException {
        
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Do you really want to Sign_Out?");
            Optional<ButtonType> result=alert.showAndWait();
            
            if(result.get()==ButtonType.OK){
            
            Parent root = FXMLLoader.load(getClass().getResource("/hsb/view/ui/login.fxml"));
            Scene scene = new Scene(root);
            stage=new Stage();
            stage.initStyle(StageStyle.TRANSPARENT);
            stage.setScene(scene);
            stage.show();
            primarystage.close();
            
            }
            
            if(result.get()==ButtonType.CANCEL){
            
//                System.out.println("no");
            }
      
    }

    @FXML
    private void about(MouseEvent event) {
        try {
            BorderPane border_pane = (BorderPane) ((Node) event.getSource()).getScene().getRoot();
            Parent content_home = FXMLLoader.load(getClass().getResource("/hsb/view/ui/About.fxml"));
            border_pane.setCenter(content_home);
            
            home_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            node_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            inventory_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            fault_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            history_tab.setStyle("-fx-background-color: rgb(17, 173, 165);");
            about_tab.setStyle("-fx-background-color: rgb(9, 21, 40);-fx-background-radius:30 30 30 30;");
        } catch (IOException ex) {
            Logger.getLogger(Side_nav_homeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
