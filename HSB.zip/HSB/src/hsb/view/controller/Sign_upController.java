/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import hsb.controller.ControllerFactory;
import hsb.controller.custom.LoginController;
import hsb.controller.custom.UserController;
import hsb.dto.LoginDTO;
import hsb.dto.UserDTO;
import static hsb.main.main.stage;
import static hsb.view.controller.LoginViewController.primarystage1;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

/**
 * FXML Controller class
 *
 * @author user
 */
public class Sign_upController implements Initializable {

    @FXML
    private Pane detail_pane;
    @FXML
    private TextField txtusername;
    @FXML
    private PasswordField txtpassword;
    @FXML
    private PasswordField txtconfirm_pwd;
    
    
    
    private UserDTO user;
    @FXML
    private Label lbl_check_username;
    @FXML
    private Label lbl_check_pwd;
    @FXML
    private Label lbl_confirm_pwd;
    
    private Pattern pattern_un;
    private Matcher matcher_un;
    
    private Pattern pattern_pwd;
    private Matcher matcher_pwd;

//    private static final String EMAIL_PATTERN = 
//		"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    
//    private static final String EMAIL_PATTERN = 
//		"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[mobitel]+(\\.[A-Za-z0-9]+)*(\\.[lk]{2})$";
     private static final String EMAIL_PATTERN = 
		"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@#######+(\\.[lk]{2})$";
    
    private static final String PASSWORD_PATTERN = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,40})";
    
    /**
     * Initializes the controller class.
     */
    
    private String validate_un="";
    private String validate_pwd="";
    private String confirm_pwd="";
    
    
    //encryption the password
    private static final String UNICODE_FORMAT = "UTF8";
    public static final String DESEDE_ENCRYPTION_SCHEME = "DESede";
    private KeySpec ks;
    private SecretKeyFactory skf;
    private Cipher cipher;
    byte[] arrayBytes;
    private String myEncryptionKey;
    private String myEncryptionScheme;
    SecretKey key;
    @FXML
    private Pane header_pane;
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      
    }    
    
    public Sign_upController() throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException {
		pattern_un = Pattern.compile(EMAIL_PATTERN);
                pattern_pwd = Pattern.compile(PASSWORD_PATTERN);
                
                //encyption password
                 myEncryptionKey = "ThisIsSpartaThisIsSparta";
                myEncryptionScheme = DESEDE_ENCRYPTION_SCHEME;
                arrayBytes = myEncryptionKey.getBytes(UNICODE_FORMAT);
                ks = new DESedeKeySpec(arrayBytes);
                skf = SecretKeyFactory.getInstance(myEncryptionScheme);
                cipher = Cipher.getInstance(myEncryptionScheme);
                key = skf.generateSecret(ks);
	} 

    @FXML
    private void close_app(MouseEvent event) {
        System.exit(0);
    }

    @FXML
    private void minimize_app(MouseEvent event) {
        primarystage1.setIconified(true);
    }

    @FXML
    private void got_sign_up(MouseEvent event) throws IOException, Exception {
        
        //validate username
        validate_un=txtusername.getText();
        boolean check_un=validate_un(validate_un);
        
        if(check_un==true){
        
            lbl_check_username.setText("*matched");
        
        }else{
        
            lbl_check_username.setText("*should be abc@mobitel.lk");
        
        }
        
        //validate password
        validate_pwd=txtpassword.getText();
        boolean check_pwd =validate_pwd(validate_pwd);
        
        if(check_pwd==true){
        
            lbl_check_pwd.setText("*matched");
        
        }else{
        
             lbl_check_pwd.setText("*@ least 8 character with "+"\n"+"1 digit,1 lower and uppercase "+"\n"+"character and (@ # $ % ! .)");
        
        }
        
        //validate confirm password and signed up
        validate_pwd=txtpassword.getText();
        confirm_pwd=txtconfirm_pwd.getText();
        boolean confirm=confirm_pwd(txtpassword.getText(),txtconfirm_pwd.getText());
        

        //check signup
        if(check_un==true && check_pwd==true && confirm==true){
           
        user=new UserDTO(txtusername.getText(),txtpassword.getText());
        UserController controller=(UserController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.USER);
        Boolean check=controller.add(user);
        
        
//        System.out.println(check);
        if(check==true){
            Parent root = FXMLLoader.load(getClass().getResource("/hsb/view/ui/login.fxml"));
            Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.initStyle(StageStyle.TRANSPARENT);
            stage.setScene(scene);
            
            stage.show();
            primarystage1.close();
        }
        
        else{
        
           lbl_confirm_pwd.setText("*Please confirm password");
           txtconfirm_pwd.clear();
        
        }
        }
        
    }

    @FXML
    private void back_to_login_page(MouseEvent event) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("/hsb/view/ui/login.fxml"));
            Scene scene = new Scene(root);
            stage=new Stage();
            stage.initStyle(StageStyle.TRANSPARENT);
            stage.setScene(scene);
            
            stage.show();
            primarystage1.close();
    }
    
            //validate for username as email address
            public boolean validate_un(final String hex) {

		matcher_un = pattern_un.matcher(hex);
		return matcher_un.matches();

	    }
            
            //validate password
            public boolean validate_pwd(final String password) {
 
                matcher_pwd = pattern_pwd.matcher(password);
                return matcher_pwd.matches();

            }
            
            //check confirm password
            public boolean confirm_pwd(final String un,final String pwd) {
 
                if(un.equals(pwd)){
                
                    return true;
                
                }else{
                
                    return false;
                
                }

            }
            
            public String encrypt(String unencryptedString) {
         String encryptedString = null;
         try {
               cipher.init(Cipher.ENCRYPT_MODE, key);
               byte[] plainText = unencryptedString.getBytes(UNICODE_FORMAT);
               byte[] encryptedText = cipher.doFinal(plainText);
               encryptedString = new String(Base64.getEncoder().encodeToString(encryptedText));
         } catch (Exception e) {
                e.printStackTrace();
         }
                return encryptedString;
         }
            
           
            


    
}
