/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.view.controller;

import hsb.controller.ControllerFactory;
import hsb.controller.custom.LoginController;
import hsb.controller.custom.UserController;
import hsb.dto.LoginDTO;
import hsb.dto.UserDTO;
import static hsb.main.main.stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import static javafx.application.Application.launch;
import static javafx.application.Application.launch;
import static javafx.application.Application.launch;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.DragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import static javafx.application.Application.launch;
import static javafx.application.Application.launch;
import static javafx.application.Application.launch;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author user
 */
public class LoginViewController implements Initializable {

    @FXML
    private Pane login_pane;
    @FXML
    private Pane signup_pane;
    @FXML
    private Pane header_pane;
    @FXML
    private ImageView min_btn;
    @FXML
    private ImageView close_btn;
    @FXML
    private AnchorPane parent;
    
    private double xOffset=0;
    private double yOffset=0;
    @FXML
    private ImageView login_btn;
    @FXML
    private ImageView signup_btn;
    
    private LoginDTO user;
    private UserDTO lastuser;
    
    public static Stage primarystage=null;
    public static Stage primarystage1=null;
    public static Stage primarystage2=null;
    public static Stage primarystage3=null;
    @FXML
    private TextField txtuser;
    @FXML
    private PasswordField txtpassword;
    @FXML
    private Label lblcheck;
    
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
//        makestageDraggable();
    }    
    
    private void makestageDraggable(){
        
        parent.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                xOffset=event.getSceneX();
                yOffset=event.getSceneY();
            }
        });
        
        parent.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
               stage.setX(event.getSceneX()+xOffset);
               stage.setY(event.getSceneX()+yOffset);
            }
        });
    
    
    
    }
    

    @FXML
    private void close_app(MouseEvent event) {
        System.exit(0);
    }

    @FXML
    private void minimize_app(MouseEvent event) {
        stage.setIconified(true);
    }

    @FXML
    private void get_logged(MouseEvent event) throws IOException, Exception {
        
        
        user=new LoginDTO(txtuser.getText()+"@#######.lk",txtpassword.getText());
        LoginController controller=(LoginController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.LOGIN);
        user=controller.CheckUser(user);
        
        lastuser=new UserDTO(txtuser.getText()+"@#######.lk",txtpassword.getText());
        UserController controller_1=(UserController)ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.USER);
        Boolean check=controller_1.lastUser(lastuser);
        
        
        if(user==null || check==false){
            
        lblcheck.setText("Access Denied");
        txtuser.clear();
        txtpassword.clear();
    
        }else{
        
            lblcheck.setText("Logged");
            Parent root = FXMLLoader.load(getClass().getResource("/hsb/view/ui/home.fxml"));
            Scene scene = new Scene(root);
            primarystage=new Stage();
            primarystage.initStyle(StageStyle.DECORATED);
            primarystage.setScene(scene);
            
            primarystage.show();
            stage.close();
        
        }
    
    
        

    }

    @FXML
    private void go_to_sign_up(MouseEvent event) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("/hsb/view/ui/sign_up.fxml"));
            Scene scene = new Scene(root);
            primarystage1=new Stage();
            primarystage1.initStyle(StageStyle.TRANSPARENT);
            primarystage1.setScene(scene);
            primarystage1.show();
            stage.close();
    }

    @FXML
    private void go_to_change_pwd(MouseEvent event) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("/hsb/view/ui/change_pwd.fxml"));
            Scene scene = new Scene(root);
            primarystage2=new Stage();
            primarystage2.initStyle(StageStyle.TRANSPARENT);
            primarystage2.setScene(scene);
            primarystage2.show();
            stage.close();
    }

    @FXML
    private void go_to_forgot_pwd(MouseEvent event) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("/hsb/view/ui/forgot_password.fxml"));
            Scene scene = new Scene(root);
            primarystage3=new Stage();
            primarystage3.initStyle(StageStyle.TRANSPARENT);
            primarystage3.setScene(scene);
            primarystage3.show();
            stage.close();
    }

    
    

  
    
}
