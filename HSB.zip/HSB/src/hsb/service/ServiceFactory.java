/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.service;

import hsb.service.custom.impl.FaultsServiceImpl;
import hsb.service.custom.impl.HistoryServiceImpl;
import hsb.service.custom.impl.InvenServiceImpl;
import hsb.service.custom.impl.LoginServiceImpl;
import hsb.service.custom.impl.NodeServiceImpl;
import hsb.service.custom.impl.UserServiceImpl;


/**
 *
 * @author user
 */
public class ServiceFactory {
    
    private static ServiceFactory factory;
    private LoginServiceImpl loginServiceimpl;
    private UserServiceImpl userServiceimpl;
    private NodeServiceImpl nodeServiceimpl;
    private InvenServiceImpl invenServiceimpl;
    private FaultsServiceImpl faultsServiceimpl;
    private HistoryServiceImpl historyServiceimpl;
    public enum ServicetType{
    
        LOGIN,USER,NODE,INVEN,FAULTS,HISTORY
    
    }
    
    private ServiceFactory(){
    
        loginServiceimpl=new LoginServiceImpl();
        userServiceimpl=new UserServiceImpl();
        nodeServiceimpl=new NodeServiceImpl();
        invenServiceimpl=new InvenServiceImpl();
        faultsServiceimpl=new FaultsServiceImpl();
        historyServiceimpl=new HistoryServiceImpl();
    }
    
    public static ServiceFactory getInstance(){
    
        if(factory==null){
        
            factory=new ServiceFactory();
            
        
        }
         
        return factory;
    }
    
    public SuperService getService(ServicetType type){
    
        switch(type){
        
            case LOGIN:
                return loginServiceimpl;
            case USER:
                return userServiceimpl;
                
            case NODE:
                return nodeServiceimpl;
                
            case INVEN:
                return invenServiceimpl;
            case FAULTS:
                return faultsServiceimpl;
            case HISTORY:
                return historyServiceimpl;
            default:
                return null;
        
        }
    
    }
    
}
