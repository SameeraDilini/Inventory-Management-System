/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.service.custom;


import hsb.dto.FaultyDTO;
import hsb.service.SuperService;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public interface FaultsService extends SuperService<FaultyDTO,String>{
    boolean check_repetition(String id) throws Exception;
    boolean add_acknowledgement(FaultyDTO dto) throws Exception;
    boolean check_repetition_ack(String id) throws Exception;
    ArrayList<FaultyDTO> getAll_ack() throws Exception;
    boolean adv_replacment(String id) throws Exception;
}
