/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.service.custom.impl;

import hsb.business.BussinessFactory;
import hsb.business.custom.FaultsBussiness;
import hsb.business.custom.InvenBussiness;
import hsb.dto.FaultyDTO;
import hsb.service.ServiceFactory;
import hsb.service.custom.FaultsService;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class FaultsServiceImpl implements FaultsService{

    @Override
    public boolean add(FaultyDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean update(FaultyDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public FaultyDTO getByID(String id) throws Exception {
       FaultsBussiness faultsBussiness=(FaultsBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.FAULTS);
        return faultsBussiness.getByID(id);
    }

    @Override
    public boolean delete(String id) throws Exception {
        FaultsBussiness faultsBussiness=(FaultsBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.FAULTS);
        return faultsBussiness.delete(id);
    }

    @Override
    public ArrayList<FaultyDTO> search(String id) throws Exception {
         FaultsBussiness faultsBussiness=(FaultsBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.FAULTS);
        return faultsBussiness.search(id);
    }

    @Override
    public ArrayList<FaultyDTO> getAll() throws Exception {
         FaultsBussiness faultsBussiness=(FaultsBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.FAULTS);
        return faultsBussiness.getAll();
    }

    @Override
    public boolean check_repetition(String id) throws Exception {
        FaultsBussiness faultsBussiness=(FaultsBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.FAULTS);
        return faultsBussiness.check_repetition(id);
    }

    @Override
    public boolean add_acknowledgement(FaultyDTO dto) throws Exception {
        FaultsBussiness faultsBussiness=(FaultsBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.FAULTS);
        return faultsBussiness.add_acknowledgement(dto);
    }

    @Override
    public boolean check_repetition_ack(String id) throws Exception {
         FaultsBussiness faultsBussiness=(FaultsBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.FAULTS);
        return faultsBussiness.check_repetition_ack(id);
    }

    @Override
    public ArrayList<FaultyDTO> getAll_ack() throws Exception {
        FaultsBussiness faultsBussiness=(FaultsBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.FAULTS);
        return faultsBussiness.getAll_ack();
    }

    @Override
    public boolean adv_replacment(String id) throws Exception {
        FaultsBussiness faultsBussiness=(FaultsBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.FAULTS);
        return faultsBussiness.adv_replacment(id);
    }
    
}
