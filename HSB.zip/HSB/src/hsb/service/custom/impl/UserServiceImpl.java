/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.service.custom.impl;

import hsb.business.BussinessFactory;
import hsb.business.custom.UserBussiness;
import hsb.dto.LoginDTO;
import hsb.dto.UserDTO;
import hsb.service.ServiceFactory;
import hsb.service.custom.UserService;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class UserServiceImpl implements UserService{

    @Override
    public Boolean lastUser(UserDTO t) throws Exception {
        UserBussiness userBussiness=(UserBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.USER);
        return userBussiness.lastUser(t);
    }

    @Override
    public boolean add(UserDTO t) throws Exception {
        UserBussiness userBussiness=(UserBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.USER);
        return userBussiness.add(t);
    }

    @Override
    public boolean update(UserDTO t) throws Exception {
       UserBussiness userBussiness=(UserBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.USER);
        return userBussiness.update(t);
    }

    @Override
    public boolean delete(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public UserDTO getByID(String id) throws Exception {
       UserBussiness userBussiness=(UserBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.USER);
        return userBussiness.getByID(id);
    }

    @Override
    public ArrayList<UserDTO> search(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<UserDTO> getAll() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getLogged_username() throws Exception {
        UserBussiness userBussiness=(UserBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.USER);
        return userBussiness.getLogged_username();
    }

    
    
}
