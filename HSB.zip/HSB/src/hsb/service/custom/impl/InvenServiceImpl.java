/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.service.custom.impl;

import hsb.business.BussinessFactory;
import hsb.business.custom.InvenBussiness;
import hsb.dto.FaultyDTO;
import hsb.dto.InvenDTO;
import hsb.service.ServiceFactory;
import hsb.service.custom.InvenService;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class InvenServiceImpl implements InvenService{

    @Override
    public boolean add(InvenDTO t) throws Exception {
         InvenBussiness invenBussiness=(InvenBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.INVEN);
        return invenBussiness.add(t);
    }

    @Override
    public boolean update(InvenDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(String id) throws Exception {
         InvenBussiness invenBussiness=(InvenBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.INVEN);
        return invenBussiness.delete(id);
    }

    @Override
    public InvenDTO getByID(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<InvenDTO> search(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<InvenDTO> getAll() throws Exception {
         InvenBussiness invenBussiness=(InvenBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.INVEN);
        return invenBussiness.getAll();
    }

    @Override
    public boolean add_faulty(FaultyDTO dto) throws Exception {
         InvenBussiness invenBussiness=(InvenBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.INVEN);
        return invenBussiness.add_faulty(dto);
    }

    @Override
    public boolean check_repetition(String id) throws Exception {
        InvenBussiness invenBussiness=(InvenBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.INVEN);
        return invenBussiness.check_repetition(id);
    }


    
}
