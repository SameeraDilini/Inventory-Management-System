/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.service.custom.impl;

import hsb.business.BussinessFactory;
import hsb.business.custom.HistoryBussiness;
import hsb.dto.HistoryDTO;
import hsb.dto.TransactionDTO;
import hsb.service.ServiceFactory;
import hsb.service.custom.HistoryService;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class HistoryServiceImpl implements HistoryService{

    @Override
    public boolean add(TransactionDTO t) throws Exception {
        HistoryBussiness historybussiness=(HistoryBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.HISTORY);
        return historybussiness.add(t);
    }

    @Override
    public boolean update(TransactionDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public TransactionDTO getByID(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<TransactionDTO> search(String id) throws Exception {
        HistoryBussiness historybussiness=(HistoryBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.HISTORY);
        return historybussiness.search(id);
    }

    @Override
    public ArrayList<TransactionDTO> getAll() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<TransactionDTO> search_by_location(String id) throws Exception {
        HistoryBussiness historybussiness=(HistoryBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.HISTORY);
        return historybussiness.search_by_location(id);
    }

    @Override
    public ArrayList<TransactionDTO> search_by_board(HistoryDTO dto) throws Exception {
        HistoryBussiness historybussiness=(HistoryBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.HISTORY);
        return historybussiness.search_by_board(dto);
    }
    
}
