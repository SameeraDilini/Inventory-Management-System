/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.service.custom.impl;

import hsb.business.BussinessFactory;
import hsb.business.custom.LoginBussiness;
import hsb.dto.LoginDTO;
import hsb.service.ServiceFactory;
import hsb.service.SuperService;
import hsb.service.custom.LoginService;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class LoginServiceImpl implements LoginService{

    @Override
    public LoginDTO CheckUser(LoginDTO t) throws Exception {
        LoginBussiness loginBussiness=(LoginBussiness) BussinessFactory.getInstance().getBussiness(ServiceFactory.ServicetType.LOGIN);
        return loginBussiness.checkUser(t);
    }
    

    @Override
    public boolean add(LoginDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean update(LoginDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public LoginDTO getByID(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<LoginDTO> search(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<LoginDTO> getAll() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
