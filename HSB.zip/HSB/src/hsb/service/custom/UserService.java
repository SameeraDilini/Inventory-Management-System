/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.service.custom;

import hsb.dto.LoginDTO;
import hsb.dto.UserDTO;
import hsb.service.SuperService;

/**
 *
 * @author user
 */
public interface UserService extends SuperService<UserDTO, String>{
     public Boolean lastUser(UserDTO t) throws Exception;
    String getLogged_username() throws Exception;
}
