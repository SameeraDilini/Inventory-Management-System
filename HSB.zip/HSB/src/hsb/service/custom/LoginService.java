/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.service.custom;

import hsb.dto.LoginDTO;
import hsb.service.SuperService;

/**
 *
 * @author user
 */
public interface LoginService extends SuperService<LoginDTO, String> {
    public LoginDTO CheckUser(LoginDTO t) throws Exception;
}
