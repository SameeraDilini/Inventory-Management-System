/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.service.custom;

import hsb.dto.HistoryDTO;
import hsb.dto.TransactionDTO;
import hsb.service.SuperService;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public interface HistoryService extends SuperService<TransactionDTO,String>{
    ArrayList<TransactionDTO> search_by_location(String id) throws Exception;
    ArrayList<TransactionDTO> search_by_board(HistoryDTO dto) throws Exception;
}
