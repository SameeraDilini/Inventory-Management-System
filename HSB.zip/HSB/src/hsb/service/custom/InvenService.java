/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.service.custom;

import hsb.dto.FaultyDTO;
import hsb.dto.InvenDTO;
import hsb.service.SuperService;

/**
 *
 * @author user
 */
public interface InvenService extends SuperService<InvenDTO, String>{
    boolean add_faulty(FaultyDTO dto) throws Exception;
    boolean check_repetition(String id) throws Exception;
}
