/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.main;
import hsb.controller.ControllerFactory;
import hsb.controller.custom.FaultsController;
import hsb.controller.custom.UserController;
import hsb.dto.FaultyDTO;
import hsb.dto.UserDTO;
import hsb.view.model.faulty_tablemodel;
import hsb.view.model.home_tablemodel;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import static java.time.LocalDate.now;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.DragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
//import javax.mail.Message;
//import javax.mail.Session;
//import javax.mail.Transport;
//import javax.mail.internet.InternetAddress;
//import javax.mail.internet.MimeMessage;
//import tray.animations.AnimationType;
//import tray.notification.NotificationType;
//import tray.notification.TrayNotification;
import javax.net.ssl.TrustManager;

/**
 *
 * @author user
 */
public class main extends Application {
    
    public static Stage stage=null;
    private double xoffset=0;
    private double yoffset=0;
    
    
    
    @Override
    public void start(Stage stage) {
        
        
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/hsb/view/ui/login.fxml"));
            Scene scene = new Scene(root);
            stage.initStyle(StageStyle.UNDECORATED);
            stage.setScene(scene);
            this.stage=stage;
            stage.show();
            
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
//        LocalDate localDate = LocalDate.now();
//        Date date = java.sql.Date.valueOf(localDate);
        
        Calendar calendar = Calendar.getInstance();
//        System.out.println(calendar.get(Calendar.DAY_OF_WEEK));
        if(calendar.get(Calendar.DAY_OF_WEEK)==4){
        
        try {
//           

            LocalDate localDate = LocalDate.now();
            Date date = java.sql.Date.valueOf(localDate);
            
            SimpleDateFormat formatter2 = new SimpleDateFormat("dd/MM/yyyy");

            FaultsController controller=(FaultsController) ControllerFactory.getInstance().getController(ControllerFactory.ControllerType.FAULTS);
            ArrayList<FaultyDTO> faulty = controller.getAll();
            ArrayList<String> all_faulty = new ArrayList<String>();
            for (FaultyDTO dto : faulty) {
                
                
                
                Date date_2=dto.getAdded_date();
                
                long diffInMillies = Math.abs(date.getTime() - date_2.getTime());
                long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
                

                if(diff>=45){
                
                    
                        all_faulty.add("\nSerial number : "+dto.getSerial_no()+
                                        " \nBoard_name : "+dto.getBoard_name()+
                                        " \nFaulty List Added_date : "+dto.getAdded_date()+
                                        " \nFalty List added By : "+dto.getAdded_by()+
                                        " \nAcknowledeged Date : - "+
                                        " \nAcknowledeged By : - \n\n");
                        
                        
                        

                        }
                
            }
                ArrayList<FaultyDTO> faulty_ack = controller.getAll_ack();
                
                for (FaultyDTO dto_ack : faulty_ack) {
                  
                Date date_3=dto_ack.getAdded_date_ack();
                
                long diffInMillies_2 = Math.abs(date.getTime() - date_3.getTime());
                long diff_2 = TimeUnit.DAYS.convert(diffInMillies_2, TimeUnit.MILLISECONDS);
                

                if(diff_2>=45){
                
                    
                    
                    all_faulty.add("\nSerial number : "+dto_ack.getSerial_no()+
                                        " \nBoard_name : "+dto_ack.getBoard_name()+
                                        " \nFaulty List Added_date : "+dto_ack.getAdded_date()+
                                        " \nFalty List added By : "+dto_ack.getAdded_by()+
                                        " \nAcknowledeged Date : "+dto_ack.getAdded_date_ack()+
                                        " \nAcknowledeged By : "+dto_ack.getAck_added_by()+"\n\n");
                        
                        
                        
                
                    System.out.println(dto_ack.getAck_added_by());
                    
                    
                }
                
                }
                    
//                Properties props = new Properties();
//                props.put("mail.smtp.host", "192.168.39.79");
//                props.put("mail.smtp.port", 587);            //127.0.0.1:49685
//                props.put("mail.smtp.user", "inventorymanagement@mobitel.lk");
//                props.put("mail.smtp.auth", "true");
//                props.put("mail.smtp.starttls.enable", "true");
////                props.put("mail.smtp.ssl.enable", "true");
//                props.put("mail.smtp.debug", "true");
//                props.put("mail.smtp.socketFactory.port", 587);
//                props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
//                props.put("mail.smtp.socketFactory.fallback", "false");
//                props.put("mail.smtp.ssl.trust", "192.168.39.79");
////                repair=new ArrayList<>();
//                
//                Session session = Session.getDefaultInstance(props, null);
//                session.setDebug(true);
//                MimeMessage message = new MimeMessage(session);
//                message.setText("Dear Sir/Madam,\nFollowing items have been sent for repairs and not returned yet.\n" + all_faulty);
//                
//                
//                
//                
//                
//                
//                message.setSubject("_NPA_Notification About Repair Return");
//                message.setFrom(new InternetAddress("inventorymanagement@mobitel.lk"));
//                message.addRecipient(Message.RecipientType.TO, new InternetAddress("lalithap@mobitel.lk".trim()));
//                message.saveChanges();
//                Transport transport = session.getTransport("smtp");
//                transport.connect("192.168.39.79", "inventorymanagement@mobitel.lk", "xxxx");
//                transport.sendMessage(message, message.getAllRecipients());
//                transport.close();
//                
//                if(transport!=null){
//                
//                    TrayNotification tray = new TrayNotification();
////                    System.out.println(selectedFile.getAbsoluteFile() + " is successfully written");
//                    tray.setNotificationType(NotificationType.NOTICE);
//                    tray.setTitle("Check an Email");
//                    tray.setMessage("An email has been sent to your account successfully. ");
//                    tray.setAnimationType(AnimationType.SLIDE);
//                    tray.showAndDismiss(javafx.util.Duration.millis(5000));
//                    tray.setRectangleFill(javafx.scene.paint.Color.valueOf("#4183D7"));
//                
//                
//                }else{
//                
//                    TrayNotification tray = new TrayNotification();
////                    System.out.println(selectedFile.getAbsoluteFile() + " is successfully written");
//                    tray.setNotificationType(NotificationType.WARNING);
//                    tray.setTitle("Check an Email");
//                    tray.setMessage("Can't reach to send an email");
//                    tray.setAnimationType(AnimationType.POPUP);
//                    tray.showAndDismiss(javafx.util.Duration.millis(1000));
//                    tray.setRectangleFill(javafx.scene.paint.Color.valueOf("#4183D7"));
//                
//                
//                }
                
                
                
                     
            
        }catch (Exception e) {
            e.printStackTrace(); 
                        }
        }
        
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        launch(args);
        
        
    }
    
    
}
