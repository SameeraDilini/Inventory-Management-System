/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dto;

/**
 *
 * @author user
 */
public class UserDTO extends SuperDTO{
     private int id;
     private String username;
     private String password;

    /**
     * @return the username
     */
     
     
      public UserDTO(String username,String password){
        
        this.username=username;
        this.password=password;
        
    
    }
      
       public UserDTO(int id,String username,String password){
        
        this.id=id;
        this.username=username;
        this.password=password;
        
    
    }
     
     
     
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

   
}
