/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dto;

import java.util.Date;

/**
 *
 * @author user
 */
public class bsc_DTO extends SuperDTO{
    private String serial_no;
    private String bsc_rnc_name;
    private String board_name;
    private String rack;
    private String sub_rack;
    private String slot;
    private Date manufac_date;
    private String erp_item_code;
    private String erp_name;
    private String vendor;
    private String physical_name;
    private String logical_name;
    private Date date;
    private String added_by;
    private String bsc_location;
    private String spare_serial_no;
    private int id;
    private String comment;
    
    
    public bsc_DTO(
            int id,
            String serial_no,
            String vendor,
            String bsc_rnc_name,
            String bsc_location,
            String physical_name,
            String logical_name,
            String erp_item_code,
            String erp_name,
            String rack,
            String sub_rack,
            String slot,
            Date date,
            String added_by,
            Date manufac_date,
            String comment
            ){
    
        this.serial_no=serial_no;
        this.vendor=vendor;
        this.bsc_rnc_name=bsc_rnc_name;
        this.bsc_location=bsc_location;
        this.physical_name=physical_name;
        this.logical_name=logical_name;
        this.erp_item_code=erp_item_code;
        this.erp_name=this.erp_name;
        this.rack=rack;
        this.sub_rack=sub_rack;
        this.slot=slot;
        this.date=date;
        this.added_by=added_by;
        this.manufac_date=manufac_date;
        this.erp_name=erp_name;
        this.id=id;
        this.comment=comment;

    }
    
    
    public bsc_DTO(
            int id,
            String spare_serial_no,
            String serial_no,
            String vendor,
            String bsc_rnc_name,
            String bsc_location,
            String physical_name,
            String logical_name,
            String erp_item_code,
            String erp_name,
            String rack,
            String sub_rack,
            String slot,
            Date date,
            String added_by,
            Date manufac_date,
            String comment
            
            ){
        this.id=id;
        this.spare_serial_no=spare_serial_no;
        this.serial_no=serial_no;
        this.vendor=vendor;
        this.bsc_rnc_name=bsc_rnc_name;
        this.bsc_location=bsc_location;
        this.physical_name=physical_name;
        this.logical_name=logical_name;
        this.erp_item_code=erp_item_code;
        this.erp_name=this.erp_name;
        this.rack=rack;
        this.sub_rack=sub_rack;
        this.slot=slot;
        this.date=date;
        this.added_by=added_by;
        this.manufac_date=manufac_date;
        this.erp_name=erp_name;
        this.comment=comment;
        

    }
    
    public bsc_DTO(String serial_no,
            String bsc_rnc_name,
            String board_name,
            String rack,
            String sub_rack,
            String slot,
            Date manufac_date,
            String erp_item_code,
            String erp_no){
    
        this.serial_no=serial_no;
        this.bsc_rnc_name=bsc_rnc_name;
        this.board_name=board_name;
        this.rack=rack;
        this.sub_rack=sub_rack;
        this.slot=slot;
        this.manufac_date=manufac_date;
        this.erp_item_code=erp_item_code;
        this.erp_name=erp_name;
    
    
    }
    
    
     
     
    public String getSerial_no() {
        return serial_no;
    }

    /**
     * @param serial_no the serial_no to set
     */
    public void setSerial_no(String serial_no) {
        this.serial_no = serial_no;
    }

    /**
     * @return the bsc_rnc_name
     */
    public String getBsc_rnc_name() {
        return bsc_rnc_name;
    }

    /**
     * @param bsc_rnc_name the bsc_rnc_name to set
     */
    public void setBsc_rnc_name(String bsc_rnc_name) {
        this.bsc_rnc_name = bsc_rnc_name;
    }

    /**
     * @return the board_name
     */
    public String getBoard_name() {
        return board_name;
    }

    /**
     * @param board_name the board_name to set
     */
    public void setBoard_name(String board_name) {
        this.board_name = board_name;
    }

    /**
     * @return the rack
     */
    public String getRack() {
        return rack;
    }

    /**
     * @param rack the rack to set
     */
    public void setRack(String rack) {
        this.rack = rack;
    }

    /**
     * @return the sub_rack
     */
    public String getSub_rack() {
        return sub_rack;
    }

    /**
     * @param sub_rack the sub_rack to set
     */
    public void setSub_rack(String sub_rack) {
        this.sub_rack = sub_rack;
    }

    /**
     * @return the slot
     */
    public String getSlot() {
        return slot;
    }

    /**
     * @param slot the slot to set
     */
    public void setSlot(String slot) {
        this.slot = slot;
    }

    /**
     * @return the manufac_date
     */
    public Date getManufac_date() {
        return manufac_date;
    }

    /**
     * @param manufac_date the manufac_date to set
     */
    public void setManufac_date(Date manufac_date) {
        this.manufac_date = manufac_date;
    }

    /**
     * @return the erp_item_code
     */
    public String getErp_item_code() {
        return erp_item_code;
    }

    /**
     * @param erp_item_code the erp_item_code to set
     */
    public void setErp_item_code(String erp_item_code) {
        this.erp_item_code = erp_item_code;
    }

    /**
     * @return the erp_no
     */
    public String getErp_name() {
        return erp_name;
    }

    /**
     * @param erp_no the erp_no to set
     */
    public void setErp_name(String erp_name) {
        this.erp_name = erp_name;
    }

    /**
     * @return the vendor
     */
    public String getVendor() {
        return vendor;
    }

    /**
     * @param vendor the vendor to set
     */
    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    /**
     * @return the physical_name
     */
    public String getPhysical_name() {
        return physical_name;
    }

    /**
     * @param physical_name the physical_name to set
     */
    public void setPhysical_name(String physical_name) {
        this.physical_name = physical_name;
    }

    /**
     * @return the logical_name
     */
    public String getLogical_name() {
        return logical_name;
    }

    /**
     * @param logical_name the logical_name to set
     */
    public void setLogical_name(String logical_name) {
        this.logical_name = logical_name;
    }

    /**
     * @return the date
     */
    public Date getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * @return the added_by
     */
    public String getAdded_by() {
        return added_by;
    }

    /**
     * @param added_by the added_by to set
     */
    public void setAdded_by(String added_by) {
        this.added_by = added_by;
    }

    /**
     * @return the bsc_location
     */
    public String getBsc_location() {
        return bsc_location;
    }

    /**
     * @param bsc_location the bsc_location to set
     */
    public void setBsc_location(String bsc_location) {
        this.bsc_location = bsc_location;
    }

    /**
     * @return the spare_serial_no
     */
    public String getSpare_serial_no() {
        return spare_serial_no;
    }

    /**
     * @param spare_serial_no the spare_serial_no to set
     */
    public void setSpare_serial_no(String spare_serial_no) {
        this.spare_serial_no = spare_serial_no;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }
}
