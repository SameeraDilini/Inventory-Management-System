/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dto;

import java.util.Date;

/**
 *
 * @author user
 */
public class Node_FaultyDTO extends SuperDTO{
    private String serial_no;
    private String bsc_rnc_name;
    private String board_name;
    private String rack;
    private String sub_rack;
    private String slot;
    private String manufac_date;
    private String erp_item_code;
    private String erp_no;
    private String vendor;
    private String physical_name;
    private String logical_name;
    private Date date;
    private String added_by;
    

    /**
     * @return the serial_no
     */
    
       public Node_FaultyDTO(
            String vendor,
            String bsc_rnc_name,
            String physical_name,
            String logical_name,
            String erp_item_code,
            String rack,
            String sub_rack,
            String slot
            
            ){
    
        this.vendor=vendor;
        this.bsc_rnc_name=bsc_rnc_name;
        this.physical_name=physical_name;
        this.logical_name=logical_name;
        this.erp_item_code=erp_item_code;
        this.rack=rack;
        this.sub_rack=sub_rack;
        this.slot=slot;

    }
    
    public Node_FaultyDTO(String serial_no,
            String bsc_rnc_name,
            String board_name,
            String rack,
            String sub_rack,
            String slot,
            String manufac_date,
            String erp_item_code,
            String erp_no){
    
        this.serial_no=serial_no;
        this.bsc_rnc_name=bsc_rnc_name;
        this.board_name=board_name;
        this.rack=rack;
        this.sub_rack=sub_rack;
        this.slot=slot;
        this.manufac_date=manufac_date;
        this.erp_item_code=erp_item_code;
        this.erp_no=erp_no;
    
    
    }
    
     public Node_FaultyDTO(
            String serial_no,
            String vendor,
            String bsc_rnc_name,
            String board_name,
            String physical_name,
            String logical_name,
            String erp_item_code,
            String erp_no,
            String rack,
            String sub_rack,
            String slot,
            Date date,
            String added_by,
            String manufac_date
            ){
    
        this.serial_no=serial_no;
        this.vendor=vendor;
        this.bsc_rnc_name=bsc_rnc_name;
        this.board_name=board_name;
        this.physical_name=physical_name;
        this.logical_name=logical_name;
        this.erp_item_code=erp_item_code;
        this.erp_no=erp_no;
        this.rack=rack;
        this.sub_rack=sub_rack;
        this.slot=slot;
        this.date=date;
        this.added_by=added_by;
        this.manufac_date=manufac_date;
        
    
    
    }

   
    
    
    public String getSerial_no() {
        return serial_no;
    }

    /**
     * @param serial_no the serial_no to set
     */
    public void setSerial_no(String serial_no) {
        this.serial_no = serial_no;
    }

    /**
     * @return the bsc_rnc_name
     */
    public String getBsc_rnc_name() {
        return bsc_rnc_name;
    }

    /**
     * @param bsc_rnc_name the bsc_rnc_name to set
     */
    public void setBsc_rnc_name(String bsc_rnc_name) {
        this.bsc_rnc_name = bsc_rnc_name;
    }

    /**
     * @return the board_name
     */
    public String getBoard_name() {
        return board_name;
    }

    /**
     * @param board_name the board_name to set
     */
    public void setBoard_name(String board_name) {
        this.board_name = board_name;
    }

    /**
     * @return the rack
     */
    public String getRack() {
        return rack;
    }

    /**
     * @param rack the rack to set
     */
    public void setRack(String rack) {
        this.rack = rack;
    }

    /**
     * @return the sub_rack
     */
    public String getSub_rack() {
        return sub_rack;
    }

    /**
     * @param sub_rack the sub_rack to set
     */
    public void setSub_rack(String sub_rack) {
        this.sub_rack = sub_rack;
    }

    /**
     * @return the slot
     */
    public String getSlot() {
        return slot;
    }

    /**
     * @param slot the slot to set
     */
    public void setSlot(String slot) {
        this.slot = slot;
    }

    /**
     * @return the manufac_date
     */
    public String getManufac_date() {
        return manufac_date;
    }

    /**
     * @param manufac_date the manufac_date to set
     */
    public void setManufac_date(String manufac_date) {
        this.manufac_date = manufac_date;
    }

    /**
     * @return the erp_item_code
     */
    public String getErp_item_code() {
        return erp_item_code;
    }

    /**
     * @param erp_item_code the erp_item_code to set
     */
    public void setErp_item_code(String erp_item_code) {
        this.erp_item_code = erp_item_code;
    }

    /**
     * @return the erp_no
     */
    public String getErp_no() {
        return erp_no;
    }

    /**
     * @param erp_no the erp_no to set
     */
    public void setErp_no(String erp_no) {
        this.erp_no = erp_no;
    }

    /**
     * @return the vendor
     */
    public String getVendor() {
        return vendor;
    }

    /**
     * @param vendor the vendor to set
     */
    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    /**
     * @return the physical_name
     */
    public String getPhysical_name() {
        return physical_name;
    }

    /**
     * @param physical_name the physical_name to set
     */
    public void setPhysical_name(String physical_name) {
        this.physical_name = physical_name;
    }

    /**
     * @return the logical_name
     */
    public String getLogical_name() {
        return logical_name;
    }

    /**
     * @param logical_name the logical_name to set
     */
    public void setLogical_name(String logical_name) {
        this.logical_name = logical_name;
    }

    /**
     * @return the date
     */
    public Date getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * @return the added_by
     */
    public String getAdded_by() {
        return added_by;
    }

    /**
     * @param added_by the added_by to set
     */
    public void setAdded_by(String added_by) {
        this.added_by = added_by;
    }
    
}
