/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dto;

import java.util.Date;
import javafx.scene.control.CheckBox;

/**
 *
 * @author user
 */
public class FaultyDTO extends SuperDTO{
    private String serial_no;
    private String vendor;
    private String erp_item_code;
    private String board_name;
    private Date added_date;
    private String added_by;
    private Date added_date_ack;
    private String ack_added_by;
    

    
    public FaultyDTO(
            String serial_no,
            String vendor,
            String erp_item_code,
            String board_name,
            Date added_date,
            String added_by)
    {
        this.serial_no=serial_no;
        this.vendor=vendor;
        this.erp_item_code=erp_item_code;
        this.board_name=board_name;
        this.added_date=added_date;
        this.added_by=added_by;
        
    
    
    }

    public FaultyDTO(String serial_no, String vendor, String erp_item_code, String board_name, Date added_date, String added_by, Date added_date_ack, String ack_added_by) {
        this.serial_no = serial_no;
        this.vendor = vendor;
        this.erp_item_code = erp_item_code;
        this.board_name = board_name;
        this.added_date = added_date;
        this.added_by = added_by;
        this.added_date_ack = added_date_ack;
        this.ack_added_by = ack_added_by;
    }

    public FaultyDTO(String serial_no, String vendor, String erp_item_code, String board_name, Date added_date, String added_by, Date added_date_ack) {
        this.serial_no = serial_no;
        this.vendor = vendor;
        this.erp_item_code = erp_item_code;
        this.board_name = board_name;
        this.added_date = added_date;
        this.added_by = added_by;
        this.added_date_ack = added_date_ack;
    }

    /**
     * @return the serial_no
     */
    public String getSerial_no() {
        return serial_no;
    }

    /**
     * @param serial_no the serial_no to set
     */
    public void setSerial_no(String serial_no) {
        this.serial_no = serial_no;
    }

    /**
     * @return the vendor
     */
    public String getVendor() {
        return vendor;
    }

    /**
     * @param vendor the vendor to set
     */
    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    /**
     * @return the erp_item_code
     */
    public String getErp_item_code() {
        return erp_item_code;
    }

    /**
     * @param erp_item_code the erp_item_code to set
     */
    public void setErp_item_code(String erp_item_code) {
        this.erp_item_code = erp_item_code;
    }

    /**
     * @return the board_name
     */
    public String getBoard_name() {
        return board_name;
    }

    /**
     * @param board_name the board_name to set
     */
    public void setBoard_name(String board_name) {
        this.board_name = board_name;
    }

    /**
     * @return the added_date
     */
    public Date getAdded_date() {
        return added_date;
    }

    /**
     * @param added_date the added_date to set
     */
    public void setAdded_date(Date added_date) {
        this.added_date = added_date;
    }

    /**
     * @return the added_by
     */
    public String getAdded_by() {
        return added_by;
    }

    /**
     * @param added_by the added_by to set
     */
    public void setAdded_by(String added_by) {
        this.added_by = added_by;
    }

    /**
     * @return the added_date_ack
     */
    public Date getAdded_date_ack() {
        return added_date_ack;
    }

    /**
     * @param added_date_ack the added_date_ack to set
     */
    public void setAdded_date_ack(Date added_date_ack) {
        this.added_date_ack = added_date_ack;
    }

    /**
     * @return the ack_added_by
     */
    public String getAck_added_by() {
        return ack_added_by;
    }

    /**
     * @param ack_added_by the ack_added_by to set
     */
    public void setAck_added_by(String ack_added_by) {
        this.ack_added_by = ack_added_by;
    }

    
}
