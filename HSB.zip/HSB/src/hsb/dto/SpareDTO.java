/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dto;

import java.util.Date;

/**
 *
 * @author user
 */
public class SpareDTO extends SuperDTO{
    private String serial_no;
    private String vendor;
    private String board_name;
    private String sub_inventory;
    private String locator;
    private String location;
    private Date manufac_date;
    private String erp_item_code;
    private String erp_number;
    private Date date;
    private String added_by;
    

    /**
     * @return the serial_no
     */
    
    public SpareDTO(String serial_no,String vendor,String board_name,String sub_inventory,String locator){
    
        this.serial_no=serial_no;
        this.board_name=board_name;
        this.sub_inventory=sub_inventory;
        this.locator=locator;
        this.location=location;
        this.erp_number=erp_number;
    
    
    }
    
    
    public SpareDTO(
            String serial_no,
            String vendor,
            String sub_inventory,
            String locator,
            String location,
            Date date,
            String added_by,
            String erp_item_code,
            String erp_number,
            String board_name,
            Date manufac_date){
    
        this.serial_no=serial_no;
        this.vendor=vendor;
        this.sub_inventory=sub_inventory;
        this.locator=locator;
        this.location=location;
        this.date=date;
        this.added_by=added_by;
        this.erp_item_code=erp_item_code;
        this.erp_number=erp_number;
        this.board_name=board_name;
        this.manufac_date=manufac_date;
        
        
    
    
    }
    public String getSerial_no() {
        return serial_no;
    }

    /**
     * @param serial_no the serial_no to set
     */
    public void setSerial_no(String serial_no) {
        this.serial_no = serial_no;
    }

    /**
     * @return the board_name
     */
    public String getBoard_name() {
        return board_name;
    }

    /**
     * @param board_name the board_name to set
     */
    public void setBoard_name(String board_name) {
        this.board_name = board_name;
    }

    /**
     * @return the sub_inventory
     */
    public String getSub_inventory() {
        return sub_inventory;
    }

    /**
     * @param sub_inventory the sub_inventory to set
     */
    public void setSub_inventory(String sub_inventory) {
        this.sub_inventory = sub_inventory;
    }

    /**
     * @return the locator
     */
    public String getLocator() {
        return locator;
    }

    /**
     * @param locator the locator to set
     */
    public void setLocator(String locator) {
        this.locator = locator;
    }

    /**
     * @return the location
     */
    public String getLocation() {
        return location;
    }

    /**
     * @param location the location to set
     */
    public void setLocation(String location) {
        this.location = location;
    }

  

    /**
     * @return the erp_number
     */
    public String getErp_number() {
        return erp_number;
    }

    /**
     * @param erp_number the erp_number to set
     */
    public void setErp_number(String erp_number) {
        this.erp_number = erp_number;
    }

    /**
     * @return the vendor
     */
    public String getVendor() {
        return vendor;
    }

    /**
     * @param vendor the vendor to set
     */
    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    /**
     * @return the manufac_date
     */
    public Date getManufac_date() {
        return manufac_date;
    }

    /**
     * @param manufac_date the manufac_date to set
     */
    public void setManufac_date(Date manufac_date) {
        this.manufac_date = manufac_date;
    }

    /**
     * @return the erp_item_code
     */
    public String getErp_item_code() {
        return erp_item_code;
    }

    /**
     * @param erp_item_code the erp_item_code to set
     */
    public void setErp_item_code(String erp_item_code) {
        this.erp_item_code = erp_item_code;
    }

    /**
     * @return the date
     */
    public Date getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * @return the added_by
     */
    public String getAdded_by() {
        return added_by;
    }

    /**
     * @param added_by the added_by to set
     */
    public void setAdded_by(String added_by) {
        this.added_by = added_by;
    }
    
}
