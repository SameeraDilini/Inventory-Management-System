/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dto;

import java.util.Date;

/**
 *
 * @author user
 */
public class TransactionDTO extends SuperDTO{
    private String serial_no;
    private String added_by;
    private Date added_date;
    private String bsc_location;
    private String spare_location;
    private String sub_inventory;
    private String board_name;
    private String locator;
    private String comment;
    private String replacement;
    private String adv_serial_no;
    
    
   
    
    public TransactionDTO(String serial_no,                         
                          String bsc_location,
                          String spare_location,
                          String sub_inventory,
                          String locator,
                          String board_name,
                          String replacement,
                          String adv_serial_no,
                          Date added_date,
                          String added_by,
                          String comment){
    
    this.serial_no=serial_no;
    this.bsc_location=bsc_location;
    this.spare_location=spare_location;
    this.sub_inventory=sub_inventory;
    this.locator=locator;
    this.board_name=board_name;
    this.replacement=replacement;
    this.adv_serial_no=adv_serial_no;
    this.added_by=added_by;
    this.added_date=added_date;
    this.comment=comment;
    
    
    }

    /**
     * @return the serial_no
     */
    public String getSerial_no() {
        return serial_no;
    }

    /**
     * @param serial_no the serial_no to set
     */
    public void setSerial_no(String serial_no) {
        this.serial_no = serial_no;
    }

    /**
     * @return the added_by
     */
    public String getAdded_by() {
        return added_by;
    }

    /**
     * @param added_by the added_by to set
     */
    public void setAdded_by(String added_by) {
        this.added_by = added_by;
    }

    /**
     * @return the added_date
     */
    public Date getAdded_date() {
        return added_date;
    }

    /**
     * @param added_date the added_date to set
     */
    public void setAdded_date(Date added_date) {
        this.added_date = added_date;
    }

    

    /**
     * @return the sub_inventory
     */
    public String getSub_inventory() {
        return sub_inventory;
    }

    /**
     * @param sub_inventory the sub_inventory to set
     */
    public void setSub_inventory(String sub_inventory) {
        this.sub_inventory = sub_inventory;
    }

    /**
     * @return the board_name
     */
    public String getBoard_name() {
        return board_name;
    }

    /**
     * @param board_name the board_name to set
     */
    public void setBoard_name(String board_name) {
        this.board_name = board_name;
    }

    /**
     * @return the locator
     */
    public String getLocator() {
        return locator;
    }

    /**
     * @param locator the locator to set
     */
    public void setLocator(String locator) {
        this.locator = locator;
    }

    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @return the replacement
     */
    public String getReplacement() {
        return replacement;
    }

    /**
     * @param replacement the replacement to set
     */
    public void setReplacement(String replacement) {
        this.replacement = replacement;
    }

    /**
     * @return the adv_serial_no
     */
    public String getAdv_serial_no() {
        return adv_serial_no;
    }

    /**
     * @param adv_serial_no the adv_serial_no to set
     */
    public void setAdv_serial_no(String adv_serial_no) {
        this.adv_serial_no = adv_serial_no;
    }

    /**
     * @return the bsc_location
     */
    public String getBsc_location() {
        return bsc_location;
    }

    /**
     * @param bsc_location the bsc_location to set
     */
    public void setBsc_location(String bsc_location) {
        this.bsc_location = bsc_location;
    }

    /**
     * @return the spare_location
     */
    public String getSpare_location() {
        return spare_location;
    }

    /**
     * @param spare_location the spare_location to set
     */
    public void setSpare_location(String spare_location) {
        this.spare_location = spare_location;
    }
    
    
   

    

    
    
    
    
    
}
