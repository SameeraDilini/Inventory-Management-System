/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dto;

import java.util.Date;

/**
 *
 * @author user
 */
public class InvenDTO extends SuperDTO{
    private String serial_no;
    private String vendor;
    private String board_name;
    private String sub_inventory;
    private String locator;
    private String location;
    private String item_code;
    private String erp_number;
    private Date manufac_date;
    private Date date;
    private String added_by;
    private String comment;
    

    /**
     * @return the serial_no
     */
    
    
    public InvenDTO(String serial_no,
                    String vendor,
                    String sub_inventory,
                    String locator,
                    String location,
                    Date date,
                    String added_by,
                    String item_code,
                    String erp_number,
                    String board_name,
                    Date manufac_date,
                    String comment
                    ){
    
    this.serial_no=serial_no;
    this.vendor=vendor;
    this.board_name=board_name;
    this.sub_inventory=sub_inventory;
    this.locator=locator;
    this.location=location;
    this.item_code=item_code;
    this.erp_number=erp_number;
    this.manufac_date=manufac_date;
    this.date=date;
    this.added_by=added_by;
    this.comment=comment;
    
    
    }
    
    public InvenDTO(String serial_no){
    
        this.serial_no=serial_no;
    
    }

    /**
     * @return the serial_no
     */
    public String getSerial_no() {
        return serial_no;
    }

    /**
     * @param serial_no the serial_no to set
     */
    public void setSerial_no(String serial_no) {
        this.serial_no = serial_no;
    }

    /**
     * @return the vendor
     */
    public String getVendor() {
        return vendor;
    }

    /**
     * @param vendor the vendor to set
     */
    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    /**
     * @return the board_name
     */
    public String getBoard_name() {
        return board_name;
    }

    /**
     * @param board_name the board_name to set
     */
    public void setBoard_name(String board_name) {
        this.board_name = board_name;
    }

    /**
     * @return the sub_inventory
     */
    public String getSub_inventory() {
        return sub_inventory;
    }

    /**
     * @param sub_inventory the sub_inventory to set
     */
    public void setSub_inventory(String sub_inventory) {
        this.sub_inventory = sub_inventory;
    }

    /**
     * @return the locator
     */
    public String getLocator() {
        return locator;
    }

    /**
     * @param locator the locator to set
     */
    public void setLocator(String locator) {
        this.locator = locator;
    }

    /**
     * @return the location
     */
    public String getLocation() {
        return location;
    }

    /**
     * @param location the location to set
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * @return the item_code
     */
    public String getItem_code() {
        return item_code;
    }

    /**
     * @param item_code the item_code to set
     */
    public void setItem_code(String item_code) {
        this.item_code = item_code;
    }

    /**
     * @return the erp_number
     */
    public String getErp_number() {
        return erp_number;
    }

    /**
     * @param erp_number the erp_number to set
     */
    public void setErp_number(String erp_number) {
        this.erp_number = erp_number;
    }

    /**
     * @return the manufac_date
     */
    public Date getManufac_date() {
        return manufac_date;
    }

    /**
     * @param manufac_date the manufac_date to set
     */
    public void setManufac_date(Date manufac_date) {
        this.manufac_date = manufac_date;
    }

    /**
     * @return the date
     */
    public Date getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * @return the added_by
     */
    public String getAdded_by() {
        return added_by;
    }

    /**
     * @param added_by the added_by to set
     */
    public void setAdded_by(String added_by) {
        this.added_by = added_by;
    }

    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    
    
}
