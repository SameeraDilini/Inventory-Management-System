/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.business.custom;

import hsb.business.SuperBussiness;
import hsb.dto.HistoryDTO;
import hsb.dto.TransactionDTO;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public interface HistoryBussiness extends SuperBussiness<TransactionDTO,String>{
    ArrayList<TransactionDTO> search_by_location(String id) throws Exception;
    ArrayList<TransactionDTO> search_by_board(HistoryDTO dto) throws Exception;
}
