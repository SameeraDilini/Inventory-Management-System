/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.business.custom.impl;

import hsb.business.custom.InvenBussiness;
import hsb.dao.DAOFactory;
import hsb.dao.custom.InvenDAO;
import hsb.dao.custom.UserDAO;
import hsb.dto.FaultyDTO;
import hsb.dto.InvenDTO;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class InvenBussinessImpl implements InvenBussiness{

    @Override
    public boolean add(InvenDTO t) throws Exception {
        InvenDAO invendao=(InvenDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.INVEN);
        invendao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return invendao.add(t);
    }

    @Override
    public boolean update(InvenDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public InvenDTO getByID(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(String id) throws Exception {
         InvenDAO invendao=(InvenDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.INVEN);
        invendao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return invendao.delete(id);
    }

    @Override
    public ArrayList<InvenDTO> search(String id) throws Exception {
       throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<InvenDTO> getAll() throws Exception {
        InvenDAO invendao=(InvenDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.INVEN);
        invendao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return invendao.getAll();
    }

    @Override
    public boolean add_faulty(FaultyDTO dto) throws Exception {
        InvenDAO invendao=(InvenDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.INVEN);
        invendao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return invendao.add_faulty(dto);
    }

    @Override
    public boolean check_repetition(String id) throws Exception {
        InvenDAO invendao=(InvenDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.INVEN);
        invendao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return invendao.check_repetition(id);
    }


    
}
