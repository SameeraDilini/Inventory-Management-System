/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.business.custom.impl;

import hsb.business.custom.NodeBussiness;
import hsb.dao.DAOFactory;
import hsb.dao.custom.NodeDAO;
import hsb.dao.custom.UserDAO;
import hsb.dto.Node_FaultyDTO;
import hsb.dto.SpareDTO;
import hsb.dto.bsc_DTO;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class NodeBussinessImpl implements NodeBussiness{

    @Override
    public boolean add(bsc_DTO t) throws Exception {
        NodeDAO nodedao=(NodeDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.NODE);
        
        nodedao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return nodedao.add(t);
    }

    @Override
    public boolean update(bsc_DTO t) throws Exception {
         NodeDAO nodedao=(NodeDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.NODE);
        
        nodedao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return nodedao.update(t);
    }

    @Override
    public bsc_DTO getByID(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(String id) throws Exception {
        NodeDAO nodedao=(NodeDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.NODE);
        
        nodedao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return nodedao.delete(id);
    }

    @Override
    public ArrayList<bsc_DTO> search(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<bsc_DTO> getAll() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public bsc_DTO getById(String id) throws Exception {
       NodeDAO nodedao=(NodeDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.NODE);
        
        nodedao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return nodedao.getById(id);
    }

    @Override
    public SpareDTO getSparebyId(String id) throws Exception {
       NodeDAO nodedao=(NodeDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.NODE);
        
        nodedao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return nodedao.getSparebyId(id);
    }

    @Override
    public ArrayList<bsc_DTO> getAllNodes() throws Exception {
        NodeDAO nodedao=(NodeDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.NODE);
        
        nodedao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return nodedao.getAllNodes();
    }

    @Override
    public boolean check_repetition(String id) throws Exception {
        NodeDAO nodedao=(NodeDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.NODE);
        
        nodedao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return nodedao.check_repetition(id);
    }
    
}
