/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.business.custom.impl;

import hsb.business.custom.UserBussiness;
import hsb.dao.DAOFactory;
import hsb.dao.custom.UserDAO;
import hsb.dto.LoginDTO;
import hsb.dto.SuperDTO;
import hsb.dto.UserDTO;
import java.sql.Connection;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class UserBussinessImpl implements UserBussiness{

    @Override
    public Boolean lastUser(UserDTO t) throws Exception {
       UserDAO userdao=(UserDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.USER);
        
        userdao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return userdao.lastUser(t);
    }

    @Override
    public boolean add(UserDTO t) throws Exception {
        UserDAO userdao=(UserDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.USER);
        
        userdao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return userdao.add(t);
    }

    @Override
    public boolean update(UserDTO t) throws Exception {
         UserDAO userdao=(UserDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.USER);
        
         userdao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
         return userdao.update(t);
    }

    @Override
    public UserDTO getByID(String id) throws Exception {
        UserDAO userdao=(UserDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.USER);
        
        userdao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return userdao.getById(id);
    }

    @Override
    public boolean delete(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<UserDTO> search(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<UserDTO> getAll() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getLogged_username() throws Exception {
        UserDAO userdao=(UserDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.USER);
        
        userdao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return userdao.getLogged_username();
    }

    

   
    
    
}
