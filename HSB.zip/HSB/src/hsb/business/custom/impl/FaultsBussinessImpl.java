/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.business.custom.impl;

import hsb.business.custom.FaultsBussiness;
import hsb.dao.DAOFactory;
import hsb.dao.custom.FaultsDAO;
import hsb.dto.FaultyDTO;
import hsb.dto.InvenDTO;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class FaultsBussinessImpl implements FaultsBussiness{

    @Override
    public boolean add(FaultyDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean update(FaultyDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public FaultyDTO getByID(String id) throws Exception {
        FaultsDAO faultsdao=(FaultsDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.FAULTS);
        faultsdao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return faultsdao.getById(id);
    }

    @Override
    public boolean delete(String id) throws Exception {
        FaultsDAO faultsdao=(FaultsDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.FAULTS);
        faultsdao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return faultsdao.delete(id);
    }

    @Override
    public ArrayList<FaultyDTO> search(String id) throws Exception {
        FaultsDAO faultsdao=(FaultsDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.FAULTS);
        faultsdao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return faultsdao.search(id);
    }

    @Override
    public ArrayList<FaultyDTO> getAll() throws Exception {
        FaultsDAO faultsdao=(FaultsDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.FAULTS);
        faultsdao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return faultsdao.getAll();
    }

    @Override
    public boolean check_repetition(String id) throws Exception {
        FaultsDAO faultsdao=(FaultsDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.FAULTS);
        faultsdao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return faultsdao.check_repetition(id);
    }

    @Override
    public boolean add_acknowledgement(FaultyDTO dto) throws Exception {
        FaultsDAO faultsdao=(FaultsDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.FAULTS);
        faultsdao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return faultsdao.add_acknowledgement(dto);
    }

    @Override
    public boolean check_repetition_ack(String id) throws Exception {
        FaultsDAO faultsdao=(FaultsDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.FAULTS);
        faultsdao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return faultsdao.check_repetition_ack(id);
    }

    @Override
    public ArrayList<FaultyDTO> getAll_ack() throws Exception {
        FaultsDAO faultsdao=(FaultsDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.FAULTS);
        faultsdao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return faultsdao.getAll_ack();
    }

    @Override
    public boolean adv_replacment(String id) throws Exception {
        FaultsDAO faultsdao=(FaultsDAO) DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getDAO(DAOFactory.DAOType.FAULTS);
        faultsdao.setConnection(DAOFactory.getDAOFactory(DAOFactory.FactoryType.MYSQL).getConnection());
        
        return faultsdao.adv_replacment(id);
    }

  
    
}
