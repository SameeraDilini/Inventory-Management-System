/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.business.custom;

import hsb.business.SuperBussiness;
import hsb.dto.LoginDTO;

/**
 *
 * @author user
 */
public interface LoginBussiness extends SuperBussiness<LoginDTO,String>{
    public LoginDTO checkUser(LoginDTO t) throws Exception;
}
