/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.business.custom;

import hsb.business.SuperBussiness;
import hsb.dto.FaultyDTO;
import hsb.dto.InvenDTO;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public interface FaultsBussiness extends SuperBussiness<FaultyDTO,String>{
    boolean check_repetition(String id) throws Exception;
    boolean add_acknowledgement(FaultyDTO dto) throws Exception;
    boolean check_repetition_ack(String id) throws Exception;
    ArrayList<FaultyDTO> getAll_ack() throws Exception;
    boolean adv_replacment(String id) throws Exception;
}
