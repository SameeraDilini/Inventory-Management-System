/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.business.custom;

import hsb.business.SuperBussiness;
import hsb.dao.SuperDAO;
import hsb.dto.LoginDTO;
import hsb.dto.SuperDTO;
import hsb.dto.UserDTO;

/**
 *
 * @author user
 */
public interface UserBussiness extends SuperBussiness<UserDTO,String>{
    public Boolean lastUser(UserDTO t) throws Exception;
      String getLogged_username() throws Exception;
}
