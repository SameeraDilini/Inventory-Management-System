/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.business;

import hsb.business.custom.impl.FaultsBussinessImpl;
import hsb.business.custom.impl.HistoryBussinessImpl;
import hsb.business.custom.impl.InvenBussinessImpl;
import hsb.business.custom.impl.LoginBussinessImpl;
import hsb.business.custom.impl.NodeBussinessImpl;
import hsb.business.custom.impl.UserBussinessImpl;
import hsb.service.ServiceFactory;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import jdk.nashorn.internal.runtime.regexp.JoniRegExp;

/**
 *
 * @author user
 */
public class BussinessFactory {
    
    private static BussinessFactory factory;
    private LoginBussinessImpl loginbusinessimpl;
    private UserBussinessImpl userbussinessimpl;
    private NodeBussinessImpl nodebussinessimpl;
    private InvenBussinessImpl invenbussinessimpl;
    private FaultsBussinessImpl faultsbussinessimpl;
    private HistoryBussinessImpl historybussinessimpl;
    
    
    
    private BussinessFactory() throws ClassNotFoundException, SQLException{
        
        loginbusinessimpl=new LoginBussinessImpl();
        userbussinessimpl=new UserBussinessImpl();
        nodebussinessimpl=new NodeBussinessImpl();
        invenbussinessimpl=new InvenBussinessImpl();
        faultsbussinessimpl=new FaultsBussinessImpl();
        historybussinessimpl=new HistoryBussinessImpl();
    
    }
    
    public static BussinessFactory getInstance() throws ClassNotFoundException{
    
        if(factory==null){
        
            try {
                factory=new BussinessFactory();
            } catch (SQLException ex) {
                Logger.getLogger(BussinessFactory.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return factory;
        
    }
    
    
    
    public SuperBussiness getBussiness(ServiceFactory.ServicetType type){
    
        switch(type){
        
            case LOGIN:
                return loginbusinessimpl;
            case USER:
                return userbussinessimpl;
            case NODE:
                return nodebussinessimpl;
            case INVEN:
                return invenbussinessimpl;
            case FAULTS:
                return faultsbussinessimpl;
            case HISTORY:
                return historybussinessimpl;
            default:
                return null;
        
        }
    
    
    }
    
}
