/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dao;

import hsb.dao.mysql.DAOmysqlfactory;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.SQLException;
import javax.crypto.NoSuchPaddingException;

/**
 *
 * @author user
 */

public abstract class DAOFactory {
    private static DAOFactory factory;
    
    public enum FactoryType{
        MYSQL
    }
    
    public enum DAOType{
        LOGIN,USER,NODE,INVEN,FAULTS,HISTORY
    
    }
    
    public abstract SuperDAO getDAO(DAOType type);
    public abstract Connection getConnection();
    public abstract TransactionScope getTransactionScope();
    
    public static DAOFactory getDAOFactory(FactoryType type) throws ClassNotFoundException, SQLException, UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException{
        
        switch(type){
            case MYSQL:
                return DAOmysqlfactory.getInstance(); 
                
            default:
                return null;
        }
    }
}
