/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author user
 */

public class ConnectionFactory {
    
    private static ConnectionFactory dbconnection;
    private Connection connection;
    
    private ConnectionFactory() throws ClassNotFoundException, SQLException{
    
        Class.forName("com.mysql.jdbc.Driver");
        connection=DriverManager.getConnection("jdbc:mysql://localhost/inventory_management_system","root","");
    
    }   
    
    public Connection getconnection(){
    
        return connection;
    
    }
    
    public static ConnectionFactory getInstance() throws ClassNotFoundException, SQLException{
    
    if(dbconnection==null){
        
        dbconnection=new ConnectionFactory();
    
    }
    return dbconnection;
    }
}
