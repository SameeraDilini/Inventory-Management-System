/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dao.custom;

import hsb.dao.SuperDAO;
import hsb.dto.SuperDTO;
import hsb.dto.UserDTO;

/**
 *
 * @author user
 */
public interface UserDAO extends SuperDAO<UserDTO, Object>{
    Boolean lastUser(UserDTO dto) throws Exception;
    String getLogged_username() throws Exception;
}
