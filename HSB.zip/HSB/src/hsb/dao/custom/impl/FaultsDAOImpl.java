/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dao.custom.impl;

import hsb.dao.custom.FaultsDAO;
import hsb.dto.FaultyDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class FaultsDAOImpl implements FaultsDAO{
    Connection connection;

    @Override
    public boolean add(FaultyDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean update(FaultyDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(String id) throws Exception {
        String sql = "DELETE FROM faulty WHERE serial_no=?";
            PreparedStatement pstm = connection.prepareStatement(sql);
            pstm.setObject(1, id);
            return pstm.executeUpdate() > 0;
    }

    @Override
    public FaultyDTO getById(Object id) throws Exception {
         String sql = "SELECT * FROM faulty WHERE serial_no =\"" + id + "\"";
        Statement stm = connection.createStatement();
        ResultSet rst = stm.executeQuery(sql);

        if (rst.next()) {
            return (new FaultyDTO(
                    rst.getString(2), 
                    rst.getString(3), 
                    rst.getString(4), 
                    rst.getString(5),
                    rst.getDate(6),
                    rst.getString(7)
                    
                    ));
        } else {
            return null;
        }
    }

    @Override
    public ArrayList<FaultyDTO> search(Object id) throws Exception {
        String sql = "SELECT * FROM faulty WHERE serial_no` = '"+id+"'";
        Statement stm = connection.createStatement();
        ResultSet rst = stm.executeQuery(sql);
        ArrayList<FaultyDTO> list = new ArrayList<>();
        while (rst.next()) {
            list.add(new FaultyDTO(rst.getString(2),
                    rst.getString(3),
                    rst.getString(4),
                    rst.getString(5),
                    rst.getDate(6),
                    rst.getString(7)));
        }

        return list;
    }

    @Override
    public ArrayList<FaultyDTO> getAll() throws Exception {
        String sql = "SELECT * FROM faulty";
        Statement stm = connection.createStatement();
        ResultSet rst = stm.executeQuery(sql);
        ArrayList<FaultyDTO> list = new ArrayList<>();
        while (rst.next()) {
            list.add(new FaultyDTO(
                    rst.getString(2), 
                    rst.getString(3), 
                    rst.getString(4), 
                    rst.getString(5),
                    rst.getDate(6),
                    rst.getString(7)
                    
                    
            ));
        }
        return list;
    }

    @Override
    public void setConnection(Connection connection) {
        this.connection=connection;
    }

    @Override
    public boolean check_repetition(String id) throws Exception {
        String sql = "SELECT * FROM faulty WHERE serial_no =\"" + id + "\"";
        Statement stm = connection.createStatement();
        ResultSet rst = stm.executeQuery(sql);

        if (rst.next()) {
            return true;
                    
                    
                    
        } else {
            return false;
        }
    }

    @Override
    public boolean add_acknowledgement(FaultyDTO dto) throws Exception {
        String sql = "INSERT INTO acknowledgement(id,"
                 + "serial_no,"
                 + "vendor,"
                 + "erp_item_code,"
                 + "board_name,"
                + "added_date_to_faultylist,"
                 + "faulty_list_added_by,"
                + "added_date_to_ack,"
                + "ack_list_added_by) VALUES(?,?,?,?,?,?,?,?,?)";
        Connection conn = this.connection;
        try (
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1,Integer.parseInt("0"));
            pstmt.setString(2, dto.getSerial_no());
            pstmt.setString(3, dto.getVendor());
            pstmt.setString(4, dto.getErp_item_code());
            pstmt.setString(5, dto.getBoard_name());
            pstmt.setDate(6, (java.sql.Date) dto.getAdded_date());
            pstmt.setString(7, dto.getAdded_by());
            pstmt.setDate(8, (java.sql.Date) dto.getAdded_date_ack());
            pstmt.setString(9, dto.getAck_added_by());
            
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
       return false;
    }

    @Override
    public boolean check_repetition_ack(String id) throws Exception {
        String sql = "SELECT * FROM acknowledgement WHERE serial_no =\"" + id + "\"";
        Statement stm = connection.createStatement();
        ResultSet rst = stm.executeQuery(sql);

        if (rst.next()) {
            return true;
                    
                    
                    
        } else {
            return false;
        }
    }

    @Override
    public ArrayList<FaultyDTO> getAll_ack() throws Exception {
        String sql = "SELECT * FROM acknowledgement";
        Statement stm = connection.createStatement();
        ResultSet rst = stm.executeQuery(sql);
        ArrayList<FaultyDTO> list = new ArrayList<>();
        while (rst.next()) {
            list.add(new FaultyDTO(
                    rst.getString(2), 
                    rst.getString(3), 
                    rst.getString(4), 
                    rst.getString(5),
                    rst.getDate(6),
                    rst.getString(7),
                    rst.getDate(8),
                    rst.getString(9)
                    
                    
            ));
        }
        return list;
    }

    @Override
    public boolean adv_replacment(String id) throws Exception {
        String sql = "DELETE FROM acknowledgement WHERE serial_no=?";
            PreparedStatement pstm = connection.prepareStatement(sql);
            pstm.setObject(1, id);
            return pstm.executeUpdate() > 0;
    }
    
}
