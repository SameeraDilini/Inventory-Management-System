/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dao.custom.impl;

import static com.sun.javafx.util.Utils.split;
import hsb.dao.custom.HistoryDAO;
import hsb.dto.FaultyDTO;
import hsb.dto.HistoryDTO;
import hsb.dto.TransactionDTO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class HistoryDAOImpl implements HistoryDAO{
    
    Connection connection;

    @Override
    public boolean add(TransactionDTO t) throws Exception {
        String sql = "INSERT INTO transactions(id,"
                 + "serial_no,"
                 + "bsc_location,"
                 + "spare_location,"
                + "sub_inventory,"
                + "locator,"
                + "board_name,"
                + "replacement,"
                + "replaced_serial_no,"
                + "added_date,"
                + "added_by,"
                + "comment) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
        Connection conn = this.connection;
        try (
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1,Integer.parseInt("0"));
            pstmt.setString(2, t.getSerial_no());
            pstmt.setString(3, t.getBsc_location());
            pstmt.setString(4, t.getSpare_location());
            pstmt.setString(5, t.getSub_inventory());
            pstmt.setString(6, t.getLocator());
            pstmt.setString(7, t.getBoard_name());
            pstmt.setString(8, t.getReplacement());
            pstmt.setString(9, t.getAdv_serial_no());
            pstmt.setDate(10, (Date) t.getAdded_date());
            pstmt.setString(11, t.getAdded_by());
            pstmt.setString(12, t.getComment());
            
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
       return false;
    }

    @Override
    public boolean update(TransactionDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public TransactionDTO getById(Object id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<TransactionDTO> search(Object id) throws Exception {
        String sql = "SELECT * FROM transactions WHERE serial_no =\"" + id + "\"";
        Statement stm = connection.createStatement();
        ResultSet rst = stm.executeQuery(sql);
        ArrayList<TransactionDTO> list = new ArrayList<>();
        while (rst.next()) {
            list.add(new TransactionDTO(rst.getString(2),
                    rst.getString(3),
                    rst.getString(4),
                    rst.getString(5),
                    rst.getString(6),
                    rst.getString(7),
                    rst.getString(8),
                    rst.getString(9),
                    rst.getDate(10),
                    rst.getString(11),
                    rst.getString(12)
                    ));
        }

        return list;
    }

    @Override
    public ArrayList<TransactionDTO> getAll() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setConnection(Connection connection) {
        this.connection=connection;
    }

    @Override
    public ArrayList<TransactionDTO> search_by_location(String id) throws Exception {
        
       
        String sql = "SELECT * FROM transactions WHERE bsc_location =\"" + id + "\"";
//      String sql = "SELECT * FROM transactions WHERE bsc_name =\"" + bsc_name + "\"";
        Statement stm = connection.createStatement();
        ResultSet rst = stm.executeQuery(sql);
        ArrayList<TransactionDTO> list2 = new ArrayList<>();
        while (rst.next()) {
            list2.add(new TransactionDTO(rst.getString(2),
                    rst.getString(3),
                    rst.getString(4),
                    rst.getString(5),
                    rst.getString(6),
                    rst.getString(7),
                    rst.getString(8),
                    rst.getString(9),
                    rst.getDate(10),
                    rst.getString(11),
                    rst.getString(12)
                    ));
        }

        return list2;
    }

    @Override
    public ArrayList<TransactionDTO> search_by_board(HistoryDTO dto) throws Exception {
       String sql = "SELECT * FROM transactions WHERE board_name =\"" + dto.getBoard_name() + "\" AND added_date BETWEEN \""+dto.getStart_date()+"\" AND \""+dto.getEnd_date()+"\"";
//      String sql = "SELECT * FROM transactions WHERE bsc_name =\"" + bsc_name + "\"";
        Statement stm = connection.createStatement();
        ResultSet rst = stm.executeQuery(sql);
        ArrayList<TransactionDTO> list2 = new ArrayList<>();
        while (rst.next()) {
            list2.add(new TransactionDTO(rst.getString(2),
                    rst.getString(3),
                    rst.getString(4),
                    rst.getString(5),
                    rst.getString(6),
                    rst.getString(7),
                    rst.getString(8),
                    rst.getString(9),
                    rst.getDate(10),
                    rst.getString(11),
                    rst.getString(12)
                    ));
        }

        return list2;
    }
    
}
