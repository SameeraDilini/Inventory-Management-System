/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dao.custom.impl;

import hsb.dao.ConnectionFactory;
import hsb.dao.custom.NodeDAO;
import hsb.dto.Node_FaultyDTO;
import hsb.dto.SpareDTO;
import hsb.dto.bsc_DTO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class NodeDAOImpl implements NodeDAO{
    
    private Connection connection;

    @Override
    public boolean add(bsc_DTO t) throws Exception {
        String sql = "INSERT INTO bsc("
                + "id,"
                + "serial_no,"
                + "vendor,"
                + "bsc_name,"
                + "bsc_location,"
                + "physical_name,"
                + "logical_name,"
                + "erp_item_code,"
                + "erp_item_name,"
                + "rack,"
                + "shelf,"
                + "slot,"
                + "date,"
                + "added_by,"
                + "manufac_date,"
                + "comment) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        Connection conn = this.connection;
        try (
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1,Integer.parseInt("0"));
            pstmt.setString(2, t.getSerial_no());
            pstmt.setString(3, t.getVendor());
            pstmt.setString(4, t.getBsc_rnc_name());
            pstmt.setString(5, t.getBsc_location());
            pstmt.setString(6, t.getPhysical_name());
            pstmt.setString(7, t.getLogical_name());
            pstmt.setString(8, t.getErp_item_code());
            pstmt.setString(9, t.getErp_name());
            pstmt.setString(10, t.getRack());
            pstmt.setString(11, t.getSub_rack());
            pstmt.setString(12, t.getSlot());
            pstmt.setDate(13, (Date) t.getDate());
            pstmt.setString(14, t.getAdded_by());
            pstmt.setDate(15, (Date) t.getManufac_date());
            pstmt.setString(16, t.getComment());
            pstmt.executeUpdate();
            
            return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
        return false;
    }

    @Override
    public boolean update(bsc_DTO t) throws Exception {
        
        String sql = "UPDATE bsc SET "
                + "serial_no=?,"
                + "vendor=?,"
                + "bsc_name=?,"
                + "bsc_location=?,"
                + "physical_name=?,"
                + "logical_name=?,"
                + "erp_item_code=?,"
                + "erp_item_name=?,"
                + "rack=?,"
                + "shelf=?,"
                + "slot=?,"
                + "date=?,"
                + "added_by=?,"
                + "manufac_date=?,"
                + "comment=?  WHERE id=?";
        Connection conn = this.connection;
        try (
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, t.getSpare_serial_no());
            pstmt.setString(2, t.getVendor());
            pstmt.setString(3, t.getBsc_rnc_name());
            pstmt.setString(4, t.getBsc_location());
            pstmt.setString(5, t.getPhysical_name());
            pstmt.setString(6, t.getLogical_name());
            pstmt.setString(7, t.getErp_item_code());
            pstmt.setString(8, t.getErp_name());
            pstmt.setString(9, t.getRack());
            pstmt.setString(10, t.getSub_rack());
            pstmt.setString(11, t.getSlot());
            pstmt.setDate(12, (Date) t.getDate());
            pstmt.setString(13, t.getAdded_by());
            pstmt.setDate(14, (Date) t.getManufac_date());
            pstmt.setString(15, t.getComment());
            pstmt.setInt(16,t.getId());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
       return false;
    }

    @Override
    public boolean delete(String id) throws Exception {
            String sql = "DELETE FROM bsc WHERE serial_no=?";
            PreparedStatement pstm = connection.prepareStatement(sql);
            pstm.setObject(1, id);
            return pstm.executeUpdate() > 0;
    }

    @Override
    public bsc_DTO getById(Object id) throws Exception {
        return null;
    }

    @Override
    public ArrayList<bsc_DTO> search(Object id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<bsc_DTO> getAll() throws Exception {
       return null;
    }

    @Override
    public void setConnection(Connection connection) {
        this.connection=connection;
        
    }

//    @Override
//    public bscDTO getByserial_no(String id) throws Exception {
//        String sql = "SELECT * FROM test WHERE serial_no =\"" + id + "\"";
//        Statement stm = connection.createStatement();
//        ResultSet rst = stm.executeQuery(sql);
//
//        if (rst.next()) {
//            return (new bscDTO(
//                    rst.getString(2), 
//                    rst.getString(3), 
//                    rst.getString(4), 
//                    rst.getString(5),
//                    rst.getString(6),
//                    rst.getString(7),
//                    rst.getString(8),
//                    rst.getString(9),
//                    rst.getString(10),
//                    rst.getString(11),
//                    rst.getString(12),
//                    rst.getDate(13),
//                    rst.getString(14),
//                    rst.getDate(15)));
//        } else {
//            return null;
//        }
//
//    
//    }     

    @Override
    public SpareDTO getSparebyId(String id) throws Exception {
        String sql = "SELECT * FROM faulty_spare WHERE serial_no =\"" + id + "\"";
        Statement stm = connection.createStatement();
        ResultSet rst = stm.executeQuery(sql);

        if (rst.next()) {
            return (new SpareDTO(
                    rst.getString(2), 
                    rst.getString(3), 
                    rst.getString(4), 
                    rst.getString(5),
                    rst.getString(6),
                    rst.getDate(7),
                    rst.getString(8),
                    rst.getString(9),
                    rst.getString(10),
                    rst.getString(11),
                    rst.getDate(12)
                    
                    
                    ));
        } else {
            return null;
        }
    }

    @Override
    public bsc_DTO getById(String id) throws Exception {
        String sql = "SELECT * FROM bsc WHERE serial_no =\"" + id + "\"";
                Statement stm = connection.createStatement();
                ResultSet rst = stm.executeQuery(sql);

                if (rst.next()) {
                    return (new bsc_DTO(
                    rst.getInt(1),
                    rst.getString(2), 
                    rst.getString(3), 
                    rst.getString(4), 
                    rst.getString(5),
                    rst.getString(6),
                    rst.getString(7),
                    rst.getString(8),
                    rst.getString(9),
                    rst.getString(10),
                    rst.getString(11),
                    rst.getString(12),
                    rst.getDate(13),
                    rst.getString(14),
                    rst.getDate(15),
                    rst.getString(16)
                            ));
                } else {
                    return null;
                }    }

    @Override
    public ArrayList<bsc_DTO> getAllNodes() throws Exception {
        String sql = "SELECT * FROM bsc";
        Statement stm = connection.createStatement();
        ResultSet rst = stm.executeQuery(sql);
        ArrayList<bsc_DTO> list = new ArrayList<>();
        while (rst.next()) {
            list.add(new bsc_DTO(
                    rst.getInt(1),
                    rst.getString(2), 
                    rst.getString(3), 
                    rst.getString(4), 
                    rst.getString(5),
                    rst.getString(6),
                    rst.getString(7),
                    rst.getString(8),
                    rst.getString(9),
                    rst.getString(10),
                    rst.getString(11),
                    rst.getString(12),
                    rst.getDate(13),
                    rst.getString(14),
                    rst.getDate(15),
                    rst.getString(16)
            ));
        }
        return list;
    }

    @Override
    public boolean check_repetition(String id) throws Exception {
        String sql = "SELECT * FROM bsc WHERE serial_no =\"" + id + "\"";
        Statement stm = connection.createStatement();
        ResultSet rst = stm.executeQuery(sql);

        if (rst.next()) {
            return true;
                    
                    
                    
        } else {
            return false;
        }
    }


}
