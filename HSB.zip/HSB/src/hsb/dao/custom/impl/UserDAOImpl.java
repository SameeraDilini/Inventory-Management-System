/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dao.custom.impl;

import hsb.dao.ConnectionFactory;
import hsb.dao.custom.UserDAO;
import hsb.dto.LoginDTO;
import hsb.dto.SuperDTO;
import hsb.dto.UserDTO;
import static hsb.view.controller.Sign_upController.DESEDE_ENCRYPTION_SCHEME;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.sql.Connection;
import static java.sql.JDBCType.NULL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

/**
 *
 * @author user
 */
public class UserDAOImpl implements UserDAO{
    
    private Connection connection;
    
    //encryption the password
    private static final String UNICODE_FORMAT = "UTF8";
    public static final String DESEDE_ENCRYPTION_SCHEME = "DESede";
    private KeySpec ks;
    private SecretKeyFactory skf;
    private Cipher cipher;
    byte[] arrayBytes;
    private String myEncryptionKey;
    private String myEncryptionScheme;
    SecretKey key;
    
    
    public UserDAOImpl() throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException{
    
                //encyption password
                myEncryptionKey = "ThisIsSpartaThisIsSparta";
                myEncryptionScheme = DESEDE_ENCRYPTION_SCHEME;
                arrayBytes = myEncryptionKey.getBytes(UNICODE_FORMAT);
                ks = new DESedeKeySpec(arrayBytes);
                skf = SecretKeyFactory.getInstance(myEncryptionScheme);
                cipher = Cipher.getInstance(myEncryptionScheme);
                key = skf.generateSecret(ks);
    
    }
    
    
    @Override
    public boolean add(UserDTO t) throws Exception {
        String en_pwd=encrypt(t.getPassword());
        String sql = "INSERT INTO user(id,username,password) VALUES(?,?,?)";
        Connection conn = this.connection;
        try (
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1,Integer.parseInt("0"));
            pstmt.setString(2, t.getUsername());
            pstmt.setString(3, en_pwd);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
       return false;
    }

    @Override
    public boolean update(UserDTO t) throws Exception {
        String en_pwd=encrypt(t.getPassword());
        String sql = "UPDATE user SET id=?, password=?  WHERE username=?";
        Connection conn = this.connection;
        try (
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1,t.getId());
            pstmt.setString(2, en_pwd);
            pstmt.setString(3, t.getUsername());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
       return false;
        
    }

    @Override
    public boolean delete(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public UserDTO getById(Object id) throws Exception {
        connection=ConnectionFactory.getInstance().getconnection();

       String sql="SELECT * FROM user WHERE `username` = '"+id+"'";
       Statement stm=connection.createStatement();
        ResultSet rst=stm.executeQuery(sql);
        
        if(rst.next()){
            
            UserDTO userdto=new UserDTO(rst.getInt(1),rst.getString(2),decrypt(rst.getString(3)));
            
            return userdto;
        }else{
    
        return null;
        }
    }

    @Override
    public ArrayList<UserDTO> search(Object id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<UserDTO> getAll() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setConnection(Connection connection) {
        try {
            this.connection=connection;
            connection=ConnectionFactory.getInstance().getconnection();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UserDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(UserDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public Boolean lastUser(UserDTO dto) throws Exception {

        String sql = "INSERT INTO login(id,username,password) VALUES(?,?,?)";
        Connection conn = this.connection;
        try (
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1,Integer.parseInt("0"));
            pstmt.setString(2, dto.getUsername());
            pstmt.setString(3, dto.getPassword());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
       return false;
            }

    @Override
    public String getLogged_username() throws Exception {
        connection=ConnectionFactory.getInstance().getconnection();
        
       String sql="SELECT username FROM login ORDER BY id DESC LIMIT 1";
       Statement stm=connection.createStatement();
        ResultSet rst=stm.executeQuery(sql);
        
        if(rst.next()){
           
            return rst.getString(1);
        }else{
    
        return null;
        }
    }
    
    
            //encyption password
            public String encrypt(String unencryptedString) {
                String encryptedString = null;
                try {
                    cipher.init(Cipher.ENCRYPT_MODE, key);
                    byte[] plainText = unencryptedString.getBytes(UNICODE_FORMAT);
                    byte[] encryptedText = cipher.doFinal(plainText);
                    encryptedString = new String(Base64.getEncoder().encodeToString(encryptedText));
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return encryptedString;
            }
            
           public String decrypt(String encryptedString) {
                String decryptedText=null;
                try {
                    cipher.init(Cipher.DECRYPT_MODE, key);
                    byte[] encryptedText = Base64.getDecoder().decode(encryptedString);
                    byte[] plainText = cipher.doFinal(encryptedText);
                    decryptedText= new String(plainText);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return decryptedText;
             }
    
}
