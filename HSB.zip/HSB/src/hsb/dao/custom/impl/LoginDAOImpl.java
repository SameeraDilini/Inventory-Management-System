/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dao.custom.impl;

import hsb.dao.ConnectionFactory;
import hsb.dao.custom.LoginDAO;
import hsb.dto.LoginDTO;
import hsb.dto.SuperDTO;
import static hsb.view.controller.Sign_upController.DESEDE_ENCRYPTION_SCHEME;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

/**
 *
 * @author user
 */

public class LoginDAOImpl implements LoginDAO{
    
    private Connection connection;
    
    //encryption the password
    private static final String UNICODE_FORMAT = "UTF8";
    public static final String DESEDE_ENCRYPTION_SCHEME = "DESede";
    private KeySpec ks;
    private SecretKeyFactory skf;
    private Cipher cipher;
    byte[] arrayBytes;
    private String myEncryptionKey;
    private String myEncryptionScheme;
    SecretKey key;
    
    
    public LoginDAOImpl() throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException{
    
                //decyption password
                 myEncryptionKey = "ThisIsSpartaThisIsSparta";
                myEncryptionScheme = DESEDE_ENCRYPTION_SCHEME;
                arrayBytes = myEncryptionKey.getBytes(UNICODE_FORMAT);
                ks = new DESedeKeySpec(arrayBytes);
                skf = SecretKeyFactory.getInstance(myEncryptionScheme);
                cipher = Cipher.getInstance(myEncryptionScheme);
                key = skf.generateSecret(ks);
    
    }

    @Override
    public LoginDTO checklog(LoginDTO dto) throws Exception {
        connection=ConnectionFactory.getInstance().getconnection();
        
        //encryption
        String en_pwd=encrypt(dto.getPassword());
        
       String sql="SELECT * FROM user WHERE `username` = '"+dto.getUsername()+"' AND `password` = '"+en_pwd+"'";
       Statement stm=connection.createStatement();
        ResultSet rst=stm.executeQuery(sql);
        
        if(rst.next()){
            
            LoginDTO lgdto=new LoginDTO(rst.getString(1),rst.getString(1));
            
            if(lgdto.getPassword()==dto.getPassword()){return null;}
            
            return lgdto;
        }else{
    
        return null;
        }
    }
    

    @Override
    public boolean add(SuperDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean update(SuperDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(String id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public SuperDTO getById(Object id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<SuperDTO> search(Object id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<SuperDTO> getAll() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setConnection(Connection connection) {
       this.connection=connection;
    }

     //encyption password
    public String encrypt(String unencryptedString) {
         String encryptedString = null;
         try {
               cipher.init(Cipher.ENCRYPT_MODE, key);
               byte[] plainText = unencryptedString.getBytes(UNICODE_FORMAT);
               byte[] encryptedText = cipher.doFinal(plainText);
               encryptedString = new String(Base64.getEncoder().encodeToString(encryptedText));
         } catch (Exception e) {
                e.printStackTrace();
         }
                return encryptedString;
         }
    
}
