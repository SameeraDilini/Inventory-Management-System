/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dao.custom.impl;

import hsb.dao.ConnectionFactory;
import hsb.dao.custom.InvenDAO;
import hsb.dto.FaultyDTO;
import hsb.dto.InvenDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class InvenDAOImpl implements InvenDAO{
    
    private Connection connection;

    @Override
    public boolean add(InvenDTO t) throws Exception {
         String sql = "INSERT INTO faulty_spare(id,"
                 + "serial_no,"
                 + "vendor,"
                 + "sub_inventory,"
                 + "locator,"
                 + "location,"
                 + "date,"
                 + "added_by,"
                 + "erp_item_code,"
                 + "erp_no,"
                 + "board_name,"
                 + "manufac_date,"
                 + "comment) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
        Connection conn = this.connection;
        try (
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1,Integer.parseInt("0"));
            pstmt.setString(2, t.getSerial_no());
            pstmt.setString(3, t.getVendor());
            pstmt.setString(4, t.getSub_inventory());
            pstmt.setString(5, t.getLocator());
            pstmt.setString(6, t.getLocation());
            pstmt.setDate(7, (java.sql.Date) t.getDate());
            pstmt.setString(8, t.getAdded_by());
            pstmt.setString(9, t.getItem_code());
            pstmt.setString(10, t.getErp_number());
            pstmt.setString(11, t.getBoard_name());
            pstmt.setDate(12, (java.sql.Date) t.getManufac_date());
            pstmt.setString(13, t.getComment());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
       return false;
    }

    @Override
    public boolean update(InvenDTO t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(String id) throws Exception {
            String sql = "DELETE FROM faulty_spare WHERE serial_no=?";
            PreparedStatement pstm = connection.prepareStatement(sql);
            pstm.setObject(1, id);
            return pstm.executeUpdate() > 0;
    }

    @Override
    public InvenDTO getById(Object id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<InvenDTO> search(Object id) throws Exception {
        return null;
    }

    @Override
    public ArrayList<InvenDTO> getAll() throws Exception {
         String sql = "SELECT * FROM faulty_spare";
        Statement stm = connection.createStatement();
        ResultSet rst = stm.executeQuery(sql);
        ArrayList<InvenDTO> list = new ArrayList<>();
        while (rst.next()) {
            list.add(new InvenDTO(
                    rst.getString(2), 
                    rst.getString(3), 
                    rst.getString(4), 
                    rst.getString(5),
                    rst.getString(6),
                    rst.getDate(7),
                    rst.getString(8),
                    rst.getString(9),
                    rst.getString(10),
                    rst.getString(11),
                    rst.getDate(12),
                    rst.getString(13)
                    
            ));
        }
        return list;
    }

    @Override
    public void setConnection(Connection connection) {
        try {
            this.connection=connection;
            connection=ConnectionFactory.getInstance().getconnection();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(InvenDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(InvenDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public boolean add_faulty(FaultyDTO dto) throws Exception {
        String sql = "INSERT INTO faulty(id,"
                 + "serial_no,"
                 + "vendor,"
                 + "erp_item_code,"
                 + "board_name,"
                + "added_date,"
                 + "added_by) VALUES(?,?,?,?,?,?,?)";
        Connection conn = this.connection;
        try (
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1,Integer.parseInt("0"));
            pstmt.setString(2, dto.getSerial_no());
            pstmt.setString(3, dto.getVendor());
            pstmt.setString(4, dto.getErp_item_code());
            pstmt.setString(5, dto.getBoard_name());
            pstmt.setDate(6, (java.sql.Date) dto.getAdded_date());
            pstmt.setString(7, dto.getAdded_by());
            
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
       return false;
    }

    @Override
    public boolean check_repetition(String id) throws Exception {
        String sql = "SELECT * FROM faulty_spare WHERE serial_no =\"" + id + "\"";
        Statement stm = connection.createStatement();
        ResultSet rst = stm.executeQuery(sql);

        if (rst.next()) {
            return true;
                    
                    
                    
        } else {
            return false;
        }
    }

    
    
}
