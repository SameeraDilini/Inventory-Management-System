/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dao.custom;

import hsb.dao.SuperDAO;
import hsb.dto.FaultyDTO;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public interface FaultsDAO extends SuperDAO<FaultyDTO, Object>{
    boolean check_repetition(String id) throws Exception;
    boolean add_acknowledgement(FaultyDTO dto) throws Exception;
    boolean check_repetition_ack(String id) throws Exception;
    ArrayList<FaultyDTO> getAll_ack() throws Exception;
    boolean adv_replacment(String id) throws Exception;
}
