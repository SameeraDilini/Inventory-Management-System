/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dao.custom;

import hsb.dao.SuperDAO;
import hsb.dto.HistoryDTO;
import hsb.dto.TransactionDTO;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public interface HistoryDAO extends SuperDAO<TransactionDTO, Object>{
    ArrayList<TransactionDTO> search_by_location(String id) throws Exception;
    ArrayList<TransactionDTO> search_by_board(HistoryDTO dto) throws Exception;
    
}
