/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dao.custom;

import hsb.dto.LoginDTO;
import hsb.dao.SuperDAO;
import hsb.dto.SuperDTO;

/**
 *
 * @author user
 */
public interface LoginDAO extends SuperDAO<SuperDTO, Object>{
    LoginDTO checklog(LoginDTO dto) throws Exception;
}
