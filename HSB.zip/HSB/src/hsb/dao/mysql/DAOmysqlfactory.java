/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsb.dao.mysql;

import hsb.dao.ConnectionFactory;
import hsb.dao.DAOFactory;
import hsb.dao.SuperDAO;
import hsb.dao.TransactionScope;
import hsb.dao.custom.FaultsDAO;
import hsb.dao.custom.HistoryDAO;
import hsb.dao.custom.InvenDAO;
import hsb.dao.custom.LoginDAO;
import hsb.dao.custom.NodeDAO;
import hsb.dao.custom.UserDAO;
import hsb.dao.custom.impl.FaultsDAOImpl;
import hsb.dao.custom.impl.HistoryDAOImpl;
import hsb.dao.custom.impl.InvenDAOImpl;
import hsb.dao.custom.impl.LoginDAOImpl;
import hsb.dao.custom.impl.NodeDAOImpl;
import hsb.dao.custom.impl.UserDAOImpl;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.NoSuchPaddingException;

/**
 *
 * @author user
 */
public class DAOmysqlfactory extends DAOFactory{
    
    private static DAOmysqlfactory factory;
    private static Connection connection;
    private LoginDAO login;
    private UserDAO user;
    private NodeDAO node;
    private InvenDAO inventory;
    private FaultsDAO faults;
    private HistoryDAO history;
    private TransactionScope transaction;
    
    
    private DAOmysqlfactory() throws ClassNotFoundException, SQLException, UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException{
      
            connection=ConnectionFactory.getInstance().getconnection();
            login=new LoginDAOImpl();
            user=new UserDAOImpl();
            node=new NodeDAOImpl();
            inventory=new InvenDAOImpl();
            faults=new FaultsDAOImpl();
            history=new HistoryDAOImpl();
     }
    
    public static DAOmysqlfactory getInstance() throws ClassNotFoundException, SQLException, UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException{
            
        if(factory==null){
            
            factory=new DAOmysqlfactory();
        
        }
        
        return factory;
    
    }

    @Override
    public SuperDAO getDAO(DAOType type) {
       switch(type){
       
           case LOGIN:
               return login;
               
           case USER:
               return user;
           case NODE:
               return node;
           case INVEN:
               return inventory;
           case FAULTS:
               return faults;
           case HISTORY:
               return history;
            
           default:
               return null;
       
       
       }
    }

    @Override
    public Connection getConnection() {
       return connection;
    }

    @Override
    public TransactionScope getTransactionScope() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
